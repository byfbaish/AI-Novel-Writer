<script setup lang="ts">
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { contentApi } from '@/api/content'
import { useProjectStore } from '@/stores/project'
import { codexEntrySearchText, useCodexStore } from '@/stores/codex'
import { useGuardStore } from '@/stores/guard'
import { useStylesStore } from '@/stores/styles'
import { CODEX_KIND_LABEL, type CodexEntry, type CodexStateHistoryItem, type ContextLayer, type ContextMode, type GenerationControls, type ProjectNote } from '@/types'
import { useProjectNavigation } from '@/composables/use-project-navigation'
import { generationDraftApi, longGenerationApi, previewGeneration, type GenerationPreview, type LongGenerationPlan } from '@/api/generation'
import AppIcon from '@/components/ui/AppIcon.vue'
import ReviewPanel from '@/components/editor/ReviewPanel.vue'
import type { GenerationDraftDecision, GenerationDraftDetail, GenerationDraftSummary, ReviewAnchor, ReviewComment, ReviewRound, ReviewWorkspace } from '@/types'

/**
 * AI 面板。三件事按重要性排：能不能生成（章纲 + 参数）、
 * 生成会带什么进去（四层预算）、生成前有什么没解决（守卫提醒）。
 * 弹性预算必须逐层可见，作者应知道上下文被哪些材料占用。
 */
const props = defineProps<{
  generating?: boolean
  generationError?: string
  generationErrorCode?: string
  lastGenerationOptions?: GenerationControls | null
  drafts?: GenerationDraftSummary[]
  draftsLoading?: boolean
  reviewWorkspace?: ReviewWorkspace
  reviewAnchor?: ReviewAnchor
  reviewLoading?: boolean
  reviewBusy?: boolean
  reviewError?: string
  reviewSubmitDisabledReason?: string
  mobileReadOnly?: boolean
}>()
const emit = defineEmits<{
  generate: [options: GenerationControls]
  retryGeneration: []
  downgradeGeneration: []
  stop: []
  insertDraft: [draft: GenerationDraftDetail]
  continueDraft: [draft: GenerationDraftDetail]
  rejectDraft: [id: string]
  refreshDrafts: []
  refreshReviews: []
  submitReview: [note: string]
  addReviewComment: [roundId: string, content: string]
  updateReviewComment: [roundId: string, comment: ReviewComment, content: string]
  resolveReviewComment: [roundId: string, comment: ReviewComment]
  decideReview: [round: ReviewRound, decision: 'approved' | 'changes_requested', note: string]
  locateReviewComment: [comment: ReviewComment]
}>()

const router = useRouter()
const project = useProjectStore()
const codex = useCodexStore()
const guard = useGuardStore()
const styles = useStylesStore()
const { toProject } = useProjectNavigation()

const layers = ref<ContextLayer[]>([])
const tab = ref<'ai' | 'long' | 'drafts' | 'refs' | 'review' | 'notes'>('ai')
const targetWords = ref(3000)
const model = ref<'basic' | 'advanced'>('basic')
const contextMode = ref<ContextMode>('smart')
const loadingContext = ref(false)
const contextError = ref('')
const selectedDraft = ref<GenerationDraftDetail | null>(null)
const draftDetailLoading = ref(false)
const draftDetailError = ref('')
const draftReviewBusy = ref(false)
const referenceScope = ref<'chapter' | 'all'>('chapter')
const referenceQuery = ref('')
const selectedReferenceId = ref<string | null>(null)
const referenceStates = ref<CodexStateHistoryItem[]>([])
const referenceStatesLoading = ref(false)
const referenceStatesError = ref('')
const previewOpen = ref(false)
const previewLoading = ref(false)
const previewError = ref('')
const preview = ref<GenerationPreview | null>(null)
const previewOptionsKey = ref('')
const notes = ref<ProjectNote[]>([])
const noteDraft = ref('')
const notesLoading = ref(false)
const noteBusy = ref(false)
const noteError = ref('')
const longPlan = ref<LongGenerationPlan | null>(null)
const longTargetWords = ref(4800)
const longSegmentWords = ref(2400)
const longInstruction = ref('')
const longPlanLoading = ref(false)
const longPlanBusy = ref(false)
const longPlanError = ref('')
const longModel = ref<'basic' | 'advanced'>('basic')
const longContextMode = ref<ContextMode>('smart')
const longAutoRun = ref(false)
let longPollTimer: number | null = null
let longPumpInFlight = false
let referenceStateRequest = 0
let previewRequest = 0
let notesRequest = 0

const CONTEXT_MODES: ReadonlyArray<{ value: ContextMode; label: string; budget: number; title: string }> = [
  { value: 'smart', label: '智能', budget: 208000, title: '按作品长度与本章关联内容在 64k 至 208k 间弹性分配' },
  { value: 'fast', label: '快速', budget: 64000, title: '减少远距资料，优先保证生成速度' },
  { value: 'standard', label: '标准', budget: 128000, title: '兼顾最近正文、设定与历史摘要' },
  { value: 'deep', label: '深度', budget: 208000, title: '为长篇关键章节加载更多远距证据' }
]
const CONTEXT_MODE_BUDGET = Object.fromEntries(
  CONTEXT_MODES.map((item) => [item.value, item.budget])
) as Record<ContextMode, number>
const availableTabs = computed(() => props.mobileReadOnly
  ? (['notes'] as const)
  : (['ai', 'long', 'drafts', 'refs', 'review', 'notes'] as const))

watch(() => props.mobileReadOnly, (value) => {
  if (value) tab.value = 'notes'
}, { immediate: true })

async function loadNotes() {
  const projectId = project.project?.id
  const requestId = ++notesRequest
  if (!projectId) {
    notes.value = []
    notesLoading.value = false
    noteError.value = ''
    return
  }
  notesLoading.value = true
  noteError.value = ''
  try {
    const result = await contentApi.listProjectNotes(projectId)
    if (requestId === notesRequest) notes.value = result
  } catch {
    if (requestId === notesRequest) noteError.value = '灵感速记加载失败，请稍后重试。'
  } finally {
    if (requestId === notesRequest) notesLoading.value = false
  }
}

const longNextSegment = computed(() => longPlan.value?.segments.find((segment) => segment.status === 'pending' || segment.status === 'failed') ?? null)
const longRunning = computed(() => Boolean(longPlan.value?.segments.some((segment) => segment.status === 'running')))
const longPlanLocked = computed(() => Boolean(longPlan.value?.segments.some((segment) => ['running', 'ready', 'accepted'].includes(segment.status))))
const longReadyCount = computed(() => longPlan.value?.segments.filter((segment) => segment.status === 'ready').length ?? 0)
const longCompletedCount = computed(() => longPlan.value?.segments.filter((segment) => segment.status === 'ready' || segment.status === 'accepted').length ?? 0)
const longActiveCount = computed(() => longPlan.value?.segments.filter((segment) => segment.status !== 'skipped').length ?? 0)
const longProgressPercent = computed(() => longActiveCount.value ? Math.min(100, (longCompletedCount.value / longActiveCount.value) * 100) : 0)
const longComplete = computed(() => Boolean(longPlan.value && longActiveCount.value > 0 && longCompletedCount.value === longActiveCount.value))

function clearLongPoll() {
  if (longPollTimer !== null) {
    window.clearTimeout(longPollTimer)
    longPollTimer = null
  }
}

function scheduleLongPoll() {
  clearLongPoll()
  if (!longRunning.value || !project.activeId) return
  longPollTimer = window.setTimeout(async () => {
    longPollTimer = null
    await loadLongPlan()
    scheduleLongPoll()
  }, 4000)
}

async function loadLongPlan() {
  const chapterId = project.activeId
  if (!chapterId || longPlanLoading.value) return
  longPlanLoading.value = true
  longPlanError.value = ''
  try {
    const plan = await longGenerationApi.getPlan(chapterId)
    longPlan.value = plan
    if (typeof plan.targetWords === 'number') longTargetWords.value = plan.targetWords
    if (typeof plan.segmentWords === 'number') longSegmentWords.value = plan.segmentWords
    if (longAutoRun.value) await pumpLongAutoRun()
    scheduleLongPoll()
  } catch (error) {
    const message = error instanceof Error ? error.message : '长篇计划加载失败'
    if (!message.includes('404')) longPlanError.value = message
  } finally {
    longPlanLoading.value = false
  }
}

async function createLongPlan() {
  const chapterId = project.activeId
  if (!chapterId || longPlanBusy.value) return
  longPlanBusy.value = true
  longPlanError.value = ''
  try {
    longPlan.value = await longGenerationApi.createPlan({
      chapterId,
      targetWords: Math.max(800, Math.min(1_000_000, Math.round(longTargetWords.value))),
      segmentWords: Math.max(800, Math.min(32_000, Math.round(longSegmentWords.value))),
      scenePurposes: project.active?.outline ?? []
    })
    scheduleLongPoll()
  } catch (error) {
    longPlanError.value = error instanceof Error ? error.message : '长篇计划创建失败'
  } finally {
    longPlanBusy.value = false
  }
}

async function queueLongNext() {
  const segment = longNextSegment.value
  if (!segment || longPlanBusy.value) return
  longPlanBusy.value = true
  longPlanError.value = ''
  try {
    const queued = await longGenerationApi.queueSegment(segment.id, {
      model: longModel.value,
      contextMode: longContextMode.value,
      dialogueDensity: 'mid',
      useStyleProfile: true,
      instruction: longInstruction.value.trim()
    })
    if (longPlan.value) {
      longPlan.value = {
        ...longPlan.value,
        segments: longPlan.value.segments.map((item) => item.id === queued.id ? { ...item, ...queued, status: 'running' } : item)
      }
    }
    scheduleLongPoll()
  } catch (error) {
    longPlanError.value = error instanceof Error ? error.message : '长篇分段排队失败'
  } finally {
    longPlanBusy.value = false
  }
}

/**
 * Queue one segment at a time so the existing lease/checkpoint/credit path stays
 * authoritative. A failed worker segment pauses the run for author review
 * instead of retrying indefinitely or hiding a quality/cost problem.
 */
async function pumpLongAutoRun() {
  if (longPumpInFlight || !longAutoRun.value || !longPlan.value || longPlanBusy.value || longRunning.value) return
  const next = longNextSegment.value
  if (!next) {
    longAutoRun.value = false
    return
  }
  if (next.status === 'failed') {
    longAutoRun.value = false
    return
  }
  longPumpInFlight = true
  try {
    await queueLongNext()
  } catch {
    longAutoRun.value = false
  } finally {
    longPumpInFlight = false
  }
}

function startLongAutoRun() {
  if (!longPlan.value || longRunning.value || !longNextSegment.value || longPlanBusy.value) return
  longAutoRun.value = true
  void pumpLongAutoRun()
}

function stopLongAutoRun() {
  longAutoRun.value = false
}

function toggleLongAutoRun() {
  if (longAutoRun.value) stopLongAutoRun()
  else startLongAutoRun()
}

async function mergeLongPlan() {
  const chapterId = project.activeId
  if (!chapterId || longPlanBusy.value || !longReadyCount.value) return
  longPlanBusy.value = true
  longPlanError.value = ''
  try {
    await longGenerationApi.merge(chapterId)
    // The previous candidate may refer to an already accepted prefix. Clear
    // it before refreshing so the detail pane cannot offer stale actions.
    selectedDraft.value = null
    emit('refreshDrafts')
    tab.value = 'drafts'
  } catch (error) {
    longPlanError.value = error instanceof Error ? error.message : '长篇候选合并失败'
  } finally {
    longPlanBusy.value = false
  }
}

watch(
  () => (props.drafts ?? []).map((draft) => draft.id),
  (ids) => {
    if (selectedDraft.value && !ids.includes(selectedDraft.value.id)) {
      selectedDraft.value = null
      draftDetailError.value = ''
    }
  },
)

watch(() => project.activeId, () => {
  clearLongPoll()
  longPlan.value = null
  longPlanError.value = ''
  longAutoRun.value = false
  if (tab.value === 'long') void loadLongPlan()
})

watch(() => tab.value, (value) => {
  if (value === 'long') void loadLongPlan()
})

onBeforeUnmount(() => {
  clearLongPoll()
  longAutoRun.value = false
})

watch(() => project.project?.id, () => void loadNotes(), { immediate: true })

async function createNote() {
  const projectId = project.project?.id
  const content = noteDraft.value.trim()
  if (!projectId || !content || noteBusy.value) return
  noteBusy.value = true
  noteError.value = ''
  try {
    const note = await contentApi.createProjectNote(projectId, content, project.activeId ?? undefined)
    if (project.project?.id === projectId) {
      notes.value.unshift(note)
      noteDraft.value = ''
    }
  } catch {
    if (project.project?.id === projectId) noteError.value = '灵感速记保存失败，请稍后重试。'
  } finally {
    noteBusy.value = false
  }
}

async function deleteNote(note: ProjectNote) {
  const projectId = project.project?.id
  if (!projectId || noteBusy.value) return
  noteBusy.value = true
  noteError.value = ''
  try {
    await contentApi.deleteProjectNote(projectId, note.id)
    if (project.project?.id === projectId) {
      notes.value = notes.value.filter((item) => item.id !== note.id)
    }
  } catch {
    if (project.project?.id === projectId) noteError.value = '灵感速记删除失败，请稍后重试。'
  } finally {
    noteBusy.value = false
  }
}

function noteTime(value: string) {
  return new Date(value).toLocaleString('zh-CN', {
    month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit'
  })
}

watch(
  () => [project.project?.id, project.activeId, contextMode.value] as const,
  async ([projectId, chapterId, selectedContextMode]) => {
    if (!projectId || !chapterId) return
    loadingContext.value = true
    contextError.value = ''
    try {
      const [context] = await Promise.all([
        contentApi.getContextLayers(projectId, chapterId, selectedContextMode),
        styles.load()
      ])
      layers.value = context
    } catch (error) {
      layers.value = []
      contextError.value = error instanceof Error ? error.message : '上下文加载失败'
    } finally {
      loadingContext.value = false
    }
  },
  { immediate: true }
)

function generationOptions(): GenerationControls {
  return {
    targetWords: Math.max(200, Math.min(20000, targetWords.value || 3000)),
    model: model.value,
    useStyleProfile: true,
    dialogueDensity: 'high',
    contextMode: contextMode.value
  }
}

function generationOptionsKey(options = generationOptions()) {
  return JSON.stringify({ chapterId: project.activeId, ...options })
}

const previewStale = computed(() => Boolean(preview.value && previewOptionsKey.value !== generationOptionsKey()))

async function loadPromptPreview(showPanel: boolean): Promise<GenerationPreview | null> {
  if (!project.activeId || previewLoading.value) return null
  const requestId = ++previewRequest
  const chapterId = project.activeId
  const options = generationOptions()
  const optionsKey = generationOptionsKey(options)
  if (showPanel) previewOpen.value = true
  previewLoading.value = true
  previewError.value = ''
  try {
    const result = await previewGeneration({ chapterId, ...options })
    if (requestId !== previewRequest || chapterId !== project.activeId || optionsKey !== generationOptionsKey()) return null
    preview.value = result
    previewOptionsKey.value = optionsKey
    return result
  } catch (error) {
    if (requestId === previewRequest) {
      preview.value = null
      previewError.value = error instanceof Error ? error.message : '提示词预览加载失败'
      previewOpen.value = true
    }
    return null
  } finally {
    if (requestId === previewRequest) previewLoading.value = false
  }
}

async function requestGeneration() {
  const result = await loadPromptPreview(false)
  if (!result) return
  if (result.preflight.blocking) {
    previewOpen.value = true
    return
  }
  emit('generate', generationOptions())
}

function openPromptPreview() {
  void loadPromptPreview(true)
}

function closePromptPreview() {
  ++previewRequest
  previewOpen.value = false
  previewLoading.value = false
}

const total = computed(() => layers.value.reduce((s, l) => s + l.tokens, 0))
const contextBudgetLimit = computed(() => CONTEXT_MODE_BUDGET[contextMode.value])
const over = computed(() => total.value > contextBudgetLimit.value)
const k = (n: number) => (n / 1000).toFixed(1) + 'k'
const layerShare = (tokens: number) => total.value ? Math.min(100, (tokens / total.value) * 100) : 0
const LAYER_LABEL: Record<string, string> = {
  resident: '常驻设定',
  retrieved: '本章相关设定',
  summary: '前情摘要',
  adjacent: '相邻章节原文'
}

const previewContextStats = computed(() => {
  if (!preview.value) return null
  const value = preview.value
  const stats = value.contextStats ?? value.context_stats
  return {
    mode: stats?.mode ?? value.tokenBudget.mode ?? contextMode.value,
    budget: stats?.budgetTokens ?? stats?.budget_tokens ?? value.tokenBudget.total,
    used: stats?.usedTokens ?? stats?.used_tokens ?? value.tokenBudget.context,
    modelWindow: stats?.modelWindowTokens ?? stats?.model_window_tokens ?? value.tokenBudget.modelWindow,
    reservedOutput: stats?.reservedOutputTokens ?? stats?.reserved_output_tokens ?? value.tokenBudget.reservedOutput,
    safetyMargin: stats?.safetyMarginTokens ?? value.tokenBudget.safetyMargin,
    usableContext: stats?.usableContextTokens ?? value.tokenBudget.usableContext
  }
})

const previewContextSections = computed(() => {
  if (!preview.value) return []
  if (preview.value.sections?.length) {
    return preview.value.sections.map((section, index) => ({
      key: section.key ?? `${section.source ?? section.label ?? 'section'}-${index}`,
      label: section.label ?? section.source ?? section.key ?? '上下文资料',
      source: section.source,
      included: section.includedTokens ?? section.included_tokens ?? 0,
      available: section.availableTokens ?? section.available_tokens,
      trimReason: section.trimReason ?? section.trim_reason
    }))
  }
  return preview.value.layers.map((layer) => ({
    key: layer.key,
    label: layer.label ?? LAYER_LABEL[layer.key] ?? layer.key,
    source: layer.source,
    included: layer.tokens,
    available: layer.availableTokens ?? layer.budgetTokens ?? layer.budget,
    trimReason: layer.trimReason
  }))
})

function contextModeLabel(mode?: ContextMode) {
  return CONTEXT_MODES.find((item) => item.value === mode)?.label ?? '智能'
}

const cost = computed(() => (model.value === 'advanced' ? 35 : 18))
const canRetryGeneration = computed(() => Boolean(props.generationError && props.lastGenerationOptions))
const canDowngradeGeneration = computed(() => Boolean(
  canRetryGeneration.value && (
    props.lastGenerationOptions?.model === 'advanced'
    || props.generationErrorCode === 'INSUFFICIENT_CREDITS'
    || props.generationErrorCode === 'insufficient_credits'
  )
))
const generationErrorLabel = computed(() => {
  switch (props.generationErrorCode) {
    case 'AUTH_REQUIRED':
    case 'TOKEN_EXPIRED':
    case 'unauthorized':
      return '登录状态已失效'
    case 'INSUFFICIENT_CREDITS':
    case 'insufficient_credits':
      return '积分不足'
    case 'GENERATION_CONFLICT':
    case 'generation_conflict':
      return '版本冲突'
    case 'network_error':
      return '网络连接失败'
    default:
      return '生成未完成'
  }
})
const styleName = computed(() => {
  const id = project.project?.styleProfile
  return id ? styles.byId.get(id)?.name ?? '已绑定风格档' : '未设置'
})

/** 本章引用的设定：mock 下按章号反查 refChapters */
const refs = computed(() => {
  const idx = project.active?.index
  if (!idx) return []
  return codex.entries.filter((e) => e.refChapters.includes(idx))
})

const referenceRows = computed(() => {
  const query = referenceQuery.value.trim().toLowerCase()
  const pool = referenceScope.value === 'chapter' && !query ? refs.value : codex.entries
  return [...pool]
    .filter((entry) => entry.status === 'confirmed')
    .filter((entry) => !query || codexEntrySearchText(entry).includes(query))
    .sort((left, right) => Number(right.resident) - Number(left.resident) || right.refChapters.length - left.refChapters.length)
})

const selectedReference = computed(() => selectedReferenceId.value ? codex.byId.get(selectedReferenceId.value) ?? null : null)

const referenceFacts = computed(() => {
  const entry = selectedReference.value
  if (!entry) return []
  if (entry.kind !== 'character') return entry.facts ?? []
  return [
    { label: '当前状态', value: entry.character?.currentState },
    { label: '行动动机', value: entry.character?.motivation },
    { label: '能力', value: entry.character?.ability },
    { label: '能力边界', value: entry.character?.limitation },
    { label: '语言习惯', value: entry.character?.speech }
  ].filter((item): item is { label: string; value: string } => Boolean(item.value))
})

const effectiveReferenceStates = computed(() => {
  const targetIndex = project.active?.index ?? Number.MAX_SAFE_INTEGER
  const latest = new Map<string, CodexStateHistoryItem>()
  referenceStates.value
    .filter((item) => item.source === 'author' && item.chapterIndex <= targetIndex)
    .forEach((item) => {
      const previous = latest.get(item.stateKey)
      if (!previous || previous.chapterIndex <= item.chapterIndex) latest.set(item.stateKey, item)
    })
  return [...latest.values()].sort((left, right) => left.stateKey.localeCompare(right.stateKey))
})

watch(() => project.activeId, () => {
  ++referenceStateRequest
  ++previewRequest
  selectedDraft.value = null
  draftDetailError.value = ''
  selectedReferenceId.value = null
  referenceStates.value = []
  referenceStatesLoading.value = false
  previewOpen.value = false
  preview.value = null
  previewOptionsKey.value = ''
  previewError.value = ''
  previewLoading.value = false
})

watch(
  [selectedReferenceId, () => project.project?.id],
  async ([entryId, projectId]) => {
    const requestId = ++referenceStateRequest
    referenceStates.value = []
    referenceStatesError.value = ''
    if (!entryId || !projectId) {
      referenceStatesLoading.value = false
      return
    }
    referenceStatesLoading.value = true
    try {
      const result = await contentApi.listCodexStateHistory(projectId, entryId)
      if (requestId === referenceStateRequest) referenceStates.value = result
    } catch {
      if (requestId === referenceStateRequest) referenceStatesError.value = '当前状态加载失败。'
    } finally {
      if (requestId === referenceStateRequest) referenceStatesLoading.value = false
    }
  }
)

function openReference(entry: CodexEntry) {
  selectedReferenceId.value = entry.id
}

function openFullReference(entry: CodexEntry) {
  codex.kind = entry.kind
  codex.query = entry.name
  router.push(toProject('codex'))
}

async function openDraft(draft: GenerationDraftSummary) {
  draftDetailLoading.value = true
  draftDetailError.value = ''
  try {
    selectedDraft.value = await generationDraftApi.get(draft.id)
  } catch (error) {
    draftDetailError.value = error instanceof Error ? error.message : '候选内容加载失败'
  } finally {
    draftDetailLoading.value = false
  }
}

function draftLabel(draft: GenerationDraftSummary) {
  if (draft.requestSummary.action) return draft.requestSummary.action
  return draft.kind === 'chapter' ? '整章生成' : '行内生成'
}

function draftTime(value: string) {
  return new Date(value).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })
}

function rejectSelected() {
  if (!selectedDraft.value) return
  emit('rejectDraft', selectedDraft.value.id)
  selectedDraft.value = null
}

const acceptedDraftContent = computed(() => selectedDraft.value?.segments
  .filter((segment) => segment.decision === 'accepted')
  .map((segment) => segment.text)
  .join('\n') ?? '')

const selectedDraftWarnings = computed(() => selectedDraft.value?.coverage?.checks.filter(
  (check) => check.severity === 'warning' && ['attention', 'author_review'].includes(check.status)
) ?? [])

// The API deliberately bounds one review request so an accidental click on
// a million-character candidate cannot create an oversized JSON payload. A
// long segment can contain well over 500 paragraphs, so bulk review must be
// sent as versioned batches and each response becomes the base for the next.
const DRAFT_REVIEW_BATCH_SIZE = 400

async function decideDraftSegments(segmentIds: string[], decision: GenerationDraftDecision) {
  const draft = selectedDraft.value
  if (!draft || draftReviewBusy.value || draft.status === 'streaming' || !segmentIds.length) return
  draftReviewBusy.value = true
  draftDetailError.value = ''
  try {
    const uniqueIds = [...new Set(segmentIds)]
    for (let start = 0; start < uniqueIds.length; start += DRAFT_REVIEW_BATCH_SIZE) {
      const current = selectedDraft.value
      if (!current) break
      const batch = uniqueIds.slice(start, start + DRAFT_REVIEW_BATCH_SIZE)
      selectedDraft.value = await generationDraftApi.review(
        current.id,
        batch,
        decision,
        current.reviewVersion,
      )
    }
  } catch (error) {
    draftDetailError.value = error instanceof Error ? error.message : '候选审阅保存失败'
    try {
      selectedDraft.value = await generationDraftApi.get(draft.id)
    } catch {
      // 保留原稿，避免二次加载失败让作者失去当前阅读位置。
    }
  } finally {
    draftReviewBusy.value = false
  }
}

function decideAllDraftSegments(decision: Exclude<GenerationDraftDecision, 'pending'>) {
  const ids = selectedDraft.value?.segments.map((segment) => segment.id) ?? []
  void decideDraftSegments(ids, decision)
}

function insertReviewedDraft() {
  const draft = selectedDraft.value
  if (!draft || draft.review.pending > 0 || !acceptedDraftContent.value) return
  emit('insertDraft', { ...draft, content: acceptedDraftContent.value })
}

function forwardReviewComment(roundId: string, content: string) {
  emit('addReviewComment', roundId, content)
}

function forwardReviewCommentUpdate(roundId: string, comment: ReviewComment, content: string) {
  emit('updateReviewComment', roundId, comment, content)
}

function forwardReviewCommentResolution(roundId: string, comment: ReviewComment) {
  emit('resolveReviewComment', roundId, comment)
}

function forwardReviewDecision(round: ReviewRound, decision: 'approved' | 'changes_requested', note: string) {
  emit('decideReview', round, decision, note)
}
</script>

<template>
  <div>
    <div class="wk-tabs">
      <button
        v-for="t in availableTabs"
        :key="t"
        class="wk-tab"
        type="button"
        role="tab"
        :aria-selected="tab === t"
        @click="tab = t"
      >
        {{ t === 'ai' ? 'AI' : t === 'long' ? '长篇' : t === 'drafts' ? `候选 ${props.drafts?.length ?? 0}` : t === 'refs' ? '资料' : t === 'review' ? `审稿 ${props.reviewWorkspace?.rounds[0]?.comments.filter((item) => item.status === 'open').length ?? 0}` : '笔记' }}
      </button>
    </div>

    <div v-if="previewOpen" class="prompt-preview" role="region" aria-label="生成提示词预览">
      <div class="prompt-preview-head">
        <div>
          <div class="wk-label">生成前检查</div>
          <h2>本次提示词</h2>
        </div>
        <button class="prompt-preview-close" type="button" aria-label="关闭提示词预览" @click="closePromptPreview"><AppIcon name="close" :size="15" /></button>
      </div>

      <p v-if="previewLoading" class="prompt-preview-state">正在装配本章设定，不会调用模型或扣除积分…</p>
      <div v-else-if="previewError" class="prompt-preview-state prompt-preview-error" role="alert">
        <p>{{ previewError }}</p>
        <button class="wk-btn wk-btn-xs" type="button" @click="openPromptPreview">重新检查</button>
      </div>
      <template v-else-if="preview">
        <div v-if="previewStale" class="prompt-preview-stale" role="status">
          <span>生成参数已变化，这份提示词不再对应当前设置。</span>
          <button class="wk-btn wk-btn-xs" type="button" @click="openPromptPreview">按当前参数刷新</button>
        </div>
        <div class="prompt-preview-summary">
          <span>{{ preview.chapterTitle }}</span>
          <span>{{ preview.model.id }} · {{ preview.targetWords }} 字</span>
          <span>{{ preview.provider.source === 'user' ? '自带模型' : '平台模型' }}</span>
          <span>{{ preview.tokenBudget.prompt.toLocaleString() }} tokens</span>
        </div>

        <section v-if="previewContextStats" class="prompt-preview-section context-stats" aria-label="上下文用量">
          <div class="row-between">
            <div class="wk-label">上下文用量 · {{ contextModeLabel(previewContextStats.mode) }}</div>
            <span class="prompt-preview-metric">
              {{ previewContextStats.used.toLocaleString() }} / {{ previewContextStats.budget.toLocaleString() }}
            </span>
          </div>
          <div class="context-stat-grid">
            <span v-if="previewContextStats.modelWindow"><small>模型窗口</small>{{ k(previewContextStats.modelWindow) }}</span>
            <span v-if="previewContextStats.reservedOutput"><small>输出预留</small>{{ k(previewContextStats.reservedOutput) }}</span>
            <span v-if="previewContextStats.safetyMargin"><small>安全余量</small>{{ k(previewContextStats.safetyMargin) }}</span>
            <span v-if="previewContextStats.usableContext"><small>可用上限</small>{{ k(previewContextStats.usableContext) }}</span>
          </div>
          <div v-if="previewContextSections.length" class="context-section-list">
            <div v-for="section in previewContextSections" :key="section.key" class="context-section-row">
              <span><strong>{{ section.label }}</strong><small v-if="section.source">{{ section.source }}</small></span>
              <span>{{ section.included.toLocaleString() }}<template v-if="section.available !== undefined"> / {{ section.available.toLocaleString() }}</template></span>
              <p v-if="section.trimReason">{{ section.trimReason }}</p>
            </div>
          </div>
        </section>

        <section class="prompt-preview-section" aria-labelledby="preflight-title">
          <div class="wk-label" id="preflight-title">生成前检查</div>
          <p
            class="prompt-preview-note"
            :class="preview.preflight.blocking ? 'prompt-preview-warning' : ''"
          >
            {{ preview.preflight.blocking ? '提示词超过硬预算，当前请求不应直接生成。' : preview.preflight.warningCount ? `有 ${preview.preflight.warningCount} 项规划需要作者复核。` : '预算、规划和索引检查通过。' }}
          </p>
          <details v-if="preview.preflight.checks.length" class="prompt-layer">
            <summary>查看检查项</summary>
            <ul class="prompt-preview-checks">
              <li v-for="check in preview.preflight.checks" :key="check.id">
                <strong>{{ check.id }}</strong><span>{{ check.message }}</span>
              </li>
            </ul>
          </details>
        </section>

        <section class="prompt-preview-section">
          <div class="wk-label">已加载技能 · {{ preview.skills.length }}</div>
          <div class="prompt-skill-list">
            <span v-for="skill in preview.skills" :key="skill.id" class="prompt-skill">
              {{ skill.id }} <small>{{ skill.version }}</small>
            </span>
          </div>
          <p class="prompt-preview-note">场景判断：{{ preview.scene }}。技能只影响写法，不会覆盖已确认设定。</p>
        </section>

        <section class="prompt-preview-section">
          <div class="row-between">
            <div class="wk-label">四层上下文</div>
            <span class="prompt-preview-metric">{{ preview.tokenBudget.context.toLocaleString() }} / {{ preview.tokenBudget.total.toLocaleString() }}</span>
          </div>
          <details v-for="layer in preview.layers" :key="layer.key" class="prompt-layer">
            <summary><span>{{ LAYER_LABEL[layer.key] ?? layer.key }}</span><span>{{ layer.tokens.toLocaleString() }} tokens · {{ layer.items.length }} 项</span></summary>
            <pre>{{ layer.content || '（这一层为空）' }}</pre>
          </details>
          <p v-if="preview.tokenBudget.trimmedLayers.length" class="prompt-preview-note prompt-preview-warning">
            已按预算裁剪：{{ preview.tokenBudget.trimmedLayers.join('、') }}
          </p>
        </section>

        <section class="prompt-preview-section">
          <div class="wk-label">最终发送消息</div>
          <details v-for="message in preview.messages" :key="message.role" class="prompt-message" :open="message.role === 'user'">
            <summary>{{ message.role === 'system' ? 'System · 写作规则' : 'User · 本章任务' }}</summary>
            <pre>{{ message.content }}</pre>
          </details>
        </section>
      </template>
    </div>

    <template v-if="tab === 'ai'">
      <!-- 章纲：生成的依据，放最上面 -->
      <section class="wk-sec">
        <div class="wk-label" :style="{ marginBottom: 'var(--u2)' }">本章章纲</div>
        <ol
          v-if="project.active?.outline.length"
          :style="{ margin: '0 0 var(--u3)', padding: '0 0 0 18px', fontSize: 'var(--fs)', lineHeight: 1.85, color: 'var(--ink-2)' }"
        >
          <li v-for="(o, i) in project.active.outline" :key="i">{{ o }}</li>
        </ol>
        <p v-else :style="{ margin: '0 0 var(--u3)', color: 'var(--ink-3)', lineHeight: 1.7 }">
          本章还没有章纲，先写一句你想发生什么。
        </p>

        <button
          v-if="props.generating"
          class="wk-btn wk-btn-block"
          type="button"
          @click="emit('stop')"
        >停止生成</button>
        <button
          v-else
          class="wk-btn wk-btn-block"
          type="button"
          data-primary="true"
          :disabled="previewLoading"
          @click="requestGeneration"
        >{{ previewLoading ? '正在检查本章…' : '按章纲生成整章' }}</button>
        <button
          v-if="!props.generating"
          class="wk-btn wk-btn-block"
          type="button"
          @click="openPromptPreview"
        >预览提示词</button>
        <div v-if="props.generationError" class="generation-recovery" role="alert">
          <div class="generation-recovery-title">
            <strong>{{ generationErrorLabel }}</strong>
          </div>
          <p>{{ props.generationError }}</p>
          <div class="generation-recovery-actions">
            <button
              v-if="canRetryGeneration"
              class="wk-btn wk-btn-xs"
              type="button"
              :disabled="props.generating"
              @click="emit('retryGeneration')"
            >重试</button>
            <button
              v-if="canDowngradeGeneration"
              class="wk-btn wk-btn-xs"
              type="button"
              :disabled="props.generating"
              data-primary="true"
              @click="emit('downgradeGeneration')"
            >切换基础档重试</button>
            <button class="wk-btn wk-btn-xs" type="button" @click="tab = 'drafts'">
              查看已保留片段
            </button>
          </div>
          <small>失败内容会保留在“候选”中，确认后再放入正文。</small>
        </div>
      </section>

      <!-- 生成参数 -->
      <section class="wk-sec">
        <div class="wk-label" :style="{ marginBottom: 'var(--u2)' }">生成参数</div>
        <div :style="{ display: 'grid', gap: '6px', fontSize: 'var(--fs)' }">
          <label class="row-between">
            <span :style="{ color: 'var(--ink-2)' }">模型档位</span>
            <select v-model="model" class="wk-input" :style="{ width: '120px', height: '22px' }">
              <option value="basic">基础档</option>
              <option value="advanced">高级档</option>
            </select>
          </label>
          <label class="row-between">
            <span :style="{ color: 'var(--ink-2)' }">目标字数</span>
            <input v-model.number="targetWords" class="wk-input" type="number" step="500"
                   :style="{ width: '120px', height: '22px', fontFamily: 'var(--font-mono)' }">
          </label>
          <div class="context-mode-field">
            <span>上下文范围</span>
            <div class="context-mode-control" role="radiogroup" aria-label="上下文范围">
              <button
                v-for="item in CONTEXT_MODES"
                :key="item.value"
                type="button"
                role="radio"
                :aria-checked="contextMode === item.value"
                :title="item.title"
                @click="contextMode = item.value"
              >{{ item.label }}</button>
            </div>
          </div>
          <div class="row-between">
            <span :style="{ color: 'var(--ink-2)' }">风格档</span>
            <span>{{ styleName }}</span>
          </div>
          <div class="row-between">
            <span :style="{ color: 'var(--ink-2)' }">预估消耗</span>
            <span :style="{ fontFamily: 'var(--font-mono)' }">{{ cost }} 积分</span>
          </div>
        </div>
      </section>

      <!-- 当前上下文素材 -->
      <section class="wk-sec">
        <div class="row-between" :style="{ marginBottom: 'var(--u2)' }">
          <span class="wk-label">上下文预算 · {{ contextModeLabel(contextMode) }}</span>
          <span
            :style="{
              fontFamily: 'var(--font-mono)', fontSize: 'var(--fs-sm)',
              color: over ? 'var(--alert-ink)' : 'var(--ink-3)',
              fontWeight: over ? 700 : 400
            }"
          >{{ k(total) }} / {{ k(contextBudgetLimit) }}</span>
        </div>

        <div :style="{ display: 'grid', gap: 'var(--u2)' }">
          <div v-for="l in layers" :key="l.key">
            <div class="row-between" :style="{ fontSize: 'var(--fs-sm)', marginBottom: '3px' }">
              <span :title="l.detail" :style="{ color: 'var(--ink-2)' }">{{ l.label }}</span>
              <span :style="{ fontFamily: 'var(--font-mono)', color: 'var(--ink-3)' }">
                {{ k(l.tokens) }}
              </span>
            </div>
            <div class="bar" :data-layer="l.key">
              <span :style="{ width: layerShare(l.tokens) + '%' }" />
            </div>
          </div>
        </div>
        <p v-if="loadingContext" :style="{ margin: 'var(--u2) 0 0', color: 'var(--ink-3)', fontSize: 'var(--fs-sm)' }">正在装配本章上下文…</p>
        <p v-else-if="contextError" :style="{ margin: 'var(--u2) 0 0', color: 'var(--alert-ink)', fontSize: 'var(--fs-sm)' }">{{ contextError }}</p>
      </section>

      <!-- 守卫提醒：只取最紧要的三条 -->
      <section class="wk-sec">
        <div class="row-between" :style="{ marginBottom: 'var(--u2)' }">
          <span class="wk-label" :style="{ color: guard.open.length ? 'var(--alert-ink)' : 'var(--ink-3)' }">
            守卫提醒
          </span>
          <button class="wk-btn wk-btn-xs" type="button" @click="router.push(toProject('guard'))">
            全部 {{ guard.open.length }}
          </button>
        </div>

        <div :style="{ display: 'grid', gap: '6px' }">
          <button
            v-for="i in guard.topThree"
            :key="i.id"
            type="button"
            :style="{
              display: 'grid', gap: '3px', width: '100%', textAlign: 'left', cursor: 'pointer',
              padding: '6px var(--u2)', fontSize: 'var(--fs-sm)', lineHeight: 1.55,
              background: 'var(--panel-sunken)', border: 0,
              borderLeft: '2px solid ' + (i.severity === 'high' ? 'var(--alert)' : 'var(--ink-4)')
            }"
            @click="router.push(toProject('guard'))"
          >
            <span class="row" :style="{ gap: '6px' }">
              <span class="pill" :class="i.severity === 'high' ? 'pill-alert' : ''">
                {{ i.severity === 'high' ? '高' : '中' }}
              </span>
              <span :style="{ fontWeight: 700, color: 'var(--ink)' }">{{ i.category }}</span>
              <span :style="{ marginLeft: 'auto', color: 'var(--ink-4)' }">{{ i.chapterRef }}</span>
            </span>
            <span :style="{ color: 'var(--ink-2)' }">{{ i.title }}</span>
          </button>
          <p v-if="!guard.open.length" :style="{ margin: 0, color: 'var(--ink-3)' }">暂无提醒。</p>
        </div>
      </section>
    </template>

    <template v-else-if="tab === 'long'">
      <div class="wk-head"><span>长篇分段</span><span class="wk-head-push">整本可累计至 100 万字</span><button class="draft-refresh" type="button" title="刷新长篇计划" aria-label="刷新长篇计划" @click="loadLongPlan"><AppIcon name="restore" :size="14" /></button></div>
      <section class="long-generation-card" aria-label="长篇分段生成">
        <p class="long-generation-intro">当前计划只生成这一章；整本百万字通过多章累计。每章拆成可恢复的小段，逐段校验后再合并到候选区，关闭页面也不会丢失已保存的段落。</p>
        <div class="long-generation-fields">
          <label><span>目标字数</span><input v-model.number="longTargetWords" type="number" min="800" max="1000000" step="1000" :disabled="longPlanLocked" /></label>
          <label><span>每段字数</span><input v-model.number="longSegmentWords" type="number" min="800" max="32000" step="200" :disabled="longPlanLocked" /></label>
          <label><span>模型档位</span><select v-model="longModel"><option value="basic">均衡</option><option value="advanced">高级</option></select></label>
          <label><span>上下文</span><select v-model="longContextMode"><option value="smart">智能</option><option value="standard">标准</option><option value="deep">深度</option><option value="fast">快速</option></select></label>
        </div>
        <label class="long-generation-instruction"><span>本轮补充要求（可选）</span><textarea v-model="longInstruction" rows="3" maxlength="2000" placeholder="例如：本段必须让女主拿到第一条可验证的线索，并在结尾留下新的风险。" /></label>
        <p v-if="longPlanError" class="long-generation-error" role="alert">{{ longPlanError }}</p>
        <p v-if="longPlanLoading" class="long-generation-state" role="status">正在读取分段计划…</p>
        <template v-if="longPlan?.segments.length">
          <div class="long-generation-progress">
            <div class="row-between"><strong>{{ longCompletedCount }} / {{ longActiveCount }} 段已完成</strong><span>{{ longPlan.targetWords?.toLocaleString() ?? longTargetWords.toLocaleString() }} 字</span></div>
            <div class="long-generation-progress-bar"><span :style="{ width: `${longProgressPercent}%` }" /></div>
          </div>
          <div class="long-generation-segments">
            <div v-for="segment in longPlan.segments" :key="segment.id" class="long-generation-segment" :data-status="segment.status">
              <span class="long-generation-index">{{ String(segment.index + 1).padStart(2, '0') }}</span>
              <span class="long-generation-segment-main"><strong>{{ segment.status === 'running' ? '生成中' : segment.status === 'ready' ? '待合并' : segment.status === 'accepted' ? '已采纳' : segment.status === 'failed' ? '需要重试' : segment.status === 'skipped' ? '已跳过' : '待生成' }}</strong><small>{{ segment.generatedWords.toLocaleString() }} / {{ segment.targetWords.toLocaleString() }} 字</small></span>
              <span v-if="segment.errorCode" class="long-generation-segment-error">{{ segment.errorCode }}</span>
            </div>
          </div>
          <div class="long-generation-actions"><button v-if="!longPlanLocked" class="wk-btn" type="button" :disabled="longPlanBusy || longRunning" @click="createLongPlan">更新计划</button><button class="wk-btn" type="button" :disabled="longPlanBusy || longRunning || !longNextSegment" @click="queueLongNext">{{ longPlanBusy ? '排队中…' : longRunning ? '当前段生成中…' : longNextSegment?.status === 'failed' ? '重试当前段' : '生成下一段' }}</button><button class="wk-btn" type="button" :disabled="longPlanBusy || (!longAutoRun && (longRunning || !longNextSegment))" @click="toggleLongAutoRun">{{ longAutoRun ? '暂停连续生成' : '连续生成剩余' }}</button><button class="wk-btn" data-primary="true" type="button" :disabled="longPlanBusy || !longReadyCount" @click="mergeLongPlan">{{ longComplete ? '合并全部候选' : '合并已完成段落' }}</button></div>
          <p v-if="longAutoRun" class="long-generation-state" role="status">连续生成已开启：每段完成后自动排队下一段，遇到失败会暂停。</p>
        </template>
        <button v-else class="wk-btn" data-primary="true" type="button" :disabled="longPlanBusy || longPlanLoading || !project.activeId" @click="createLongPlan">{{ longPlanBusy ? '创建中…' : '创建长篇计划' }}</button>
      </section>
    </template>

    <template v-else-if="tab === 'drafts'">
      <div class="wk-head">
        <span>生成候选</span>
        <span class="wk-head-push">{{ props.drafts?.length ?? 0 }} 条</span>
        <button class="draft-refresh" type="button" title="刷新候选" aria-label="刷新候选" @click="emit('refreshDrafts')">
          <AppIcon name="restore" :size="14" />
        </button>
      </div>

      <div v-if="selectedDraft" class="draft-detail">
        <button class="draft-back" type="button" @click="selectedDraft = null">返回候选列表</button>
        <div class="row-between">
          <strong>{{ draftLabel(selectedDraft) }}</strong>
          <span class="pill" :class="selectedDraft.status === 'failed' ? 'pill-alert' : 'pill-soft'">
            {{ selectedDraft.status === 'streaming' ? '生成中' : selectedDraft.status === 'failed' ? '生成中断' : '待采纳' }}
          </span>
        </div>
        <div class="draft-meta">
          {{ selectedDraft.generatedWords }} 字 · {{ draftTime(selectedDraft.createdAt) }} ·
          {{ selectedDraft.review.accepted }} 接受 / {{ selectedDraft.review.rejected }} 拒绝 / {{ selectedDraft.review.pending }} 待定
        </div>
        <section v-if="selectedDraftWarnings.length" class="draft-quality" aria-label="采纳前质量检查">
          <div class="draft-quality-head">
            <strong>采纳前检查</strong>
            <span>{{ selectedDraftWarnings.length }} 项需复核</span>
          </div>
          <ul>
            <li v-for="check in selectedDraftWarnings" :key="check.id">
              <strong>{{ check.label }}</strong>
              <span>{{ check.message }}</span>
              <small v-if="check.evidence.length">{{ check.evidence.slice(0, 3).join(' · ') }}</small>
            </li>
          </ul>
        </section>
        <div v-if="selectedDraft.segments.length" class="draft-review-tools">
          <button class="wk-btn wk-btn-xs" type="button" :disabled="draftReviewBusy || selectedDraft.status === 'streaming'" @click="decideAllDraftSegments('accepted')">全部接受</button>
          <button class="wk-btn wk-btn-xs" type="button" :disabled="draftReviewBusy || selectedDraft.status === 'streaming'" @click="decideAllDraftSegments('rejected')">全部拒绝</button>
        </div>
        <div v-if="selectedDraft.segments.length" class="draft-segments" aria-label="候选段落审阅">
          <article
            v-for="segment in selectedDraft.segments"
            :key="segment.id"
            class="draft-segment"
            :data-decision="segment.decision"
          >
            <p>{{ segment.text }}</p>
            <footer>
              <span>{{ segment.decision === 'accepted' ? '已接受' : segment.decision === 'rejected' ? '已拒绝' : '待决定' }}</span>
              <button
                v-if="segment.decision !== 'accepted'"
                type="button"
                :disabled="draftReviewBusy || selectedDraft.status === 'streaming'"
                @click="decideDraftSegments([segment.id], 'accepted')"
              >接受</button>
              <button
                v-if="segment.decision !== 'rejected'"
                type="button"
                :disabled="draftReviewBusy || selectedDraft.status === 'streaming'"
                @click="decideDraftSegments([segment.id], 'rejected')"
              >拒绝</button>
              <button
                v-if="segment.decision !== 'pending'"
                type="button"
                :disabled="draftReviewBusy || selectedDraft.status === 'streaming'"
                @click="decideDraftSegments([segment.id], 'pending')"
              >撤销</button>
            </footer>
          </article>
        </div>
        <div v-else class="draft-prose">{{ selectedDraft.content || '没有可恢复的内容。' }}</div>
        <p v-if="selectedDraft.status === 'failed'" class="draft-warning">这次生成提前中断，已保留完成的部分。</p>
        <p v-else-if="selectedDraft.status === 'streaming'" class="draft-warning">候选仍在写入，完成或停止后才能处理。</p>
        <p v-if="draftDetailError" class="draft-warning" role="alert">{{ draftDetailError }}</p>
        <div class="draft-actions">
          <button
            v-if="selectedDraft.status === 'failed'"
            class="wk-btn wk-btn-xs"
            type="button"
            :disabled="draftReviewBusy || props.generating"
            @click="emit('continueDraft', selectedDraft)"
          >从末尾继续</button>
          <button class="wk-btn wk-btn-xs" type="button" :disabled="selectedDraft.status === 'streaming'" @click="rejectSelected">舍弃</button>
          <button
            class="wk-btn wk-btn-xs"
            data-primary="true"
            type="button"
            :disabled="!acceptedDraftContent || selectedDraft.review.pending > 0 || selectedDraft.status === 'streaming' || draftReviewBusy"
            @click="insertReviewedDraft"
          >放入正文检查</button>
        </div>
      </div>

      <div v-else>
        <p v-if="props.draftsLoading || draftDetailLoading" class="draft-state">正在读取候选…</p>
        <p v-else-if="draftDetailError" class="draft-state draft-state-error">{{ draftDetailError }}</p>
        <template v-else>
          <button
            v-for="draft in props.drafts"
            :key="draft.id"
            class="draft-row"
            type="button"
            @click="openDraft(draft)"
          >
            <span class="row-between">
              <strong>{{ draftLabel(draft) }}</strong>
              <span :class="draft.status === 'failed' ? 'draft-status-failed' : 'muted'">
                {{ draft.status === 'streaming' ? '生成中' : draft.status === 'failed' ? '已中断' : `${draft.generatedWords} 字` }}
              </span>
            </span>
            <span class="draft-excerpt">{{ draft.excerpt || '等待生成内容…' }}</span>
            <span class="draft-time">{{ draftTime(draft.createdAt) }}</span>
          </button>
        </template>
        <p v-if="!props.draftsLoading && !props.drafts?.length" class="draft-state">
          生成结果会保存在这里，刷新页面后仍可找回。
        </p>
      </div>
    </template>

    <template v-else-if="tab === 'refs'">
      <div v-if="selectedReference" class="reference-detail">
        <div class="reference-detail-bar">
          <button type="button" @click="selectedReferenceId = null">返回资料</button>
          <button type="button" @click="openFullReference(selectedReference)">完整档案 →</button>
        </div>
        <header class="reference-identity">
          <span class="wk-label">{{ CODEX_KIND_LABEL[selectedReference.kind] }}</span>
          <h2>{{ selectedReference.name }}</h2>
          <p v-if="selectedReference.aliases.length">又名 {{ selectedReference.aliases.join('、') }}</p>
        </header>
        <p class="reference-summary">{{ selectedReference.summary }}</p>

        <section v-if="referenceFacts.length" class="reference-section">
          <div class="wk-label">写作核对</div>
          <dl>
            <div v-for="fact in referenceFacts" :key="fact.label"><dt>{{ fact.label }}</dt><dd>{{ fact.value }}</dd></div>
          </dl>
        </section>

        <section class="reference-section">
          <div class="row-between"><span class="wk-label">本章有效状态</span><small>截至第 {{ project.active?.index ?? '—' }} 章</small></div>
          <p v-if="referenceStatesLoading" class="reference-state-message">正在读取状态…</p>
          <p v-else-if="referenceStatesError" class="reference-state-message is-error">{{ referenceStatesError }}</p>
          <dl v-else-if="effectiveReferenceStates.length" class="reference-states">
            <div v-for="item in effectiveReferenceStates" :key="item.stateKey">
              <dt>{{ item.stateKey }} <small>第 {{ item.chapterIndex }} 章</small></dt><dd>{{ item.value }}</dd>
            </div>
          </dl>
          <p v-else class="reference-state-message">当前章节之前没有作者状态记录。</p>
        </section>

        <section v-if="selectedReference.relations?.length" class="reference-section">
          <div class="wk-label">关联</div>
          <button v-for="relation in selectedReference.relations" :key="`${relation.name}-${relation.relation}`" class="reference-relation" type="button" :disabled="!relation.targetId" @click="relation.targetId && (selectedReferenceId = relation.targetId)">
            <span><strong>{{ relation.name }}</strong><small>{{ relation.relation }}</small></span><span>→</span>
          </button>
        </section>
      </div>

      <div v-else class="reference-browser">
        <div class="wk-head"><span>写作资料</span><span class="wk-head-push">{{ referenceRows.length }} 条</span></div>
        <div class="reference-tools">
          <input v-model="referenceQuery" class="wk-input" placeholder="搜索人物、地点或约束" aria-label="搜索写作资料">
          <div class="reference-scope" aria-label="资料范围">
            <button type="button" :aria-pressed="referenceScope === 'chapter'" @click="referenceScope = 'chapter'">本章 {{ refs.length }}</button>
            <button type="button" :aria-pressed="referenceScope === 'all'" @click="referenceScope = 'all'">全部 {{ codex.entries.length }}</button>
          </div>
        </div>
        <button v-for="entry in referenceRows" :key="entry.id" class="reference-row" type="button" :data-reference-id="entry.id" @click="openReference(entry)">
          <span class="reference-row-title"><strong>{{ entry.name }}</strong><span>{{ CODEX_KIND_LABEL[entry.kind] }}</span><small v-if="entry.resident">常驻</small></span>
          <span>{{ entry.summary }}</span>
        </button>
        <p v-if="!referenceRows.length" class="reference-empty">
          {{ referenceQuery ? '没有匹配资料。可按人物动机、能力或地点名搜索。' : '本章还没有显式引用。切换“全部”可查阅整本设定库。' }}
        </p>
      </div>
    </template>

    <ReviewPanel
      v-else-if="tab === 'review'"
      :workspace="reviewWorkspace"
      :anchor="reviewAnchor"
      :loading="reviewLoading"
      :busy="reviewBusy"
      :error="reviewError"
      :submit-disabled-reason="reviewSubmitDisabledReason"
      @refresh="emit('refreshReviews')"
      @submit="emit('submitReview', $event)"
      @add-comment="forwardReviewComment"
      @update-comment="forwardReviewCommentUpdate"
      @resolve-comment="forwardReviewCommentResolution"
      @decide="forwardReviewDecision"
      @locate="emit('locateReviewComment', $event)"
    />

    <template v-else>
      <div class="wk-head"><span>灵感速记</span><span class="wk-head-push">仅自己可见</span></div>
      <div class="quick-notes">
        <form class="quick-note-form" @submit.prevent="createNote">
          <textarea v-model="noteDraft" class="wk-input" maxlength="2000" rows="5" placeholder="记下突然想到的情节、对白或待核对事项。" />
          <div><small>{{ project.active ? `保存到第 ${project.active.index} 章` : '保存到当前作品' }}</small><button class="wk-btn wk-btn-xs" data-primary="true" type="submit" :disabled="!noteDraft.trim() || noteBusy">{{ noteBusy ? '保存中…' : '保存速记' }}</button></div>
        </form>
        <p v-if="noteError" class="quick-note-state is-error" role="alert">{{ noteError }}</p>
        <p v-else-if="notesLoading" class="quick-note-state" role="status">正在读取速记…</p>
        <div v-else-if="notes.length" class="quick-note-list">
          <article v-for="note in notes" :key="note.id" class="quick-note-row">
            <p>{{ note.content }}</p>
            <footer><span>{{ note.chapterIndex ? `第 ${note.chapterIndex} 章${note.chapterTitle ? ` · ${note.chapterTitle}` : ''}` : '全书' }} · {{ noteTime(note.createdAt) }}</span><button type="button" title="删除速记" aria-label="删除速记" :disabled="noteBusy" @click="deleteNote(note)"><AppIcon name="trash" :size="13" /></button></footer>
          </article>
        </div>
        <p v-else class="quick-note-state">还没有速记。这里的内容不会进入 AI 上下文。</p>
      </div>
    </template>
  </div>
</template>

<style scoped>
.prompt-preview {
  position: relative;
  z-index: 2;
  max-height: min(78vh, 760px);
  overflow: auto;
  padding: var(--u3);
  color: var(--ink-2);
  background: var(--panel-sunken);
  border-bottom: var(--hair) solid var(--line-strong);
}
.prompt-preview-head { display: flex; align-items: flex-start; justify-content: space-between; gap: var(--u3); }
.prompt-preview-head h2 { margin: 3px 0 0; color: var(--ink); font-family: var(--font-prose); font-size: 20px; font-weight: 600; }
.prompt-preview-close { width: 26px; height: 26px; padding: 0; color: var(--ink-3); background: transparent; border: 0; font-size: 20px; line-height: 1; cursor: pointer; }
.prompt-preview-close:hover { color: var(--ink); }
.prompt-preview-stale { display: flex; align-items: center; justify-content: space-between; gap: var(--u2); margin: var(--u3) 0; padding: var(--u2); color: var(--alert-ink); background: var(--alert-soft); border-left: 2px solid var(--alert); font-size: var(--fs-xs); line-height: 1.6; }
.prompt-preview-summary { display: flex; flex-wrap: wrap; gap: 6px 12px; margin: var(--u3) 0; color: var(--ink-3); font: var(--fs-xs)/1.5 var(--font-mono); }
.prompt-preview-summary span:first-child { color: var(--ink); font-family: var(--font-prose); font-size: var(--fs); }
.prompt-preview-section { padding: var(--u3) 0; border-top: var(--hair) solid var(--line); }
.prompt-skill-list { display: flex; flex-wrap: wrap; gap: 5px; margin-top: var(--u2); }
.prompt-skill { padding: 3px 6px; color: var(--ink-2); background: var(--panel); border: var(--hair) solid var(--line-strong); font: 10px/1.3 var(--font-mono); }
.prompt-skill small { color: var(--ink-4); }
.prompt-preview-note { margin: var(--u2) 0 0; color: var(--ink-3); font-size: var(--fs-xs); line-height: 1.6; }
.prompt-preview-warning { color: var(--alert-ink); }
.prompt-preview-checks { display: grid; gap: 6px; margin: 8px 0 0; padding-left: 18px; color: var(--ink-3); font-size: var(--fs-xs); line-height: 1.55; }
.prompt-preview-checks li { padding-left: 2px; }
.prompt-preview-checks strong { display: block; color: var(--ink-2); font-family: var(--font-mono); font-size: 10px; font-weight: 500; }
.prompt-preview-metric { color: var(--ink-3); font: 10px var(--font-mono); }
.context-stat-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1px;
  margin-top: var(--u2);
  background: var(--line);
  border: var(--hair) solid var(--line);
}
.context-stat-grid > span {
  min-width: 0;
  display: grid;
  gap: 2px;
  padding: 7px 8px;
  color: var(--ink-2);
  background: var(--panel);
  font: 11px/1.35 var(--font-mono);
}
.context-stat-grid small { color: var(--ink-4); font-family: var(--font-ui); font-size: 9px; }
.context-section-list { margin-top: var(--u2); border-top: var(--hair) solid var(--line); }
.context-section-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 3px var(--u2);
  padding: 7px 0;
  border-bottom: var(--hair) solid var(--line);
}
.context-section-row > span:first-child { min-width: 0; display: flex; align-items: baseline; gap: 6px; }
.context-section-row strong { overflow: hidden; color: var(--ink-2); font-size: var(--fs-xs); text-overflow: ellipsis; white-space: nowrap; }
.context-section-row small { color: var(--ink-4); font-size: 9px; }
.context-section-row > span:nth-child(2) { color: var(--ink-4); font: 10px/1.5 var(--font-mono); }
.context-section-row p { grid-column: 1 / -1; margin: 0; color: var(--alert-ink); font-size: 10px; line-height: 1.5; }
.prompt-layer, .prompt-message { margin-top: 5px; background: var(--panel); border: var(--hair) solid var(--line); }
.prompt-layer summary, .prompt-message summary { display: flex; justify-content: space-between; gap: var(--u2); padding: 7px 8px; color: var(--ink-2); font-size: var(--fs-xs); cursor: pointer; list-style: none; }
.prompt-layer summary::-webkit-details-marker, .prompt-message summary::-webkit-details-marker { display: none; }
.prompt-layer summary span:last-child { color: var(--ink-4); font: 10px var(--font-mono); }
.prompt-layer pre, .prompt-message pre { max-height: 220px; overflow: auto; margin: 0; padding: 8px; color: var(--ink-2); border-top: var(--hair) solid var(--line); font: 11px/1.7 var(--font-mono); white-space: pre-wrap; overflow-wrap: anywhere; }
.prompt-preview-state { margin: var(--u4) 0; color: var(--ink-3); font-size: var(--fs-sm); line-height: 1.7; }
.prompt-preview-error { color: var(--alert-ink); }
.prompt-preview-error p { margin: 0 0 var(--u2); }
.prompt-preview:focus-within { outline: 2px solid var(--primary-line); outline-offset: -2px; }
.draft-refresh {
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  padding: 0;
  color: var(--ink-3);
  background: transparent;
  border: 0;
  border-radius: 4px;
  cursor: pointer;
}
.draft-refresh:hover { color: var(--ink); background: var(--panel-sunken); }
.draft-refresh:focus-visible,
.draft-row:focus-visible,
.draft-back:focus-visible { outline: 2px solid var(--primary); outline-offset: -2px; }
.draft-row {
  display: grid;
  gap: 5px;
  width: 100%;
  padding: var(--u3);
  text-align: left;
  color: var(--ink);
  background: transparent;
  border: 0;
  border-bottom: var(--hair) solid var(--line);
  cursor: pointer;
}
.draft-row:hover { background: var(--panel-sunken); }
.draft-row strong { font-size: var(--fs); }
.draft-excerpt {
  display: -webkit-box;
  overflow: hidden;
  color: var(--ink-2);
  font-size: var(--fs-sm);
  line-height: 1.6;
  white-space: normal;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}
.draft-time,
.draft-meta { color: var(--ink-4); font-family: var(--font-mono); font-size: var(--fs-xs); }
.draft-status-failed { color: var(--alert-ink); font-size: var(--fs-sm); }
.draft-state { margin: 0; padding: var(--u5) var(--u3); color: var(--ink-3); line-height: 1.7; }
.draft-state-error { color: var(--alert-ink); }
.draft-detail { display: grid; gap: var(--u3); padding: var(--u3); }
.draft-quality { padding: var(--u3); color: var(--alert-ink); background: var(--alert-soft); border-left: 3px solid var(--alert); }
.draft-quality-head { display: flex; align-items: baseline; justify-content: space-between; gap: var(--u2); }
.draft-quality-head strong { font-size: var(--fs-sm); }
.draft-quality-head span { color: var(--ink-3); font: 10px/1.4 var(--font-mono); }
.draft-quality ul { display: grid; gap: var(--u2); margin: var(--u2) 0 0; padding: 0; list-style: none; }
.draft-quality li { display: grid; gap: 2px; padding-top: var(--u2); border-top: var(--hair) solid var(--line-strong); }
.draft-quality li strong { font-size: var(--fs-xs); }
.draft-quality li span { color: var(--ink-2); font-size: var(--fs-xs); line-height: 1.6; }
.draft-quality li small { color: var(--ink-4); font: 10px/1.5 var(--font-mono); overflow-wrap: anywhere; }
.draft-back {
  justify-self: start;
  padding: 0;
  color: var(--ink-3);
  background: transparent;
  border: 0;
  cursor: pointer;
}
.draft-back:hover { color: var(--ink); }
.draft-prose {
  max-height: min(52vh, 520px);
  overflow: auto;
  padding: var(--u3) 0;
  color: var(--ink-2);
  font-family: var(--font-serif);
  line-height: 1.85;
  white-space: pre-wrap;
  border-top: var(--hair) solid var(--line);
  border-bottom: var(--hair) solid var(--line);
}
.draft-review-tools { display: flex; justify-content: flex-end; gap: var(--u2); }
.draft-segments { display: grid; gap: var(--u2); max-height: min(52vh, 520px); overflow: auto; }
.draft-segment {
  display: grid;
  gap: var(--u2);
  padding: var(--u3);
  background: var(--panel-sunken);
  border-left: 3px solid var(--line-strong);
}
.draft-segment[data-decision='accepted'] { border-left-color: var(--success); }
.draft-segment[data-decision='rejected'] { color: var(--ink-4); border-left-color: var(--alert); }
.draft-segment p { margin: 0; font-family: var(--font-serif); font-size: var(--fs); line-height: 1.85; white-space: pre-wrap; }
.draft-segment[data-decision='rejected'] p { text-decoration: line-through; }
.draft-segment footer { display: flex; align-items: center; justify-content: flex-end; gap: var(--u2); color: var(--ink-4); font-size: var(--fs-xs); }
.draft-segment footer span { margin-right: auto; }
.draft-segment footer button { padding: 2px 5px; color: var(--ink-2); background: transparent; border: 0; cursor: pointer; }
.draft-segment footer button:hover { color: var(--ink); background: var(--panel); }
.draft-segment footer button:focus-visible { outline: 2px solid var(--primary); outline-offset: 1px; }
.long-generation-card { display: grid; gap: var(--u4); padding: var(--u3); border: var(--hair) solid var(--line-strong); background: var(--panel-sunken); }
.long-generation-intro { margin: 0; color: var(--ink-3); font-size: var(--fs-sm); line-height: 1.7; }
.long-generation-fields { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: var(--u3); }
.long-generation-fields label, .long-generation-instruction { display: grid; gap: 5px; color: var(--ink-3); font-size: var(--fs-xs); }
.long-generation-fields input, .long-generation-fields select, .long-generation-instruction textarea { width: 100%; min-width: 0; padding: 7px 8px; color: var(--ink); background: var(--paper); border: var(--hair) solid var(--line-strong); border-radius: 3px; font: inherit; }
.long-generation-fields input:focus, .long-generation-fields select:focus, .long-generation-instruction textarea:focus { outline: 2px solid var(--primary-soft); border-color: var(--primary); }
.long-generation-instruction textarea { resize: vertical; line-height: 1.6; }
.long-generation-error { margin: 0; padding: 7px 9px; color: var(--alert-ink); background: var(--alert-soft); border-left: 3px solid var(--alert); font-size: var(--fs-sm); line-height: 1.6; }
.long-generation-state { margin: 0; color: var(--ink-3); font-size: var(--fs-sm); }
.long-generation-progress { display: grid; gap: 7px; color: var(--ink-2); font-size: var(--fs-xs); }
.long-generation-progress-bar { height: 5px; overflow: hidden; background: var(--line); border-radius: 2px; }
.long-generation-progress-bar span { display: block; height: 100%; background: var(--primary); transition: width .25s ease; }
.long-generation-segments { display: grid; gap: 5px; max-height: 250px; overflow: auto; }
.long-generation-segment { display: grid; grid-template-columns: 28px minmax(0, 1fr) auto; align-items: center; gap: var(--u2); min-height: 42px; padding: 6px 8px; border: var(--hair) solid var(--line); background: var(--paper); }
.long-generation-segment[data-status='running'] { border-left: 3px solid var(--primary); }
.long-generation-segment[data-status='ready'], .long-generation-segment[data-status='accepted'] { border-left: 3px solid var(--success); }
.long-generation-segment[data-status='failed'] { border-left: 3px solid var(--alert); }
.long-generation-index { color: var(--ink-4); font: 700 var(--fs-xs)/1 var(--font-mono); }
.long-generation-segment-main { display: grid; gap: 2px; min-width: 0; }
.long-generation-segment-main strong { color: var(--ink-2); font-size: var(--fs-sm); }
.long-generation-segment-main small { color: var(--ink-4); font-size: var(--fs-xs); }
.long-generation-segment-error { max-width: 90px; overflow: hidden; color: var(--alert-ink); font: var(--fs-2xs)/1.3 var(--font-mono); text-overflow: ellipsis; white-space: nowrap; }
.long-generation-actions { display: flex; flex-wrap: wrap; gap: var(--u2); }
@media (max-width: 420px) { .long-generation-fields { grid-template-columns: 1fr; } }
.draft-warning { margin: 0; color: var(--alert-ink); font-size: var(--fs-sm); line-height: 1.6; }
.draft-actions { display: flex; justify-content: flex-end; gap: var(--u2); }
.generation-recovery {
  display: grid;
  gap: 7px;
  margin-top: var(--u3);
  padding: var(--u3);
  color: var(--alert-ink);
  background: var(--alert-soft);
  border-left: 3px solid var(--alert);
}
.generation-recovery-title { display: flex; align-items: baseline; gap: var(--u2); }
.generation-recovery-title strong { color: var(--alert-ink); font-size: var(--fs-sm); }
.generation-recovery p { margin: 0; font-size: var(--fs-sm); line-height: 1.65; overflow-wrap: anywhere; }
.generation-recovery-actions { display: flex; flex-wrap: wrap; gap: var(--u2); }
.generation-recovery small { color: var(--ink-3); font-size: var(--fs-xs); line-height: 1.5; }
.context-mode-field { display: grid; gap: 5px; color: var(--ink-2); }
.context-mode-control {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  min-height: 27px;
  overflow: hidden;
  border: var(--hair) solid var(--line-strong);
  border-radius: 3px;
}
.context-mode-control button {
  min-width: 0;
  padding: 0 3px;
  color: var(--ink-3);
  background: transparent;
  border: 0;
  border-left: var(--hair) solid var(--line);
  font-size: var(--fs-xs);
  cursor: pointer;
}
.context-mode-control button:first-child { border-left: 0; }
.context-mode-control button[aria-checked='true'] { color: var(--ink); background: var(--panel-sunken); font-weight: 700; }
.context-mode-control button:focus-visible { position: relative; outline: 2px solid var(--primary); outline-offset: -2px; }
.quick-notes { padding: var(--u3); }
.quick-note-form { padding-bottom: var(--u4); border-bottom: var(--hair) solid var(--line-strong); }
.quick-note-form textarea { width: 100%; min-height: 118px; padding: var(--u3); resize: vertical; line-height: 1.7; }
.quick-note-form > div { display: flex; align-items: center; justify-content: space-between; gap: var(--u3); margin-top: var(--u2); }
.quick-note-form small { color: var(--ink-4); font-size: var(--fs-xs); }
.quick-note-state { margin: 0; padding: var(--u5) 0; color: var(--ink-3); font-size: var(--fs-sm); line-height: 1.7; }
.quick-note-state.is-error { color: var(--alert-ink); }
.quick-note-list { border-top: var(--hair) solid var(--line); }
.quick-note-row { padding: var(--u3) 0; border-bottom: var(--hair) solid var(--line); }
.quick-note-row > p { margin: 0; color: var(--ink-2); font-family: var(--font-prose); font-size: 14px; line-height: 1.72; white-space: pre-wrap; overflow-wrap: anywhere; }
.quick-note-row footer { display: flex; align-items: center; justify-content: space-between; gap: var(--u2); margin-top: var(--u2); color: var(--ink-4); font: 10px/1.4 var(--font-mono); }
.quick-note-row footer span { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.quick-note-row footer button { width: 26px; height: 26px; flex: none; display: grid; place-items: center; padding: 0; border: 0; color: var(--ink-4); background: transparent; cursor: pointer; }
.quick-note-row footer button:hover { color: var(--alert-ink); background: var(--alert-soft); }
.reference-tools { display: grid; gap: var(--u2); padding: var(--u3); border-bottom: var(--hair) solid var(--line); }
.reference-tools .wk-input { width: 100%; }
.reference-scope { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); height: 27px; border: var(--hair) solid var(--line-strong); border-radius: 3px; overflow: hidden; }
.reference-scope button { min-width: 0; padding: 0 var(--u2); border: 0; border-left: var(--hair) solid var(--line); color: var(--ink-3); background: transparent; font-size: var(--fs-xs); cursor: pointer; }
.reference-scope button:first-child { border-left: 0; }
.reference-scope button[aria-pressed='true'] { color: var(--ink); background: var(--panel-sunken); font-weight: 700; }
.reference-row { width: 100%; min-width: 0; display: grid; gap: 5px; padding: 11px var(--u3); border: 0; border-bottom: var(--hair) solid var(--line); color: var(--ink-3); background: transparent; text-align: left; cursor: pointer; }
.reference-row:hover { background: var(--panel-sunken); }
.reference-row > span:last-child { display: -webkit-box; overflow: hidden; font-size: var(--fs-sm); line-height: 1.55; white-space: normal; -webkit-box-orient: vertical; -webkit-line-clamp: 2; }
.reference-row-title { min-width: 0; display: flex; align-items: center; gap: 5px; }
.reference-row-title strong { overflow: hidden; color: var(--ink); font-size: var(--fs); text-overflow: ellipsis; white-space: nowrap; }
.reference-row-title span, .reference-row-title small { flex: none; padding: 1px 4px; border: var(--hair) solid var(--line); color: var(--ink-4); font-size: 9px; }
.reference-row-title small { border-color: var(--primary-line); color: var(--primary); }
.reference-empty { margin: 0; padding: var(--u5) var(--u3); color: var(--ink-3); font-size: var(--fs-sm); line-height: 1.7; }
.reference-detail { min-width: 0; padding-bottom: var(--u6); }
.reference-detail-bar { min-height: 36px; display: flex; align-items: center; justify-content: space-between; gap: var(--u2); padding: 0 var(--u3); border-bottom: var(--hair) solid var(--line); }
.reference-detail-bar button { padding: 0; border: 0; color: var(--ink-3); background: transparent; font-size: var(--fs-xs); cursor: pointer; }
.reference-detail-bar button:hover { color: var(--primary); }
.reference-identity { padding: var(--u4) var(--u3) var(--u3); }
.reference-identity h2 { margin: 5px 0 0; font-family: var(--font-prose); font-size: 24px; font-weight: 600; }
.reference-identity p { margin: 4px 0 0; color: var(--ink-4); font-size: var(--fs-xs); }
.reference-summary { margin: 0; padding: 0 var(--u3) var(--u4); color: var(--ink-2); font-family: var(--font-prose); font-size: 14px; line-height: 1.75; overflow-wrap: anywhere; }
.reference-section { padding: var(--u3); border-top: var(--hair) solid var(--line-strong); }
.reference-section > .row-between small { color: var(--ink-4); font: 9px/1.4 var(--font-mono); }
.reference-section dl { margin: var(--u2) 0 0; }
.reference-section dl > div { padding: 8px 0; border-bottom: var(--hair) solid var(--line); }
.reference-section dt { color: var(--ink-4); font-size: 9px; font-weight: 700; }
.reference-section dd { margin: 3px 0 0; color: var(--ink-2); font-size: var(--fs-sm); line-height: 1.55; overflow-wrap: anywhere; }
.reference-states dt { color: var(--primary); }
.reference-states dt small { margin-left: 4px; color: var(--ink-4); font-family: var(--font-mono); font-weight: 400; }
.reference-state-message { margin: var(--u2) 0 0; color: var(--ink-3); font-size: var(--fs-sm); line-height: 1.6; }
.reference-state-message.is-error { color: var(--alert-ink); }
.reference-relation { width: 100%; min-width: 0; display: flex; align-items: center; justify-content: space-between; gap: var(--u2); padding: 8px 0; border: 0; border-bottom: var(--hair) solid var(--line); color: var(--ink-3); background: transparent; text-align: left; cursor: pointer; }
.reference-relation > span:first-child { min-width: 0; display: grid; gap: 2px; }
.reference-relation strong { color: var(--ink); font-size: var(--fs-sm); }
.reference-relation small { color: var(--ink-4); font-size: 9px; }
.reference-relation:hover { color: var(--primary); }
.reference-relation:disabled { cursor: default; opacity: .6; }
.reference-row:focus-visible, .reference-detail-bar button:focus-visible, .reference-relation:focus-visible, .reference-scope button:focus-visible { outline: 2px solid var(--primary); outline-offset: -2px; }
</style>
