<script setup lang="ts">
import { computed, onUnmounted, reactive, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import AppIcon from '@/components/ui/AppIcon.vue'
import { useCodexStore } from '@/stores/codex'
import { useShellStore } from '@/stores/shell'
import { useStoryboardStore } from '@/stores/storyboard'
import { useProjectStore } from '@/stores/project'
import type { CodexEntry, ProductionPackageIssue, StoryboardAsset, StoryboardShot, VisualProfile } from '@/types'

const route = useRoute()
const shell = useShellStore()
const codex = useCodexStore()
const storyboard = useStoryboardStore()
const project = useProjectStore()
const profileEditOpen = ref(false)
const savedNotice = ref('')
const episodeCreateOpen = ref(false)
const sceneEditOpen = ref(false)
const sceneCreateMode = ref(false)
const profileCreateOpen = ref(false)
const assetUploading = ref(false)
const assetUploadError = ref('')
const assetReview = ref<StoryboardAsset | null>(null)
const assetRejectionReason = ref('')
const imageConfirmOpen = ref(false)
const fullBodyConfirmOpen = ref(false)
const selectedCharacterId = ref<string | null>(null)
const assetInput = ref<HTMLInputElement | null>(null)
const profileAssetInput = ref<HTMLInputElement | null>(null)
const episodeDraft = reactive({ title: '', sourceChapterIds: [] as string[], targetDuration: 90 })
const sceneDraft = reactive({ purpose: '', summary: '', timeAnchor: '', locationEntryId: '', characterEntryIds: [] as string[] })
const profileDraft = reactive({ codexEntryId: '', displayName: '', style: '', appearance: '', costume: '' })

const projectId = computed(() => typeof route.params.projectId === 'string' ? route.params.projectId : 'p1')
const episodes = computed(() => storyboard.adaptation?.episodes ?? [])
const scenes = computed(() => storyboard.selectedEpisode?.scenes ?? [])
const shots = computed(() => storyboard.selectedScene?.shots ?? [])
const shotAssets = computed(() => storyboard.assets.filter((asset) => asset.shotId === storyboard.selectedShot?.id))
const activeImageJob = computed(() => storyboard.imageJobs.find((job) => job.status === 'queued' || job.status === 'running'))
const characterEntries = computed(() => codex.entries.filter((entry) => entry.kind === 'character' && entry.status === 'confirmed'))
const locationEntries = computed(() => codex.entries.filter((entry) => entry.kind === 'place' && entry.status === 'confirmed'))
const profileCandidates = computed(() => characterEntries.value.filter((entry) => !storyboard.adaptation?.visualProfiles.some((profile) => profile.codexEntryId === entry.id)))
type ProfileOption = { id: string; character: CodexEntry; profile: VisualProfile | null; inScene: boolean }
const sceneCharacters = computed(() => (storyboard.selectedScene?.characterEntryIds ?? [])
  .map((id) => ({
    id,
    character: codex.byId.get(id),
    profile: storyboard.adaptation?.visualProfiles.find((profile) => profile.codexEntryId === id) ?? null,
    inScene: true
  }))
  .filter((item) => item.character))
const profileOptions = computed(() => {
  const options = new Map<string, ProfileOption>()
  sceneCharacters.value.forEach((item) => {
    if (item.character) options.set(item.id, { id: item.id, character: item.character, profile: item.profile, inScene: true })
  })
  for (const profile of storyboard.adaptation?.visualProfiles ?? []) {
    const character = codex.byId.get(profile.codexEntryId)
    if (!character) continue
    const existing = options.get(profile.codexEntryId)
    options.set(profile.codexEntryId, {
      id: profile.codexEntryId,
      character,
      profile,
      inScene: existing?.inScene ?? false
    })
  }
  return [...options.values()]
})
const activeCharacterId = computed(() => profileOptions.value.some((item) => item.id === selectedCharacterId.value)
  ? selectedCharacterId.value
  : profileOptions.value[0]?.id ?? null)
const activeCharacter = computed(() => profileOptions.value.find((item) => item.id === activeCharacterId.value)?.character ?? null)
const activeProfile = computed(() => profileOptions.value.find((item) => item.id === activeCharacterId.value)?.profile ?? null)
const profileAssets = computed(() => activeProfile.value
  ? storyboard.assets.filter((asset) => asset.visualProfileId === activeProfile.value!.id && asset.kind === 'character_sheet')
  : [])
const fullBodyAsset = computed(() => [...profileAssets.value].reverse().find((asset) => asset.status !== 'rejected'))
const profileJobs = computed(() => storyboard.fullBodyJobs.filter((job) => job.visual_profile_id === activeProfile.value?.id))
const activeFullBodyJob = computed(() => profileJobs.value.find((job) => job.status === 'queued' || job.status === 'running'))
const latestFullBodyJob = computed(() => activeFullBodyJob.value ?? profileJobs.value[0])
const activeCharacters = computed(() => (storyboard.selectedScene?.characterEntryIds ?? []).map((id) => codex.byId.get(id)).filter(Boolean))
const locationName = computed(() => {
  const id = storyboard.selectedScene?.locationEntryId
  return id ? codex.byId.get(id)?.name ?? '未关联地点' : '未关联地点'
})

watch(projectId, async (id) => {
  shell.setCrumb('漫剧 · 人物与分镜')
  selectedCharacterId.value = null
  fullBodyConfirmOpen.value = false
  imageConfirmOpen.value = false
  assetReview.value = null
  episodeCreateOpen.value = false
  sceneEditOpen.value = false
  profileCreateOpen.value = false
  try {
    await Promise.all([codex.load(id), project.load(id), storyboard.load(id)])
  } catch {
    if (projectId.value === id) storyboard.error = '漫剧资料加载失败，请刷新重试'
  }
}, { immediate: true })

const imagePollTimer = window.setInterval(() => {
  const shotId = storyboard.selectedShotId
  if (shotId && activeImageJob.value) void storyboard.loadImageJobs(shotId)
  const profileId = activeProfile.value?.id
  if (profileId && activeFullBodyJob.value) void storyboard.loadFullBodyJobs(profileId)
}, 3000)

onUnmounted(() => {
  window.clearInterval(imagePollTimer)
  storyboard.selectVisualProfile(null)
  storyboard.clearAssetPreviews()
})

watch(() => storyboard.selectedSceneId, () => {
  sceneEditOpen.value = false
  sceneCreateMode.value = false
  selectedCharacterId.value = null
})

watch(() => storyboard.selectedShotId, (shotId) => {
  imageConfirmOpen.value = false
  assetReview.value = null
  storyboard.imagePreview = null
  storyboard.imageJobs = []
  storyboard.generationError = ''
  if (shotId) void storyboard.loadImageJobs(shotId)
})

watch(() => activeProfile.value?.id, (profileId) => {
  fullBodyConfirmOpen.value = false
  storyboard.selectVisualProfile(profileId ?? null)
  if (profileId) {
    void storyboard.loadFullBodyJobs(profileId)
    const asset = storyboard.assets.find((item) => item.visualProfileId === profileId && item.kind === 'character_sheet')
    if (asset) void storyboard.loadAssetPreview(projectId.value, asset)
  }
}, { immediate: true })

watch(shotAssets, (assets) => {
  assets.forEach((asset) => { void storyboard.loadAssetPreview(projectId.value, asset) })
}, { immediate: true })

watch(profileAssets, (assets) => {
  assets.forEach((asset) => { void storyboard.loadAssetPreview(projectId.value, asset) })
}, { immediate: true })

function showSaved(message = '已保存') {
  savedNotice.value = message
  window.setTimeout(() => { savedNotice.value = '' }, 1300)
}

function issueTarget(issue: ProductionPackageIssue) {
  const episode = storyboard.selectedEpisode
  if (!episode) return ''
  const scene = episode.scenes.find((item) => item.id === issue.entity_id || item.shots.some((shot) => shot.id === issue.entity_id || shot.referenceAssetIds.includes(issue.entity_id)) || (issue.entity_type === 'character' && item.characterEntryIds.includes(issue.entity_id)))
  if (issue.entity_type === 'character') return codex.byId.get(issue.entity_id)?.name ?? '人物'
  if (issue.entity_type === 'episode') return '本集'
  if (issue.entity_type === 'scene') return `场 ${scene?.order ?? '-'}`
  const shot = scene?.shots.find((item) => item.id === issue.entity_id || item.referenceAssetIds.includes(issue.entity_id))
  return `场 ${scene?.order ?? '-'} · 镜头 ${shot?.order ?? '-'}`
}

function focusIssue(issue: ProductionPackageIssue) {
  const episode = storyboard.selectedEpisode
  if (issue.entity_type === 'character') selectedCharacterId.value = issue.entity_id
  const scene = episode?.scenes.find((item) => item.id === issue.entity_id || item.shots.some((shot) => shot.id === issue.entity_id || shot.referenceAssetIds.includes(issue.entity_id)) || (issue.entity_type === 'character' && item.characterEntryIds.includes(issue.entity_id)))
  if (!scene) return
  storyboard.selectScene(scene.id)
  if (issue.entity_type === 'shot') storyboard.selectedShotId = scene.shots.find((shot) => shot.id === issue.entity_id || shot.referenceAssetIds.includes(issue.entity_id))?.id ?? null
}

function downloadProductionPackage() {
  const data = storyboard.productionPackage
  if (!data || data.episode.id !== storyboard.selectedEpisode?.id) return
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json;charset=utf-8' }))
  const link = document.createElement('a')
  link.href = url
  link.download = `漫剧-第${String(data.episode.number).padStart(2, '0')}集-制作包.json`
  link.click()
  URL.revokeObjectURL(url)
  showSaved('制作包已下载')
}

function openEpisodeCreate() {
  const number = episodes.value.length + 1
  Object.assign(episodeDraft, { title: `第 ${number} 集 · 待命名`, sourceChapterIds: [], targetDuration: 90 })
  storyboard.clearError()
  episodeCreateOpen.value = true
}

async function createEpisode() {
  if (!episodeDraft.title.trim() || !episodeDraft.sourceChapterIds.length) return
  const episode = await storyboard.createEpisode(projectId.value, {
    title: episodeDraft.title.trim(),
    sourceChapterIds: [...episodeDraft.sourceChapterIds],
    targetDuration: Math.max(1, Math.min(1800, episodeDraft.targetDuration || 90))
  })
  if (!episode) return
  episodeCreateOpen.value = false
  showSaved('漫剧集已创建')
}

function openSceneCreate() {
  Object.assign(sceneDraft, { purpose: '', summary: '', timeAnchor: '', locationEntryId: '', characterEntryIds: [] })
  storyboard.clearError()
  sceneCreateMode.value = true
  sceneEditOpen.value = true
}

function openSceneEdit() {
  const scene = storyboard.selectedScene
  if (!scene) return
  Object.assign(sceneDraft, {
    purpose: scene.purpose,
    summary: scene.summary,
    timeAnchor: scene.timeAnchor,
    locationEntryId: scene.locationEntryId ?? '',
    characterEntryIds: [...scene.characterEntryIds]
  })
  storyboard.clearError()
  sceneCreateMode.value = false
  sceneEditOpen.value = true
}

async function saveScene() {
  if (!sceneDraft.purpose.trim()) return
  const creating = sceneCreateMode.value
  const payload = {
    purpose: sceneDraft.purpose.trim(),
    summary: sceneDraft.summary.trim(),
    timeAnchor: sceneDraft.timeAnchor.trim(),
    locationEntryId: sceneDraft.locationEntryId || undefined,
    characterEntryIds: [...sceneDraft.characterEntryIds]
  }
  const result = creating
    ? await storyboard.createScene(projectId.value, payload)
    : await storyboard.updateScene(projectId.value, payload)
  if (!result) return
  sceneEditOpen.value = false
  showSaved(creating ? '场景已创建' : '场景已保存')
}

function openProfileCreate(characterId?: string) {
  const entry = characterEntries.value.find((item) => item.id === characterId) ?? profileCandidates.value[0]
  Object.assign(profileDraft, { codexEntryId: entry?.id ?? '', displayName: entry?.name ?? '', style: '', appearance: '', costume: '' })
  storyboard.clearError()
  profileCreateOpen.value = true
}

function selectCharacter(characterId: string) {
  selectedCharacterId.value = characterId
  profileEditOpen.value = false
  assetReview.value = null
}

function selectProfileCharacter(id: string) {
  profileDraft.codexEntryId = id
  profileDraft.displayName = characterEntries.value.find((item) => item.id === id)?.name ?? ''
}

async function createVisualProfile() {
  if (!profileDraft.codexEntryId || !profileDraft.displayName.trim()) return
  const profile = await storyboard.createVisualProfile(projectId.value, {
    codexEntryId: profileDraft.codexEntryId,
    displayName: profileDraft.displayName.trim(),
    style: profileDraft.style.trim(),
    appearance: profileDraft.appearance.trim(),
    costume: profileDraft.costume.trim()
  })
  if (!profile) return
  profileCreateOpen.value = false
  showSaved('人物视觉档案已创建')
}

function shotLabel(shot: StoryboardShot) {
  const names: Record<StoryboardShot['shotType'], string> = { wide: '远景', medium: '中景', close: '近景', detail: '特写', overhead: '俯拍' }
  return names[shot.shotType]
}

async function updateShot<K extends keyof StoryboardShot>(key: K, value: StoryboardShot[K]) {
  const updated = await storyboard.updateShot(projectId.value, { [key]: value })
  if (updated) showSaved()
}

async function toggleShotStatus(shot: StoryboardShot) {
  await updateShot('status', shot.status === 'approved' ? 'draft' : 'approved')
}

async function toggleProfileLock(profile: VisualProfile) {
  const updated = await storyboard.updateVisualProfile(projectId.value, profile.id, { locked: !profile.locked })
  if (updated) showSaved()
}

async function profileField(profile: VisualProfile, key: 'style' | 'appearance' | 'costume', event: Event) {
  const value = (event.target as HTMLInputElement).value
  const updated = await storyboard.updateVisualProfile(projectId.value, profile.id, { [key]: value })
  if (updated) showSaved()
}

async function uploadShotAsset(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  input.value = ''
  if (!file || !storyboard.selectedShot) return
  assetUploadError.value = ''
  assetUploading.value = true
  const asset = await storyboard.uploadAsset(projectId.value, file, storyboard.selectedShot.id)
  assetUploading.value = false
  if (!asset) {
    assetUploadError.value = storyboard.error || '图片上传失败'
    return
  }
  await storyboard.loadAssetPreview(projectId.value, asset)
  showSaved('画面素材已上传，待确认')
}

async function uploadProfileAsset(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  input.value = ''
  const profileId = activeProfile.value?.id
  if (!file || !profileId) return
  assetUploadError.value = ''
  assetUploading.value = true
  const asset = await storyboard.uploadCharacterSheet(projectId.value, file, profileId)
  assetUploading.value = false
  if (!asset) {
    assetUploadError.value = storyboard.error || '全身图上传失败'
    return
  }
  await storyboard.loadAssetPreview(projectId.value, asset)
  showSaved('全身设定图已上传，待确认')
}

async function openAssetReview(asset: StoryboardAsset) {
  assetReview.value = asset
  assetRejectionReason.value = asset.rejectionReason ?? ''
  await storyboard.loadAssetPreview(projectId.value, asset)
}

async function saveAssetReview(status: StoryboardAsset['status']) {
  const asset = assetReview.value
  if (!asset) return
  const updated = await storyboard.approveAsset(projectId.value, asset.id, status, status === 'rejected' ? assetRejectionReason.value.trim() : undefined)
  if (updated) {
    assetReview.value = null
    showSaved(status === 'approved' ? '画面已确认' : '画面已退回')
  }
}

function shotImage(shotId: string) {
  const asset = [...storyboard.assets].reverse().find((item) => item.shotId === shotId && item.status !== 'rejected')
  return asset ? storyboard.assetPreviewUrls[asset.id] : undefined
}

function imageIssueLabel(issue: string) {
  if (issue === 'visual_prompt_missing') return '先填写画面提示词'
  if (issue.startsWith('visual_profile_not_ready:')) return '出场人物的视觉档案需填写外观并锁定'
  if (issue === 'image_price_not_configured') return '管理员尚未配置出图价格'
  if (issue === 'image_gateway_not_configured') return '管理员尚未配置图片网关'
  if (issue === 'visual_profile_unlocked') return '请先锁定人物视觉档案'
  if (issue === 'visual_profile_appearance_missing') return '先补充人物外观锚点'
  if (issue === 'visual_profile_costume_missing') return '先补充人物服装与道具'
  return issue
}

function imageJobLabel(status: string, errorCode: string | null) {
  if (status === 'failed' && errorCode === 'image_provider_forbidden') return '图片网关未开通，额度已返还'
  if (status === 'failed' && errorCode === 'image_provider_rate_limited') return '网关限流，额度已返还'
  if (status === 'failed' && errorCode === 'image_job_timeout') return '生成超时，额度已返还'
  return ({ queued: '排队中', running: '生成中', completed: '已生成，待审阅', failed: '生成失败，额度已返还', cancelled: '已取消，额度已返还' } as Record<string, string>)[status] ?? status
}

async function openImageConfirmation() {
  const shotId = storyboard.selectedShotId
  if (!shotId) return
  const preview = await storyboard.prepareImageGeneration(shotId)
  if (preview && storyboard.selectedShotId === shotId) imageConfirmOpen.value = true
}

async function confirmImageGeneration() {
  const shotId = storyboard.selectedShotId
  if (!shotId) return
  const job = await storyboard.confirmImageGeneration(shotId)
  if (job) {
    imageConfirmOpen.value = false
    showSaved('出图任务已提交')
  }
}

async function openFullBodyConfirmation() {
  const profileId = activeProfile.value?.id
  if (!profileId) return
  const preview = await storyboard.prepareFullBodyGeneration(profileId)
  if (preview && activeProfile.value?.id === profileId) fullBodyConfirmOpen.value = true
}

async function confirmFullBodyGeneration() {
  const profileId = activeProfile.value?.id
  if (!profileId) return
  const job = await storyboard.confirmFullBodyGeneration(profileId)
  if (job) {
    fullBodyConfirmOpen.value = false
    showSaved('全身设定图任务已提交')
  }
}

async function cancelImageJob(jobId: string) {
  if (await storyboard.cancelImageGeneration(jobId)) showSaved('任务已取消，额度已返还')
}

async function moveScene(sceneId: string, direction: -1 | 1) {
  if (await storyboard.moveScene(projectId.value, sceneId, direction)) showSaved('场景顺序已保存')
}

async function moveShot(shotId: string, direction: -1 | 1) {
  if (await storyboard.moveShot(projectId.value, shotId, direction)) showSaved('镜头顺序已保存')
}
</script>

<template>
  <div class="storyboard-view">
    <header class="storyboard-head">
      <div>
        <span class="wk-label">改编工作台 / 静态阶段</span>
        <h1>{{ storyboard.adaptation?.title ?? '漫剧改编' }}</h1>
        <p>锁定人物与镜头语言，逐镜头整理画面资产。</p>
      </div>
      <div class="storyboard-head-meta">
        <span class="storyboard-ratio">{{ storyboard.adaptation?.aspectRatio ?? '9:16' }}</span>
        <span>{{ episodes.length }} 集</span>
        <span>{{ storyboard.totalShots }} 镜头</span>
        <span class="storyboard-saved" aria-live="polite">{{ savedNotice }}</span>
      </div>
    </header>
    <div v-if="storyboard.error" class="storyboard-error" role="alert">
      <span>{{ storyboard.error }}</span>
      <button type="button" aria-label="关闭错误" @click="storyboard.clearError"><AppIcon name="close" :size="14" /></button>
    </div>

    <div class="storyboard-layout">
      <aside class="storyboard-outline" aria-label="漫剧集与场景">
        <div class="storyboard-pane-head">
          <div><span class="wk-label">脚本结构</span><strong>集与场景</strong></div>
          <button class="icon-button" type="button" title="新建集" aria-label="新建集" :disabled="storyboard.saving" @click="openEpisodeCreate"><AppIcon name="plus" :size="15" /></button>
        </div>

        <div class="storyboard-tree">
          <section v-for="episode in episodes" :key="episode.id" class="storyboard-episode">
            <button class="storyboard-episode-row" type="button" :aria-selected="episode.id === storyboard.selectedEpisodeId" @click="storyboard.selectEpisode(episode.id)">
              <span class="episode-index">{{ String(episode.number).padStart(2, '0') }}</span>
              <span><strong>{{ episode.title }}</strong><small>{{ episode.targetDuration }} 秒 · {{ episode.scenes.length }} 场 · {{ episode.sourceChapterIds.length }} 章</small></span>
              <span class="storyboard-status" :data-status="episode.status">{{ episode.status === 'in_review' ? '审阅' : '草稿' }}</span>
            </button>
            <div v-if="episode.id === storyboard.selectedEpisodeId" class="storyboard-scene-list">
              <div v-for="(scene, index) in episode.scenes" :key="scene.id" class="storyboard-scene-item">
                <button class="storyboard-scene-row" type="button" :aria-selected="scene.id === storyboard.selectedSceneId" @click="storyboard.selectScene(scene.id)">
                  <span class="scene-index">场 {{ scene.order }}</span>
                  <span><strong>{{ scene.purpose || '未命名场景' }}</strong><small>{{ scene.shots.length }} 镜头 · {{ scene.timeAnchor || '时间待定' }}</small></span>
                </button>
                <div class="storyboard-order-controls">
                  <button type="button" :title="`上移场 ${scene.order}`" :aria-label="`上移场 ${scene.order}`" :disabled="index === 0 || storyboard.saving" @click="moveScene(scene.id, -1)"><AppIcon name="chevron" :size="13" /></button>
                  <button type="button" :title="`下移场 ${scene.order}`" :aria-label="`下移场 ${scene.order}`" :disabled="index === episode.scenes.length - 1 || storyboard.saving" @click="moveScene(scene.id, 1)"><AppIcon name="chevron" :size="13" /></button>
                </div>
              </div>
              <button class="storyboard-add-scene" type="button" :disabled="storyboard.saving" @click="openSceneCreate"><AppIcon name="plus" :size="13" /> 添加场景</button>
            </div>
          </section>
          <p v-if="!episodes.length" class="storyboard-empty">还没有漫剧集，从第一集开始拆分小说章节。</p>
        </div>

        <div class="storyboard-outline-note">
          <span class="wk-label">工作原则</span>
          <p>每个镜头都引用 Codex 条目，不直接复制人物名字。后续生成图片时会沿用视觉档案版本。</p>
        </div>
      </aside>

      <main class="storyboard-canvas" aria-label="分镜序列">
        <div class="storyboard-canvas-head">
          <div>
            <span class="wk-label">{{ storyboard.selectedEpisode ? `第 ${storyboard.selectedEpisode.number} 集 / 场 ${storyboard.selectedScene?.order ?? '-'}` : '未选择场景' }}</span>
            <h2>{{ storyboard.selectedScene?.purpose || '选择一个场景开始分镜' }}</h2>
            <p>{{ storyboard.selectedScene?.summary || '场景摘要会出现在这里，帮助编剧和画面设计保持同一叙事目标。' }}</p>
          </div>
          <div class="storyboard-canvas-actions">
            <button class="wk-btn" type="button" :disabled="!storyboard.selectedScene || storyboard.saving" @click="openSceneEdit">编辑场景</button>
            <button class="wk-btn" type="button" data-primary="true" :disabled="!storyboard.selectedScene || storyboard.saving" @click="storyboard.createShot(projectId)"><AppIcon name="plus" :size="14" /> 添加镜头</button>
          </div>
        </div>

        <section v-if="storyboard.selectedEpisode" class="storyboard-production" aria-label="本集制作检查">
          <div class="storyboard-production-head">
            <div class="storyboard-production-title">
              <span class="wk-label">本集制作</span>
              <strong>分镜就绪检查</strong>
              <span v-if="storyboard.productionPackage" class="storyboard-production-status" :data-ready="storyboard.productionPackage.readiness.ready">
                {{ storyboard.productionPackage.readiness.ready ? '可进入制作' : '待补齐' }}
              </span>
            </div>
            <div class="storyboard-production-actions">
              <button class="wk-btn" type="button" :disabled="storyboard.loading || storyboard.checking || storyboard.saving" @click="storyboard.checkProductionPackage(projectId)"><AppIcon name="check" :size="14" /> {{ storyboard.checking ? '检查中…' : '检查本集' }}</button>
              <button class="wk-btn" type="button" :disabled="!storyboard.productionPackage || storyboard.saving" @click="downloadProductionPackage"><AppIcon name="export" :size="14" /> 下载制作包</button>
            </div>
          </div>
          <div v-if="storyboard.productionPackage" class="storyboard-production-result" aria-live="polite">
            <div class="storyboard-production-summary">
              <span>镜头 {{ storyboard.productionPackage.scenes.reduce((total, scene) => total + scene.shots.length, 0) }}</span>
              <span>合计 {{ storyboard.productionPackage.readiness.total_duration }} / {{ storyboard.productionPackage.readiness.target_duration }} 秒</span>
              <span>{{ storyboard.productionPackage.readiness.issues.filter((issue) => issue.severity === 'blocking').length }} 项待处理</span>
            </div>
            <p v-if="!storyboard.productionPackage.readiness.issues.length" class="storyboard-production-clear">人物档案、镜头确认和画面提示均已齐备。</p>
            <ul v-else class="storyboard-production-issues">
              <li v-for="(issue, index) in storyboard.productionPackage.readiness.issues" :key="`${issue.code}-${issue.entity_id}-${index}`" :data-severity="issue.severity">
                <button type="button" :disabled="issue.entity_type === 'episode'" @click="focusIssue(issue)"><span>{{ issueTarget(issue) }}</span>{{ issue.message }}</button>
              </li>
            </ul>
          </div>
        </section>

        <form v-if="sceneEditOpen" class="storyboard-scene-editor" @submit.prevent="saveScene">
          <div class="scene-editor-heading"><strong>{{ sceneCreateMode ? '新建场景' : '编辑场景绑定' }}</strong><button type="button" aria-label="关闭场景编辑" @click="sceneEditOpen = false"><AppIcon name="close" :size="14" /></button></div>
          <label>叙事任务<input v-model="sceneDraft.purpose" maxlength="200" required placeholder="这一场必须完成什么" /></label>
          <label>场景摘要<textarea v-model="sceneDraft.summary" rows="2" placeholder="冲突、转折和离场状态" /></label>
          <div class="scene-editor-columns">
            <label>时间锚点<input v-model="sceneDraft.timeAnchor" maxlength="100" placeholder="次日清晨 / 三年前" /></label>
            <label>地点<select v-model="sceneDraft.locationEntryId"><option value="">未绑定</option><option v-for="entry in locationEntries" :key="entry.id" :value="entry.id">{{ entry.name }}</option></select></label>
          </div>
          <fieldset><legend>出场人物</legend><label v-for="entry in characterEntries" :key="entry.id" class="scene-character-option"><input v-model="sceneDraft.characterEntryIds" type="checkbox" :value="entry.id" /><span>{{ entry.name }}</span></label><p v-if="!characterEntries.length">设定库还没有已确认人物。</p></fieldset>
          <div class="scene-editor-actions"><button class="wk-btn" type="button" @click="sceneEditOpen = false">取消</button><button class="wk-btn" data-primary="true" type="submit" :disabled="storyboard.saving || !sceneDraft.purpose.trim()">{{ storyboard.saving ? '保存中…' : '保存场景' }}</button></div>
        </form>

        <div class="storyboard-filmstrip" :data-empty="!shots.length">
          <article v-for="(shot, index) in shots" :key="shot.id" class="storyboard-shot" :data-selected="shot.id === storyboard.selectedShotId" @click="storyboard.selectedShotId = shot.id">
            <button class="storyboard-frame" type="button" :data-has-image="!!shotImage(shot.id)" :aria-label="`选择第 ${shot.order} 个镜头`" @click.stop="storyboard.selectedShotId = shot.id">
              <img v-if="shotImage(shot.id)" class="storyboard-frame-image" :src="shotImage(shot.id)" alt="" />
              <span class="frame-corner frame-corner-tl" /><span class="frame-corner frame-corner-br" />
              <span class="frame-number">{{ String(shot.order).padStart(2, '0') }}</span>
              <span class="frame-glyph">{{ shotLabel(shot) }}</span>
              <span class="frame-caption">{{ shot.durationTarget }}s</span>
            </button>
            <div class="storyboard-shot-meta">
              <strong>{{ shot.action || '镜头动作待填写' }}</strong>
              <small>{{ shot.camera }} · {{ shot.status === 'approved' ? '已确认' : '草稿' }}</small>
              <div class="storyboard-shot-order">
                <button type="button" :title="`前移镜头 ${shot.order}`" :aria-label="`前移镜头 ${shot.order}`" :disabled="index === 0 || storyboard.saving" @click.stop="moveShot(shot.id, -1)"><AppIcon name="collapse" :size="14" /></button>
                <button type="button" :title="`后移镜头 ${shot.order}`" :aria-label="`后移镜头 ${shot.order}`" :disabled="index === shots.length - 1 || storyboard.saving" @click.stop="moveShot(shot.id, 1)"><AppIcon name="chevron" :size="14" /></button>
              </div>
            </div>
          </article>
          <div v-if="!shots.length" class="storyboard-empty-canvas">
            <span class="empty-mark">+</span>
            <strong>先添加一个镜头</strong>
            <p>镜头会按顺序排列，点击后在右侧编辑景别、动作、对白和画面提示词。</p>
          </div>
        </div>

        <div v-if="storyboard.selectedShot" class="storyboard-shot-editor">
          <div class="storyboard-editor-head">
            <div><span class="wk-label">镜头 {{ String(storyboard.selectedShot.order).padStart(2, '0') }}</span><strong>{{ shotLabel(storyboard.selectedShot) }}</strong></div>
            <button class="wk-btn" type="button" :data-primary="storyboard.selectedShot.status !== 'approved'" @click="toggleShotStatus(storyboard.selectedShot)">{{ storyboard.selectedShot.status === 'approved' ? '退回草稿' : '确认镜头' }}</button>
          </div>
          <div class="storyboard-editor-grid">
            <label>景别<select :value="storyboard.selectedShot.shotType" @change="updateShot('shotType', ($event.target as HTMLSelectElement).value as StoryboardShot['shotType'])"><option value="wide">远景</option><option value="medium">中景</option><option value="close">近景</option><option value="detail">特写</option><option value="overhead">俯拍</option></select></label>
            <label>镜头运动<input :value="storyboard.selectedShot.camera" @change="updateShot('camera', ($event.target as HTMLInputElement).value)" /></label>
            <label>目标时长（秒）<input type="number" min="1" max="120" :value="storyboard.selectedShot.durationTarget" @change="updateShot('durationTarget', Number(($event.target as HTMLInputElement).value))" /></label>
            <label class="editor-wide">动作与表演<textarea rows="2" :value="storyboard.selectedShot.action" placeholder="人物在画面中做什么，动作如何落点" @change="updateShot('action', ($event.target as HTMLTextAreaElement).value)" /></label>
            <label class="editor-wide">对白<textarea rows="2" :value="storyboard.selectedShot.dialogue" placeholder="没有对白可留空" @change="updateShot('dialogue', ($event.target as HTMLTextAreaElement).value)" /></label>
            <label class="editor-wide">旁白<textarea rows="2" :value="storyboard.selectedShot.narration" placeholder="旁白和字幕的初稿" @change="updateShot('narration', ($event.target as HTMLTextAreaElement).value)" /></label>
            <label class="editor-wide">画面提示词<textarea rows="3" :value="storyboard.selectedShot.visualPrompt" placeholder="人物、环境、光线、构图；这里只保存提示词，不生成视频" @change="updateShot('visualPrompt', ($event.target as HTMLTextAreaElement).value)" /></label>
            <section class="storyboard-shot-assets editor-wide" aria-label="镜头画面素材">
              <div class="storyboard-shot-assets-head">
                <div><span class="wk-label">画面资产</span><strong>{{ shotAssets.length }} 张</strong></div>
                <div class="storyboard-shot-assets-actions">
                  <button class="wk-btn" type="button" :disabled="storyboard.generationLoading || storyboard.generating || storyboard.saving" @click="openImageConfirmation"><AppIcon name="storyboard" :size="13" /> {{ storyboard.generationLoading ? '准备中…' : '生成画面' }}</button>
                  <label class="wk-btn" :data-primary="true">
                    <AppIcon name="plus" :size="13" /> {{ assetUploading ? '上传中…' : '上传画面' }}
                    <input ref="assetInput" type="file" accept="image/png,image/jpeg,image/webp" :disabled="assetUploading || storyboard.saving" @change="uploadShotAsset" />
                  </label>
                </div>
              </div>
              <p class="storyboard-shot-assets-hint">画面确认后进入制作包。支持 PNG、JPEG、WebP，单张不超过 20 MB。</p>
              <p v-if="assetUploadError" class="storyboard-shot-assets-error" role="alert">{{ assetUploadError }}</p>
              <p v-if="storyboard.generationError" class="storyboard-shot-assets-error" role="alert">{{ storyboard.generationError }}</p>
              <div v-if="storyboard.imageJobs.length" class="storyboard-image-jobs" aria-live="polite">
                <div v-for="job in storyboard.imageJobs.slice(0, 3)" :key="job.id" class="storyboard-image-job">
                  <span>{{ imageJobLabel(job.status, job.error_code) }}</span><small>{{ job.model }} · {{ job.credits }} 积分</small>
                  <button v-if="job.status === 'queued'" type="button" :disabled="storyboard.generating" @click="cancelImageJob(job.id)">取消</button>
                </div>
              </div>
              <div v-if="shotAssets.length" class="storyboard-asset-grid">
                <article v-for="asset in shotAssets" :key="asset.id" class="storyboard-asset" :data-status="asset.status">
                  <div class="storyboard-asset-preview">
                    <img v-if="storyboard.assetPreviewUrls[asset.id]" :src="storyboard.assetPreviewUrls[asset.id]" :alt="asset.originalFilename" />
                    <AppIcon v-else name="storyboard" :size="20" />
                  </div>
                  <div class="storyboard-asset-meta"><strong>{{ asset.originalFilename }}</strong><small>{{ asset.status === 'approved' ? '已确认' : asset.status === 'rejected' ? '已退回' : '待确认' }} · {{ Math.ceil(asset.byteSize / 1024) }} KB</small></div>
                  <button class="storyboard-asset-status" type="button" :disabled="storyboard.saving" @click="openAssetReview(asset)">查看</button>
                </article>
              </div>
              <p v-else class="storyboard-shot-assets-empty">还没有画面。</p>
            </section>
          </div>
        </div>
      </main>

      <aside class="storyboard-inspector" aria-label="人物视觉档案">
        <div class="storyboard-pane-head">
          <div><span class="wk-label">视觉连续性</span><strong>人物档案</strong></div>
          <span class="storyboard-count">{{ storyboard.adaptation?.visualProfiles.length ?? 0 }}</span>
        </div>
        <p class="storyboard-inspector-intro">视觉档案先于图片生成。锁定后，所有镜头都应引用同一版本。</p>
        <nav v-if="profileOptions.length > 1" class="visual-profile-switcher" aria-label="人物档案">
          <button v-for="item in profileOptions" :key="item.id" type="button" :data-active="item.id === activeCharacterId" @click="selectCharacter(item.id)">
            <strong>{{ item.character?.name }}</strong><small>{{ item.profile ? (item.inScene ? '本场 · 已有档案' : '其他人物 · 已有档案') : '本场 · 待建立' }}</small>
          </button>
        </nav>
        <div v-if="activeProfile" class="visual-profile">
          <header class="visual-profile-head">
            <div class="visual-profile-avatar">{{ activeProfile.displayName.slice(0, 1) }}</div>
            <div><strong>{{ activeProfile.displayName }}</strong><small>v{{ activeProfile.version }} · {{ activeProfile.locked ? '已锁定' : '可修改' }}</small></div>
            <button class="icon-button" type="button" :title="activeProfile.locked ? '解锁档案' : '锁定档案'" :aria-label="activeProfile.locked ? '解锁档案' : '锁定档案'" @click="toggleProfileLock(activeProfile)">{{ activeProfile.locked ? '锁' : '开' }}</button>
          </header>
          <div class="visual-profile-palette"><span v-for="color in activeProfile.palette" :key="color" :style="{ background: color }" :title="color" /></div>
          <div class="visual-profile-fields" :data-editing="profileEditOpen">
            <label>画风<input :value="activeProfile.style" :disabled="activeProfile.locked || !profileEditOpen" @change="profileField(activeProfile, 'style', $event)" /></label>
            <label>外观锚点<textarea rows="4" :value="activeProfile.appearance" :disabled="activeProfile.locked || !profileEditOpen" @change="profileField(activeProfile, 'appearance', $event)" /></label>
            <label>服装与道具<textarea rows="4" :value="activeProfile.costume" :disabled="activeProfile.locked || !profileEditOpen" @change="profileField(activeProfile, 'costume', $event)" /></label>
          </div>
          <button class="profile-edit" type="button" @click="profileEditOpen = !profileEditOpen">{{ profileEditOpen ? '完成编辑' : '编辑文字档案' }}</button>
          <section class="visual-profile-sheet" aria-label="人物全身设定图">
            <div class="visual-profile-sheet-head"><div><span class="wk-label">角色资产</span><strong>全身设定图</strong></div><span v-if="fullBodyAsset" class="visual-profile-sheet-status">{{ fullBodyAsset.status === 'approved' ? '已确认' : '待审阅' }}</span></div>
            <button v-if="fullBodyAsset && storyboard.assetPreviewUrls[fullBodyAsset.id]" class="visual-profile-sheet-image" type="button" @click="openAssetReview(fullBodyAsset)"><img :src="storyboard.assetPreviewUrls[fullBodyAsset.id]" :alt="`${activeProfile.displayName}全身设定图`" /></button>
            <div v-else-if="fullBodyAsset" class="visual-profile-sheet-empty"><AppIcon name="codex" :size="18" /><span>全身图已保存，预览加载中…</span></div>
            <div v-else class="visual-profile-sheet-empty"><AppIcon name="codex" :size="18" /><span>还没有全身图</span></div>
            <p class="visual-profile-sheet-hint">用于固定人物从头到脚的比例、服装和道具，镜头生成会持续参考。</p>
            <div class="visual-profile-sheet-actions">
              <button class="wk-btn" type="button" :disabled="storyboard.saving || storyboard.fullBodyLoading || storyboard.fullBodyJobsLoading || storyboard.fullBodyGenerating || !!activeFullBodyJob || !activeProfile.appearance.trim() || !activeProfile.costume.trim()" @click="openFullBodyConfirmation">{{ storyboard.fullBodyGenerating ? '提交中…' : storyboard.fullBodyLoading ? '读取价格…' : activeFullBodyJob ? '生成中…' : storyboard.fullBodyJobsLoading ? '读取任务…' : fullBodyAsset ? '重新生成' : '生成全身图' }}</button>
              <label class="wk-btn" :data-primary="!fullBodyAsset" :class="{ 'is-disabled': assetUploading || storyboard.saving }">{{ assetUploading ? '上传中…' : '上传全身图' }}<input ref="profileAssetInput" type="file" accept="image/png,image/jpeg,image/webp" :disabled="assetUploading || storyboard.saving" @change="uploadProfileAsset" /></label>
              <span v-if="latestFullBodyJob" class="visual-profile-sheet-job" role="status">{{ imageJobLabel(latestFullBodyJob.status, latestFullBodyJob.error_code) }}</span>
            </div>
            <p v-if="storyboard.fullBodyError" class="storyboard-shot-assets-error" role="alert">{{ storyboard.fullBodyError }}</p>
          </section>
          <p v-if="activeProfile.notes" class="visual-profile-note">{{ activeProfile.notes }}</p>
        </div>
        <div v-else-if="activeCharacters.length" class="storyboard-empty inspector-empty">
          <strong>{{ activeCharacter?.name }}尚无视觉档案</strong>
          <p>先建立外观、服装和画风约束，后续镜头会持续引用同一版本。</p>
          <button class="wk-btn" data-primary="true" type="button" :disabled="storyboard.saving || !activeCharacterId" @click="openProfileCreate(activeCharacterId ?? undefined)">创建视觉档案</button>
        </div>
        <div v-else class="storyboard-empty inspector-empty">当前场景还没有绑定人物。请先编辑场景并选择出场人物。</div>

        <button v-if="profileCandidates.length" class="profile-create" type="button" :disabled="storyboard.saving" @click="openProfileCreate()"><AppIcon name="plus" :size="13" /> 新建人物视觉档案</button>

        <div class="storyboard-binding">
          <span class="wk-label">当前场景绑定</span>
          <div class="binding-row"><span>地点</span><strong>{{ locationName }}</strong></div>
          <div class="binding-row"><span>人物</span><strong>{{ activeCharacters.map((item) => item?.name).join('、') || '未绑定' }}</strong></div>
          <p>绑定来自设定库 ID，改名或补充人物资料时不会丢失关联。</p>
        </div>
        <div class="storyboard-no-video"><span class="wk-label">当前阶段</span><strong>分镜与画面审阅</strong><p>已可上传并确认镜头画面；配音、字幕时间轴和视频合成尚未启用。</p></div>
      </aside>
    </div>

    <div v-if="episodeCreateOpen" class="storyboard-dialog-backdrop" @click.self="episodeCreateOpen = false">
      <form class="storyboard-dialog" role="dialog" aria-modal="true" aria-labelledby="episode-create-title" @submit.prevent="createEpisode">
        <header><div><span class="wk-label">小说 → 漫剧</span><h2 id="episode-create-title">新建漫剧集</h2></div><button type="button" aria-label="关闭" @click="episodeCreateOpen = false"><AppIcon name="close" :size="15" /></button></header>
        <label>集标题<input v-model="episodeDraft.title" maxlength="200" required /></label>
        <label>目标时长（秒）<input v-model.number="episodeDraft.targetDuration" type="number" min="1" max="1800" /></label>
        <fieldset class="episode-chapters"><legend>小说源章节</legend><label v-for="chapter in project.chapters" :key="chapter.id"><input v-model="episodeDraft.sourceChapterIds" type="checkbox" :value="chapter.id" /><span>第 {{ chapter.index }} 章 · {{ chapter.title || '未命名' }}</span></label><p v-if="!project.chapters.length">当前作品还没有可选章节。</p></fieldset>
        <p class="dialog-hint">至少选择一章。章节只作为改编来源，不会复制或修改小说正文。</p>
        <footer><button class="wk-btn" type="button" @click="episodeCreateOpen = false">取消</button><button class="wk-btn" data-primary="true" type="submit" :disabled="storyboard.saving || !episodeDraft.title.trim() || !episodeDraft.sourceChapterIds.length">{{ storyboard.saving ? '创建中…' : '创建并进入' }}</button></footer>
      </form>
    </div>

    <div v-if="profileCreateOpen" class="storyboard-dialog-backdrop" @click.self="profileCreateOpen = false">
      <form class="storyboard-dialog" role="dialog" aria-modal="true" aria-labelledby="profile-create-title" @submit.prevent="createVisualProfile">
        <header><div><span class="wk-label">视觉连续性</span><h2 id="profile-create-title">创建人物视觉档案</h2></div><button type="button" aria-label="关闭" @click="profileCreateOpen = false"><AppIcon name="close" :size="15" /></button></header>
        <label>设定库人物<select :value="profileDraft.codexEntryId" required @change="selectProfileCharacter(($event.target as HTMLSelectElement).value)"><option value="">请选择人物</option><option v-for="entry in profileCandidates" :key="entry.id" :value="entry.id">{{ entry.name }}</option></select></label>
        <label>显示名称<input v-model="profileDraft.displayName" maxlength="200" required /></label>
        <label>画风<input v-model="profileDraft.style" placeholder="半厚涂 / 赛璐璐 / 写实" /></label>
        <label>外观锚点<textarea v-model="profileDraft.appearance" rows="3" placeholder="脸型、发型、年龄感、不可变化的特征" /></label>
        <label>服装与道具<textarea v-model="profileDraft.costume" rows="3" placeholder="常服、身份标志、随身道具" /></label>
        <footer><button class="wk-btn" type="button" @click="profileCreateOpen = false">取消</button><button class="wk-btn" data-primary="true" type="submit" :disabled="storyboard.saving || !profileDraft.codexEntryId || !profileDraft.displayName.trim()">{{ storyboard.saving ? '创建中…' : '创建档案' }}</button></footer>
      </form>
    </div>

    <div v-if="fullBodyConfirmOpen && storyboard.fullBodyPreview" class="storyboard-dialog-backdrop" @click.self="fullBodyConfirmOpen = false">
      <div class="storyboard-dialog storyboard-image-confirm" role="dialog" aria-modal="true" aria-labelledby="full-body-confirm-title">
        <header><div><span class="wk-label">{{ activeProfile?.displayName }} · 角色资产</span><h2 id="full-body-confirm-title">生成全身设定图</h2></div><button type="button" aria-label="关闭" @click="fullBodyConfirmOpen = false"><AppIcon name="close" :size="15" /></button></header>
        <div class="storyboard-image-quote"><span>{{ storyboard.fullBodyPreview.model }}</span><strong>{{ storyboard.fullBodyPreview.credits }} 积分 / 张</strong></div>
        <ul v-if="storyboard.fullBodyPreview.issues.length" class="storyboard-image-issues"><li v-for="issue in storyboard.fullBodyPreview.issues" :key="issue">{{ imageIssueLabel(issue) }}</li></ul>
        <label>生成提示词<textarea :value="storyboard.fullBodyPreview.prompt" rows="9" readonly /></label>
        <p v-if="storyboard.fullBodyError" class="storyboard-shot-assets-error" role="alert">{{ storyboard.fullBodyError }}</p>
        <p class="dialog-hint">会强制要求完整入镜，不裁切头发、手部或鞋子。生成后仍需人工审阅。</p>
        <footer><button class="wk-btn" type="button" @click="fullBodyConfirmOpen = false">取消</button><button class="wk-btn" data-primary="true" type="button" :disabled="!storyboard.fullBodyPreview.ready || storyboard.saving || storyboard.fullBodyGenerating || storyboard.fullBodyJobsLoading || !!activeFullBodyJob" @click="confirmFullBodyGeneration">{{ storyboard.fullBodyGenerating ? '提交中…' : `确认生成 · ${storyboard.fullBodyPreview.credits} 积分` }}</button></footer>
      </div>
    </div>

    <div v-if="imageConfirmOpen && storyboard.imagePreview" class="storyboard-dialog-backdrop" @click.self="imageConfirmOpen = false">
      <div class="storyboard-dialog storyboard-image-confirm" role="dialog" aria-modal="true" aria-labelledby="image-confirm-title">
        <header><div><span class="wk-label">镜头 {{ String(storyboard.selectedShot?.order ?? 0).padStart(2, '0') }}</span><h2 id="image-confirm-title">生成画面</h2></div><button type="button" aria-label="关闭" @click="imageConfirmOpen = false"><AppIcon name="close" :size="15" /></button></header>
        <div class="storyboard-image-quote"><span>{{ storyboard.imagePreview.model }}</span><strong>{{ storyboard.imagePreview.credits }} 积分 / 张</strong></div>
        <ul v-if="storyboard.imagePreview.issues.length" class="storyboard-image-issues"><li v-for="issue in storyboard.imagePreview.issues" :key="issue">{{ imageIssueLabel(issue) }}</li></ul>
        <label>生成提示词<textarea :value="storyboard.imagePreview.prompt" rows="8" readonly /></label>
        <p v-if="storyboard.generationError" class="storyboard-shot-assets-error" role="alert">{{ storyboard.generationError }}</p>
        <footer><button class="wk-btn" type="button" @click="imageConfirmOpen = false">取消</button><button class="wk-btn" data-primary="true" type="button" :disabled="!storyboard.imagePreview.ready || storyboard.generating" @click="confirmImageGeneration">{{ storyboard.generating ? '提交中…' : `确认生成 · ${storyboard.imagePreview.credits} 积分` }}</button></footer>
      </div>
    </div>

    <div v-if="assetReview" class="storyboard-dialog-backdrop" @click.self="assetReview = null">
      <div class="storyboard-dialog storyboard-asset-review" role="dialog" aria-modal="true" aria-labelledby="asset-review-title">
        <header><div><span class="wk-label">{{ assetReview.visualProfileId ? '人物资产' : '镜头画面' }}</span><h2 id="asset-review-title">{{ assetReview.visualProfileId ? '审阅全身设定图' : '审阅画面' }}</h2></div><button type="button" aria-label="关闭" @click="assetReview = null"><AppIcon name="close" :size="15" /></button></header>
        <img v-if="storyboard.assetPreviewUrls[assetReview.id]" class="storyboard-review-image" :src="storyboard.assetPreviewUrls[assetReview.id]" :alt="assetReview.originalFilename" />
        <p v-else class="storyboard-shot-assets-error">图片暂时无法加载，请稍后重试。</p>
        <div class="storyboard-review-meta"><strong>{{ assetReview.originalFilename }}</strong><span>{{ assetReview.width ?? '?' }} × {{ assetReview.height ?? '?' }} · {{ Math.ceil(assetReview.byteSize / 1024) }} KB</span></div>
        <label>退回原因<textarea v-model="assetRejectionReason" rows="2" maxlength="500" placeholder="需要修改的画面细节" /></label>
        <p v-if="storyboard.error" class="storyboard-shot-assets-error" role="alert">{{ storyboard.error }}</p>
        <footer><button class="wk-btn" type="button" @click="assetReview = null">关闭</button><button class="wk-btn" type="button" :disabled="storyboard.saving" @click="saveAssetReview('rejected')">退回修改</button><button class="wk-btn" data-primary="true" type="button" :disabled="storyboard.saving || !storyboard.assetPreviewUrls[assetReview.id]" @click="saveAssetReview('approved')">{{ assetReview.visualProfileId ? '确认设定图' : '确认画面' }}</button></footer>
      </div>
    </div>
  </div>
</template>
