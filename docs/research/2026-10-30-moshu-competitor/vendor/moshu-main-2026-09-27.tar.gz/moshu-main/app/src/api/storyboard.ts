import { request } from './http'
import { requestResponse } from './http'
import type {
  StoryboardAdaptation,
  StoryboardEpisode,
  StoryboardScene,
  StoryboardShot,
  VisualProfile,
  ProductionPackage,
  StoryboardAsset,
  ImageGenerationPreview,
  ImageGenerationJob
} from '@/types'

interface AdaptationDto {
  id: string
  project_id: string
  title: string
  format: 'comic_drama'
  aspect_ratio: '9:16' | '16:9'
  style_profile: Record<string, unknown>
  status: StoryboardAdaptation['status']
}

interface EpisodeDto {
  id: string
  adaptation_id: string
  number: number
  title: string
  source_chapter_ids: string[]
  target_duration: number
  status: StoryboardEpisode['status']
}

interface SceneDto {
  id: string
  episode_id: string
  order: number
  purpose: string
  location_entry_id: string | null
  time_anchor: string
  character_entry_ids: string[]
  summary: string
}

interface ShotDto {
  id: string
  scene_id: string
  order: number
  shot_type: StoryboardShot['shotType']
  camera: string
  duration_target: number
  action: string
  dialogue: string
  narration: string
  visual_prompt: string
  reference_asset_ids: string[]
  status: StoryboardShot['status']
}

interface VisualProfileDto {
  id: string
  adaptation_id: string
  codex_entry_id: string
  display_name: string
  style: string
  appearance: string
  costume: string
  palette: string[]
  reference_asset_ids: string[]
  version: number
  locked: boolean
  notes: string
}

interface ProductionAssetDto {
  id: string
  adaptation_id: string
  episode_id: string | null
  shot_id: string | null
  visual_profile_id: string | null
  kind: 'image' | 'reference' | 'character_sheet'
  original_filename: string
  mime_type: string
  byte_size: number
  width: number | null
  height: number | null
  sha256: string
  status: StoryboardAsset['status']
  created_by: string
  rejection_reason?: string | null
  content_url: string
}

function assetFromDto(row: ProductionAssetDto): StoryboardAsset {
  return {
    id: row.id, adaptationId: row.adaptation_id, episodeId: row.episode_id ?? undefined,
    shotId: row.shot_id ?? undefined, visualProfileId: row.visual_profile_id ?? undefined, kind: row.kind, originalFilename: row.original_filename,
    mimeType: row.mime_type, byteSize: row.byte_size, width: row.width ?? undefined,
    height: row.height ?? undefined, sha256: row.sha256, status: row.status,
    createdBy: row.created_by, rejectionReason: row.rejection_reason ?? undefined,
    contentUrl: row.content_url
  }
}

function shotFromDto(row: ShotDto): StoryboardShot {
  return {
    id: row.id,
    sceneId: row.scene_id,
    order: row.order,
    shotType: row.shot_type,
    camera: row.camera,
    durationTarget: row.duration_target,
    action: row.action,
    dialogue: row.dialogue,
    narration: row.narration,
    visualPrompt: row.visual_prompt,
    referenceAssetIds: row.reference_asset_ids,
    status: row.status
  }
}

function sceneFromDto(row: SceneDto, shots: StoryboardShot[] = []): StoryboardScene {
  return {
    id: row.id,
    episodeId: row.episode_id,
    order: row.order,
    purpose: row.purpose,
    locationEntryId: row.location_entry_id ?? undefined,
    timeAnchor: row.time_anchor,
    characterEntryIds: row.character_entry_ids,
    summary: row.summary,
    shots
  }
}

function episodeFromDto(row: EpisodeDto, scenes: StoryboardScene[] = []): StoryboardEpisode {
  return {
    id: row.id,
    adaptationId: row.adaptation_id,
    number: row.number,
    title: row.title,
    sourceChapterIds: row.source_chapter_ids,
    targetDuration: row.target_duration,
    status: row.status,
    scenes
  }
}

function visualProfileFromDto(row: VisualProfileDto): VisualProfile {
  return {
    id: row.id,
    adaptationId: row.adaptation_id,
    codexEntryId: row.codex_entry_id,
    displayName: row.display_name,
    style: row.style,
    appearance: row.appearance,
    costume: row.costume,
    palette: row.palette,
    referenceAssetIds: row.reference_asset_ids,
    version: row.version,
    locked: row.locked,
    notes: row.notes
  }
}

async function loadScene(scene: SceneDto): Promise<StoryboardScene> {
  const shots = await request<ShotDto[]>(`/scenes/${scene.id}/shots`)
  return sceneFromDto(scene, shots.map(shotFromDto))
}

async function loadEpisode(episode: EpisodeDto): Promise<StoryboardEpisode> {
  const scenes = await request<SceneDto[]>(`/episodes/${episode.id}/scenes`)
  return episodeFromDto(episode, await Promise.all(scenes.map(loadScene)))
}

function adaptationFromDto(row: AdaptationDto, episodes: StoryboardEpisode[], visualProfiles: VisualProfile[]): StoryboardAdaptation {
  const profile = row.style_profile ?? {}
  return {
    id: row.id,
    projectId: row.project_id,
    title: row.title,
    format: row.format,
    aspectRatio: row.aspect_ratio,
    styleProfile: {
      label: typeof profile.label === 'string' ? profile.label : '待设定画风',
      description: typeof profile.description === 'string' ? profile.description : ''
    },
    status: row.status,
    episodes,
    visualProfiles
  }
}

export const storyboardApi = {
  async getImageGenerationPreview(shotId: string): Promise<ImageGenerationPreview> {
    return request<ImageGenerationPreview>(`/shots/${shotId}/image-preview`)
  },

  async listImageGenerationJobs(shotId: string): Promise<ImageGenerationJob[]> {
    return request<ImageGenerationJob[]>(`/shots/${shotId}/image-jobs`)
  },

  async createImageGenerationJob(shotId: string, clientRequestId: string, preview: ImageGenerationPreview): Promise<ImageGenerationJob> {
    return request<ImageGenerationJob>(`/shots/${shotId}/image-jobs`, {
      method: 'POST', body: JSON.stringify({
        client_request_id: clientRequestId, prompt_sha256: preview.prompt_sha256,
        model: preview.model, credits: preview.credits
      })
    })
  },

  async cancelImageGenerationJob(jobId: string): Promise<ImageGenerationJob> {
    return request<ImageGenerationJob>(`/image-jobs/${jobId}/cancel`, { method: 'POST' })
  },

  async getFullBodyImageGenerationPreview(profileId: string): Promise<ImageGenerationPreview> {
    return request<ImageGenerationPreview>(`/visual-profiles/${profileId}/full-body-preview`)
  },

  async listFullBodyImageGenerationJobs(profileId: string): Promise<ImageGenerationJob[]> {
    return request<ImageGenerationJob[]>(`/visual-profiles/${profileId}/full-body-jobs`)
  },

  async createFullBodyImageGenerationJob(profileId: string, clientRequestId: string, preview: ImageGenerationPreview): Promise<ImageGenerationJob> {
    return request<ImageGenerationJob>(`/visual-profiles/${profileId}/full-body-jobs`, {
      method: 'POST', body: JSON.stringify({
        client_request_id: clientRequestId, prompt_sha256: preview.prompt_sha256,
        model: preview.model, credits: preview.credits
      })
    })
  },

  async listStoryboardAssets(_projectId: string, adaptationId: string): Promise<StoryboardAsset[]> {
    const rows = await request<ProductionAssetDto[]>(`/adaptations/${adaptationId}/assets`)
    return rows.map(assetFromDto)
  },

  async uploadStoryboardAsset(_projectId: string, adaptationId: string, file: File, shotId?: string, episodeId?: string): Promise<StoryboardAsset> {
    const body = new FormData()
    body.append('file', file)
    if (shotId) body.append('shot_id', shotId)
    if (episodeId) body.append('episode_id', episodeId)
    body.append('kind', 'image')
    return assetFromDto(await request<ProductionAssetDto>(`/adaptations/${adaptationId}/assets`, { method: 'POST', body }))
  },

  async uploadCharacterSheet(_projectId: string, adaptationId: string, profileId: string, file: File): Promise<StoryboardAsset> {
    const body = new FormData()
    body.append('file', file)
    body.append('visual_profile_id', profileId)
    body.append('kind', 'character_sheet')
    return assetFromDto(await request<ProductionAssetDto>(`/adaptations/${adaptationId}/assets`, { method: 'POST', body }))
  },

  async updateStoryboardAsset(_projectId: string, assetId: string, status: StoryboardAsset['status'], rejectionReason?: string): Promise<StoryboardAsset> {
    return assetFromDto(await request<ProductionAssetDto>(`/assets/${assetId}`, { method: 'PATCH', body: JSON.stringify({ status, rejection_reason: rejectionReason }) }))
  },

  async getStoryboardAssetPreview(_projectId: string, asset: StoryboardAsset): Promise<string> {
    const response = await requestResponse(asset.contentUrl)
    return URL.createObjectURL(await response.blob())
  },

  async getProductionPackage(_projectId: string, episodeId: string): Promise<ProductionPackage> {
    return request<ProductionPackage>(`/episodes/${episodeId}/production-package`)
  },

  async getStoryboard(projectId: string): Promise<StoryboardAdaptation> {
    const adaptations = await request<AdaptationDto[]>(`/projects/${projectId}/adaptations`)
    let adaptation = adaptations[0]
    if (!adaptation) {
      adaptation = await request<AdaptationDto>(`/projects/${projectId}/adaptations`, {
        method: 'POST',
        body: JSON.stringify({ title: '漫剧改编', format: 'comic_drama', aspect_ratio: '9:16', style_profile: {} })
      })
    }
    const [episodeRows, profileRows] = await Promise.all([
      request<EpisodeDto[]>(`/adaptations/${adaptation.id}/episodes`),
      request<VisualProfileDto[]>(`/projects/${projectId}/adaptations/${adaptation.id}/visual-profiles`)
    ])
    const episodes = await Promise.all(episodeRows.map(loadEpisode))
    return adaptationFromDto(
      adaptation,
      episodes,
      profileRows.map(visualProfileFromDto)
    )
  },

  async createStoryboardEpisode(projectId: string, input: Pick<StoryboardEpisode, 'title' | 'sourceChapterIds' | 'targetDuration'>): Promise<StoryboardEpisode> {
    const adaptation = await this.getStoryboard(projectId)
    const row = await request<EpisodeDto>(`/adaptations/${adaptation.id}/episodes`, {
      method: 'POST',
      body: JSON.stringify({
        number: adaptation.episodes.length + 1,
        title: input.title,
        source_chapter_ids: input.sourceChapterIds,
        target_duration: input.targetDuration
      })
    })
    return episodeFromDto(row)
  },

  async updateStoryboardEpisode(_projectId: string, episodeId: string, patch: Partial<StoryboardEpisode>): Promise<StoryboardEpisode> {
    const body: Record<string, unknown> = {}
    if (patch.title !== undefined) body.title = patch.title
    if (patch.sourceChapterIds !== undefined) body.source_chapter_ids = patch.sourceChapterIds
    if (patch.targetDuration !== undefined) body.target_duration = patch.targetDuration
    if (patch.status !== undefined) body.status = patch.status
    return episodeFromDto(await request<EpisodeDto>(`/episodes/${episodeId}`, { method: 'PATCH', body: JSON.stringify(body) }))
  },

  async createStoryboardScene(_projectId: string, episodeId: string, input: Pick<StoryboardScene, 'purpose' | 'summary' | 'timeAnchor' | 'locationEntryId' | 'characterEntryIds'>): Promise<StoryboardScene> {
    const existing = await request<SceneDto[]>(`/episodes/${episodeId}/scenes`)
    const row = await request<SceneDto>(`/episodes/${episodeId}/scenes`, {
      method: 'POST',
      body: JSON.stringify({
        order: existing.length + 1,
        purpose: input.purpose,
        summary: input.summary,
        time_anchor: input.timeAnchor,
        location_entry_id: input.locationEntryId ?? null,
        character_entry_ids: input.characterEntryIds
      })
    })
    return sceneFromDto(row)
  },

  async updateStoryboardScene(_projectId: string, sceneId: string, patch: Partial<StoryboardScene>): Promise<StoryboardScene> {
    const body: Record<string, unknown> = {}
    if (patch.purpose !== undefined) body.purpose = patch.purpose
    if (patch.summary !== undefined) body.summary = patch.summary
    if (patch.timeAnchor !== undefined) body.time_anchor = patch.timeAnchor
    if (patch.locationEntryId !== undefined) body.location_entry_id = patch.locationEntryId || null
    if (patch.characterEntryIds !== undefined) body.character_entry_ids = patch.characterEntryIds
    return sceneFromDto(await request<SceneDto>(`/scenes/${sceneId}`, { method: 'PATCH', body: JSON.stringify(body) }))
  },

  async reorderStoryboardScenes(_projectId: string, episodeId: string, ids: string[]): Promise<StoryboardScene[]> {
    const rows = await request<SceneDto[]>(`/episodes/${episodeId}/scenes/order`, { method: 'PUT', body: JSON.stringify({ ids }) })
    return rows.map((row) => sceneFromDto(row))
  },

  async createStoryboardShot(_projectId: string, sceneId: string, input: Partial<StoryboardShot>): Promise<StoryboardShot> {
    const existing = await request<ShotDto[]>(`/scenes/${sceneId}/shots`)
    const row = await request<ShotDto>(`/scenes/${sceneId}/shots`, {
      method: 'POST',
      body: JSON.stringify({
        order: existing.length + 1,
        shot_type: input.shotType ?? 'medium',
        camera: input.camera ?? 'static',
        duration_target: input.durationTarget ?? 4,
        action: input.action ?? '',
        dialogue: input.dialogue ?? '',
        narration: input.narration ?? '',
        visual_prompt: input.visualPrompt ?? '',
        reference_asset_ids: input.referenceAssetIds ?? []
      })
    })
    return shotFromDto(row)
  },

  async updateStoryboardShot(_projectId: string, shotId: string, patch: Partial<StoryboardShot>): Promise<StoryboardShot> {
    const body: Record<string, unknown> = {}
    if (patch.shotType !== undefined) body.shot_type = patch.shotType
    if (patch.camera !== undefined) body.camera = patch.camera
    if (patch.durationTarget !== undefined) body.duration_target = patch.durationTarget
    if (patch.action !== undefined) body.action = patch.action
    if (patch.dialogue !== undefined) body.dialogue = patch.dialogue
    if (patch.narration !== undefined) body.narration = patch.narration
    if (patch.visualPrompt !== undefined) body.visual_prompt = patch.visualPrompt
    if (patch.referenceAssetIds !== undefined) body.reference_asset_ids = patch.referenceAssetIds
    if (patch.status !== undefined) body.status = patch.status
    return shotFromDto(await request<ShotDto>(`/shots/${shotId}`, { method: 'PATCH', body: JSON.stringify(body) }))
  },

  async reorderStoryboardShots(_projectId: string, sceneId: string, ids: string[]): Promise<StoryboardShot[]> {
    const rows = await request<ShotDto[]>(`/scenes/${sceneId}/shots/order`, { method: 'PUT', body: JSON.stringify({ ids }) })
    return rows.map(shotFromDto)
  },

  async updateVisualProfile(_projectId: string, profileId: string, patch: Partial<VisualProfile>): Promise<VisualProfile> {
    const body: Record<string, unknown> = {}
    if (patch.displayName !== undefined) body.display_name = patch.displayName
    if (patch.style !== undefined) body.style = patch.style
    if (patch.appearance !== undefined) body.appearance = patch.appearance
    if (patch.costume !== undefined) body.costume = patch.costume
    if (patch.palette !== undefined) body.palette = patch.palette
    if (patch.referenceAssetIds !== undefined) body.reference_asset_ids = patch.referenceAssetIds
    if (patch.notes !== undefined) body.notes = patch.notes
    if (patch.locked !== undefined) body.locked = patch.locked
    const row = await request<VisualProfileDto>(`/visual-profiles/${profileId}`, { method: 'PATCH', body: JSON.stringify(body) })
    return visualProfileFromDto(row)
  },

  async createVisualProfile(projectId: string, input: Pick<VisualProfile, 'codexEntryId' | 'displayName'> & Partial<VisualProfile>): Promise<VisualProfile> {
    const adaptation = await this.getStoryboard(projectId)
    const row = await request<VisualProfileDto>(`/adaptations/${adaptation.id}/visual-profiles`, {
      method: 'POST',
      body: JSON.stringify({
        codex_entry_id: input.codexEntryId,
        display_name: input.displayName,
        style: input.style ?? '',
        appearance: input.appearance ?? '',
        costume: input.costume ?? '',
        palette: input.palette ?? [],
        reference_asset_ids: input.referenceAssetIds ?? [],
        notes: input.notes ?? ''
      })
    })
    return visualProfileFromDto(row)
  }
}
