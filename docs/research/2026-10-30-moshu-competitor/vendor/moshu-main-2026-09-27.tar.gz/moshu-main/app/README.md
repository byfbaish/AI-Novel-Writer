# 墨枢 · AI 网文创作平台（前端脚手架）

Vue 3 + TypeScript + Vite。默认通过 `/api` 访问真实后端；需要无后端演示时，显式设置 `VITE_USE_MOCK=true` 才会启用 `src/api/mock`。

```bash
cd app
cp .env.example .env
npm i
npm run dev      # http://localhost:5173
npm test         # 单测
npm run typecheck
```

## 五屏对应

| 路由 | 视图 | 设计稿 |
| --- | --- | --- |
| `/` | `ShelfView` | 屏 06 书架 |
| `/write` | `WorkspaceView` | 屏 01 写作台 + 屏 02 一键成章（同一界面的两个状态） |
| `/outline` | `OutlineView` | 屏 07 大纲 |
| `/codex` | `CodexView` | 屏 03 设定库 |
| `/guard` | `GuardView` | 屏 04 一致性守卫 |
| `/style` | `StyleView` | 屏 08 风格档 |
| `/ai-ratio` | `AiRatioView` | 屏 09 AI 占比自查 |
| `/export` | `ExportView` | 屏 10 导出 |
| `/usage` | `UsageView` | 屏 11 用量与计费 |
| `/wizard` | `WizardView` | 屏 05 开书向导 |
| `/login` | `LoginView` | 屏 12 登录 |
| `/deconstruct` | `DeconstructView` | P1 参考作品拆书分析 |

## 目录

```
src/
  api/            接口层。http.ts 只管传输，mock/ 是可丢弃的假数据层
    generation.ts 一键成章：mock 逐字回放 / 真实 SSE，两条路径同一签名
    mock/seed.ts  假数据（《剑起山河》），换成真接口时整个 mock/ 删掉即可
  editor/
    extensions/
      AiDraft.ts            ★ 待采纳草稿容器，产品最核心的交互
      CodexRef.ts           ★ 设定引用节点，存 id 不存文字
      codex-suggestion.ts   @ 唤起的下拉
    use-novel-editor.ts     编辑器组装入口
  stores/         Pinia：project / codex / guard
  composables/    use-autosave.ts —— 三层保险的自动保存
  components/     layout/ 应用外壳，editor/ 编辑器内部件
  views/          四个页面
  styles/
    modernist.css 设计系统令牌与组件层（勿手改，随设计系统更新）
    app.css       只放 modernist 覆盖不到的应用层样式
```

## 三个必须先读的设计决定

**1. 一章一文档。** 80 万字放进单个 ProseMirror 文档会卡死。`listChapters` 不返回正文，`openChapter` 才按需拉；切章用 `setContent` 复用同一编辑器实例，不重挂载。

**2. AI 输出落在 `aiDraft` 节点里，不进正文也不进撤销栈。** 流式增量全部 `tr.setMeta('addToHistory', false)`，用户按一次 Cmd+Z 应该整段退回而不是退回一个字。采纳是 `replaceWith(node.content)` 一次事务。这套行为有单测锁住（`AiDraft.spec.ts`），改动前先跑测试。

**3. 设定引用存 id。** `CodexRef` 节点的 `attrs.id` 指向条目，渲染时从 store 读当前名称 —— 改名自动跟随，且服务端能精确知道本章引用了什么（一致性检查与上下文装配都依赖这份关系）。

## 接后端要改的地方

1. `.env` 里保持 `VITE_USE_MOCK=false`，`vite.config.ts` 打开 proxy。
2. 如果只想启动独立演示，将 `VITE_USE_MOCK` 改为 `true`；该模式不会访问或写入真实后端。
3. `/api/generate/chapter` 按 SSE 推 `data: {"text":"…"}` / `data: {"node":2}` / `data: [DONE]`，`generation.ts` 里的解析已经写好。
4. 上下文装配（`getContextLayers` 返回的四层）在服务端完成，前端只负责展示预算与上限。

## 当前边界

真实登录与会话轮换、项目/工作室权限、行内与整章生成、额度结算、版本历史、全书校订、拆书分析、
一致性守卫和导出备份均已接通后端。当前仍保留的产品边界：

- 大纲支持按钮换序，也支持卷和章节的原生拖拽排序；跨卷拖动章节会追加到目标卷末尾
- 工作室已有成员、角色、作品共享、章节任务流和成员产量看板，不包含 Yjs/Hocuspocus 同屏实时编辑
- 已有套餐和积分账本，不包含支付渠道、订阅购买与发票流程
- 关系图、地图、出版排版和第三方平台发布属于后续增强
