"""
Celery application configuration
"""
from celery import Celery

from config import settings

celery_app = Celery(
    "moshu_consistency",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    # A long chapter may require hundreds of streamed extraction requests. Keep
    # a finite ceiling, but leave enough time for a million-word consistency run
    # to finish instead of leaving its run row stuck in ``extracting``.
    task_time_limit=7200,
    task_soft_time_limit=7140,
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=1000,
    imports=("tasks.consistency", "tasks.codex", "tasks.generation", "tasks.production"),
    task_routes={
        "consistency.dispatch_outbox": {"queue": "outbox"},
        "consistency.process_body_saved": {"queue": "consistency"},
        "consistency.extract_claims": {"queue": "consistency"},
        "consistency.generate_summary": {"queue": "consistency"},
        "consistency.scan_rules": {"queue": "consistency"},
        "consistency.rescan_temporal_dependents": {"queue": "consistency"},
        "consistency.arbitrate_issues": {"queue": "consistency"},
        "codex.backfill_embeddings": {"queue": "consistency"},
        "codex.backfill_chapter_chunks": {"queue": "consistency"},
        "codex.recover_stale_embedding_jobs": {"queue": "outbox"},
        "production.generate_image": {"queue": "consistency"},
        "production.dispatch_queued": {"queue": "outbox"},
        "production.recover_stale": {"queue": "outbox"},
        "generation.generate_long_segment": {"queue": "generation"},
    },
    beat_schedule={
        "dispatch-consistency-outbox": {
            "task": "consistency.dispatch_outbox",
            "schedule": 2.0,
            "kwargs": {"batch_size": 20},
        },
        "recover-stale-embedding-jobs": {
            "task": "codex.recover_stale_embedding_jobs",
            "schedule": 60.0,
        },
        "recover-stale-generation-state": {
            "task": "generation.recover_stale_state",
            "schedule": 60.0,
        },
        "dispatch-queued-image-jobs": {
            "task": "production.dispatch_queued",
            "schedule": 15.0,
        },
        "recover-stale-image-jobs": {
            "task": "production.recover_stale",
            "schedule": 60.0,
        },
    },
)

# Tasks are registered explicitly through ``imports`` above.  Using
# autodiscover_tasks(["tasks"]) would look for a Django-style tasks.tasks module.
