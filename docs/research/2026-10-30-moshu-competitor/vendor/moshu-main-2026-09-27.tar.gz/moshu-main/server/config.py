"""
配置管理 - 从环境变量加载所有配置
"""
from pathlib import Path
from typing import Optional
from urllib.parse import urlsplit

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Resolve .env relative to this module so Celery, Alembic, pytest, and server
# startup all read the same local configuration regardless of cwd.
_ENV_FILE = Path(__file__).resolve().parent / ".env"

# Unknown BYOK model identifiers must not silently inherit the platform
# model's larger context window. Users may override these conservative values
# only within the validated bounds below.
DEFAULT_CONTEXT_WINDOW_TOKENS = 32_768
DEFAULT_MAX_OUTPUT_TOKENS = 4_096
DEFAULT_CONTEXT_SAFETY_MARGIN_TOKENS = 2_048
MIN_CONTEXT_INPUT_TOKENS = 1_024
DEFAULT_GENERATION_CONTEXT_WINDOW_TOKENS = 256_000
DEFAULT_GENERATION_MAX_OUTPUT_TOKENS = 32_000
DEFAULT_GENERATION_CONTEXT_SAFETY_MARGIN_TOKENS = 16_000

_INSECURE_CRYPTO_SECRETS = {
    "local-development-only-change-before-production",
    "change-this-in-production",
    "replace-with-at-least-32-random-bytes",
    "replace-with-a-separate-long-random-secret",
    "replace-with-a-separate-at-least-32-byte-random-secret",
}


def _is_loopback_origin(value: str) -> bool:
    """Return whether an app origin is explicitly local-only."""

    try:
        hostname = (urlsplit(value.strip()).hostname or "").lower().rstrip(".")
    except ValueError:
        return False
    return hostname in {"localhost", "127.0.0.1", "::1"}


def validate_public_deployment_secrets(
    *,
    public_app_url: str,
    cors_origins: str,
    jwt_secret_key: str,
    credential_encryption_key: str | None,
) -> None:
    """Reject sample cryptographic material when the app is public."""

    origins = [public_app_url, *(item for item in cors_origins.split(",") if item.strip())]
    if all(_is_loopback_origin(origin) for origin in origins):
        return
    if len(jwt_secret_key.strip()) < 32 or jwt_secret_key.strip() in _INSECURE_CRYPTO_SECRETS:
        raise ValueError(
            "public deployments require JWT_SECRET_KEY with at least 32 random characters; "
            "replace the example value"
        )
    if (
        credential_encryption_key is None
        or len(credential_encryption_key.strip()) < 32
        or credential_encryption_key.strip() in _INSECURE_CRYPTO_SECRETS
        or credential_encryption_key.strip() == jwt_secret_key.strip()
    ):
        raise ValueError(
            "public deployments require a separate CREDENTIAL_ENCRYPTION_KEY with at least 32 random characters"
        )


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=_ENV_FILE, env_file_encoding="utf-8", extra="ignore", hide_input_in_errors=True,
    )

    # Database
    database_url: str = "postgresql+asyncpg://moshu:moshu@localhost:5432/moshu"
    database_pool_size: int = 20
    database_max_overflow: int = 10

    # Redis
    redis_url: str = "redis://localhost:6379/0"
    celery_broker_url: str = "redis://localhost:6379/1"
    celery_result_backend: str = "redis://localhost:6379/2"

    # JWT
    jwt_secret_key: str
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 30

    # 首次部署引导：仅临时设置，完成首个管理员创建后应从运行环境移除。
    # 不设置时不会开放 bootstrap API；普通注册流程不受影响。
    bootstrap_token: Optional[str] = None

    # Authentication protection. ``off`` is convenient for local development;
    # production can require Turnstile on every auth attempt (``always``), or
    # only after repeated failures (``adaptive``).
    auth_captcha_mode: str = "off"
    auth_captcha_site_key: Optional[str] = None
    auth_captcha_secret_key: Optional[str] = None
    auth_captcha_verify_url: str = "https://challenges.cloudflare.com/turnstile/v0/siteverify"
    auth_captcha_challenge_ttl_seconds: int = Field(default=300, ge=30, le=3600)
    auth_captcha_adaptive_threshold: int = Field(default=3, ge=1, le=100)
    auth_failure_limit: int = Field(default=8, ge=1, le=100)
    auth_failure_window_seconds: int = Field(default=900, ge=60, le=86400)
    auth_rate_limit_fail_closed: bool = False

    # Model Gateway
    model_gateway_cheap_url: str
    model_gateway_cheap_key: str
    model_gateway_main_url: str
    model_gateway_main_key: str
    model_gateway_premium_url: str
    model_gateway_premium_key: str

    # Image generation uses a separate per-image price, never text-token rates.
    # URL/key fall back to the main gateway when a compatible image route is available.
    image_gateway_url: Optional[str] = None
    image_gateway_key: Optional[str] = None
    image_gateway_model: str = "gpt-image-2"
    image_generation_credits: int = Field(default=0, ge=0, le=100_000)

    # Object Storage
    s3_endpoint: str
    s3_access_key: str
    s3_secret_key: str
    s3_bucket_exports: str = "moshu-exports"
    s3_bucket_uploads: str = "moshu-uploads"
    # Local fallback for private production assets. In Docker set this to the
    # mounted persistent volume; object-storage adapters can replace it later.
    production_asset_dir: str = ".local/production-assets"
    production_asset_max_bytes: int = Field(default=20_000_000, ge=1_000_000, le=100_000_000)

    # App
    debug: bool = False
    cors_origins: str = "http://localhost:5173"
    log_level: str = "INFO"
    build_revision: str = "local"
    # Readiness probes must fail fast when a dependency is down; otherwise a
    # rolling deploy can keep an unhealthy instance in service for minutes.
    health_check_timeout_seconds: float = Field(default=5.0, ge=0.1, le=30.0)

    # Password reset delivery. Credentials stay in the runtime environment;
    # the API never persists or logs the plaintext reset token.
    public_app_url: str = "http://localhost:8080"
    smtp_host: Optional[str] = None
    smtp_port: int = Field(default=587, ge=1, le=65_535)
    smtp_username: Optional[str] = None
    smtp_password: Optional[str] = None
    smtp_from: Optional[str] = None
    smtp_use_tls: bool = True
    smtp_timeout_seconds: float = Field(default=15.0, ge=1.0, le=120.0)

    # Mainland payment adapters. Secrets/certificates stay outside the repo;
    # adapters remain disabled until the merchant credentials are complete.
    payment_notify_base_url: Optional[str] = None
    wechat_pay_app_id: Optional[str] = None
    wechat_pay_mch_id: Optional[str] = None
    wechat_pay_serial_no: Optional[str] = None
    wechat_pay_private_key_path: Optional[str] = None
    wechat_pay_api_v3_key: Optional[str] = None
    wechat_pay_platform_certificates_dir: Optional[str] = None
    wechat_pay_api_base_url: str = "https://api.mch.weixin.qq.com"
    alipay_app_id: Optional[str] = None
    alipay_private_key_path: Optional[str] = None
    alipay_alipay_public_key_path: Optional[str] = None
    alipay_gateway_url: str = "https://openapi.alipay.com/gateway.do"
    payment_request_timeout: float = 15.0

    # Consistency pipeline - 抽取/摘要/嵌入使用的网关与模型（不得在代码里硬编码）
    consistency_gateway_tier: str = "main"  # cheap, main, premium
    consistency_extraction_model: str = "gpt-4o-mini"
    consistency_summary_model: str = "gpt-4o-mini"
    consistency_arbitration_model: Optional[str] = None
    embedding_gateway_url: Optional[str] = None
    embedding_gateway_key: Optional[str] = None
    embedding_model: str = "doubao-embedding-vision"
    # 数据库列是 HALFVEC(2048)；换维度必须先做 schema migration。
    embedding_dimensions: int = 2048
    # 本地模型可以使用更小的向量维度。服务端会在写入 HALFVEC(2048) 前
    # 追加零分量，保持余弦相似度方向不变，同时避免为本地开发强制迁移现有库。
    # 留空时严格要求网关返回 embedding_dimensions，适用于远程生产网关。
    embedding_source_dimensions: Optional[int] = Field(default=None, ge=1, le=2048)
    embedding_request_timeout: float = Field(default=120.0, ge=1.0, le=600.0)

    @field_validator("embedding_source_dimensions", mode="before")
    @classmethod
    def blank_embedding_source_dimensions(cls, value):
        return None if isinstance(value, str) and not value.strip() else value

    @property
    def embedding_space_id(self) -> str:
        """Identify a vector space without persisting any gateway credentials."""
        import hashlib
        import json

        endpoint = (self.embedding_gateway_url or self.gateway_url()).rstrip("/")
        for suffix in ("/chat/completions", "/embeddings", "/completions"):
            if endpoint.endswith(suffix):
                endpoint = endpoint[:-len(suffix)]
                break
        identity = [endpoint, self.embedding_model, self.embedding_source_dimensions or self.embedding_dimensions,
                    self.embedding_dimensions]
        return hashlib.sha256(json.dumps(identity).encode()).hexdigest()

    # 一致性抽取分块参数：长章节必须切块后全量处理，不能截断丢尾部。
    # 1M 字正文约需要 180 个 6000 字块；512 为有余量的硬上限，
    # 同时避免对异常超大请求完全取消保护。
    consistency_chunk_chars: int = 6000
    consistency_chunk_overlap_chars: int = 400
    consistency_max_chunks: int = 512

    # 向量检索使用独立的块大小。轻量本地 embedding 模型通常无法在
    # 6000 字输入上及时返回；较小的检索块保证长篇 RAG 能稳定回填，
    # 不改变上面供事实抽取使用的上下文块。
    embedding_chunk_chars: int = 1200
    embedding_chunk_overlap_chars: int = 120
    embedding_max_chunks: int = 2048
    # 本地 embedding 模型通常按单条请求更稳定；远程网关可按需调大。
    embedding_batch_size: int = Field(default=8, ge=1, le=64)

    # SSE 流式与重试配置
    consistency_reasoning_effort: str = "low"  # none, low, medium, high
    consistency_request_timeout: float = 180.0  # 秒
    consistency_max_retries: int = 3
    consistency_retry_base_delay: float = 1.0  # 秒
    # 分块抽取/摘要的并发上限。六路并发能让百万字扫描在 worker 时限内完成；
    # 低配或受限网关可通过 MOSHU_CONSISTENCY_CHUNK_CONCURRENCY 下调。
    consistency_chunk_concurrency: int = Field(default=6, ge=1, le=32)

    # Novel generation.  The model falls back to the configured consistency
    # summary model so deployments keep one source of truth unless overridden.
    generation_gateway_tier: str = "main"
    generation_model: Optional[str] = None
    generation_review_model: Optional[str] = None
    generation_reasoning_effort: str = "low"
    generation_request_timeout: float = 600.0
    generation_context_window_tokens: int = Field(
        default=DEFAULT_GENERATION_CONTEXT_WINDOW_TOKENS, ge=4_096, le=2_000_000
    )
    generation_max_output_tokens: int = Field(
        default=DEFAULT_GENERATION_MAX_OUTPUT_TOKENS, ge=256, le=131_072
    )
    generation_context_safety_margin_tokens: int = Field(
        default=DEFAULT_GENERATION_CONTEXT_SAFETY_MARGIN_TOKENS, ge=256, le=262_144
    )

    # User-provided model keys are encrypted at rest. Deployments should set a
    # dedicated value; the JWT key is a backward-compatible derivation source.
    credential_encryption_key: Optional[str] = None

    @field_validator("embedding_dimensions")
    @classmethod
    def validate_embedding_dimensions(cls, value: int) -> int:
        if value != 2048:
            raise ValueError(
                "embedding_dimensions must be 2048 for the HALFVEC(2048) schema"
            )
        return value

    @field_validator("auth_captcha_mode")
    @classmethod
    def validate_auth_captcha_mode(cls, value: str) -> str:
        normalized = value.strip().lower()
        if normalized not in {"off", "adaptive", "always"}:
            raise ValueError("auth_captcha_mode must be off, adaptive or always")
        return normalized

    @model_validator(mode="after")
    def validate_context_budget(self) -> "Settings":
        available_input = (
            self.generation_context_window_tokens
            - self.generation_max_output_tokens
            - self.generation_context_safety_margin_tokens
        )
        if available_input < MIN_CONTEXT_INPUT_TOKENS:
            raise ValueError(
                "context budget must reserve at least "
                f"{MIN_CONTEXT_INPUT_TOKENS} tokens for input"
            )
        return self

    @model_validator(mode="after")
    def validate_public_secrets(self) -> "Settings":
        validate_public_deployment_secrets(
            public_app_url=self.public_app_url,
            cors_origins=self.cors_origins,
            jwt_secret_key=self.jwt_secret_key,
            credential_encryption_key=self.credential_encryption_key,
        )
        return self

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",")]

    def gateway_url(self, tier: Optional[str] = None) -> str:
        """按 tier 取网关 URL。"""
        return self._gateway_pair(tier)[0]

    def gateway_key(self, tier: Optional[str] = None) -> str:
        """按 tier 取网关 key。"""
        return self._gateway_pair(tier)[1]

    @property
    def resolved_generation_model(self) -> str:
        return self.generation_model or self.consistency_summary_model

    @property
    def resolved_arbitration_model(self) -> str:
        return self.consistency_arbitration_model or self.consistency_extraction_model

    def _gateway_pair(self, tier: Optional[str]) -> tuple[str, str]:
        resolved = (tier or self.consistency_gateway_tier).lower()
        mapping = {
            "cheap": (self.model_gateway_cheap_url, self.model_gateway_cheap_key),
            "main": (self.model_gateway_main_url, self.model_gateway_main_key),
            "premium": (self.model_gateway_premium_url, self.model_gateway_premium_key),
        }
        if resolved not in mapping:
            raise ValueError(
                f"unknown model gateway tier: {resolved!r} (expected cheap, main or premium)"
            )
        return mapping[resolved]


settings = Settings()
