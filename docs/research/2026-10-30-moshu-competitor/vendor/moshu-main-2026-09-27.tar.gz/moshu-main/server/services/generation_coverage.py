"""Explainable, non-blocking coverage checks for generation prompts and drafts.

The checks intentionally avoid claiming semantic certainty.  Prompt checks prove
that author-authored requirements reached the model package; draft checks only
surface lexical evidence and leave the final judgement to the author.
"""

import re
from typing import Any

_COMMON_BIGRAMS = {
    "一个",
    "一些",
    "以及",
    "之后",
    "他们",
    "她们",
    "这个",
    "那个",
    "什么",
    "如何",
    "开始",
    "继续",
    "需要",
    "本章",
    "场景",
    "人物",
    "主角",
}

_PROCEDURAL_TERMS = (
    "登记",
    "核验",
    "复称",
    "保管",
    "交接",
    "凭据",
    "责任",
    "封存",
    "时辰",
    "费用",
    "文书",
    "袋号",
    "阅卷",
    "副本",
    "条款",
    "编号",
    "写入",
    "复核",
    "见证",
)
_CHECKLIST_ENDING = re.compile(
    r"(?:^|[\n。；])\s*(?:一|二|三|四|五|六|七|八|九|十)[、，.]"
)
_TURN_MARKERS = (
    "却", "但", "没想到", "突然", "直到", "原本", "改口", "拒绝", "答应",
    "发现", "暴露", "扣住", "拦住", "失去", "转身", "反悔", "被截", "落空",
)
_HOOK_MARKERS = (
    "?", "？", "未完", "还没", "尚未", "却在", "突然", "门外", "脚步", "来人",
    "明日", "今晚", "必须", "等着", "不敢", "要么", "还是", "倒计时", "期限",
    "哪里", "哪儿", "何处", "去哪", "去向", "转移", "追踪", "盯梢",
)
_HOOK_ACTION_MARKERS = (
    "敲", "撞", "闯", "扣", "拔", "抬", "转", "递", "烧", "撕", "打开", "按住",
    "站起", "回头", "冲进", "落笔", "封", "带走", "逼问", "拔刀", "来信",
    "追上", "追踪", "跟上", "抓住", "围住", "喊叫", "点燃", "转移", "运往",
    "押走", "锁住", "封住", "掀开", "掏出", "撬开", "截住", "盯梢",
    "落锁", "锁死", "砸碎", "碎裂", "倒下", "塌落", "断裂", "割断", "点着",
    "熄灭", "亮起", "响起", "传来", "逼近", "追来", "失踪", "夺走", "撕开",
    "掐住", "拽住", "拦下", "封死", "烧着", "坠落", "翻倒", "冲出", "闯入",
)
_HOOK_PRESSURE_MARKERS = (
    "必须", "期限", "倒计时", "来不及", "之前", "之内", "否则", "要么", "代价",
    "拔刀", "封门", "追上", "抓住", "带走", "杀", "着火", "断粮", "失踪", "截住",
    "交出", "撕掉", "烧掉", "扣下", "不见了", "只给", "只剩", "香灭", "一刻钟",
    "门外", "脚步", "围住", "喊叫", "转移", "运往", "追踪", "盯梢", "去向",
)
_HOOK_INTENT_MARKERS = ("准备", "打算", "想要", "将要", "计划", "看看", "再去")
_DECISION_MARKERS = (
    "决定", "答应", "拒绝", "撕掉", "烧掉", "交出", "留下", "放弃", "押上", "签下",
    "闯入", "拔刀",
)
_COST_MARKERS = (
    "代价", "失去", "换来", "换回", "舍弃", "损失", "暴露", "得罪", "受伤", "欠下",
    "没有退路", "再也不能", "断粮", "坐牢", "杀头", "被抓", "被扣",
)
_RECOGNITION_ONLY_HOOK = re.compile(
    r"(?:认出|认出了|看清|看到了|想起|是)\s*[^。！？!?]{0,36}"
    r"(?:怎么会|为何|为什么|怎么可能|竟然在|会在|是谁)\s*[？?]\s*$"
)
_ABSTRACT_ENDING = re.compile(
    r"(?:接下来|下一步|从此以后|新的篇章|才刚刚开始|局势(?:已经|将会)?改变|"
    r"命运(?:将|会)[^。！？!?]{0,32}|(?:知道|意识到|明白)[^。！？!?]{0,48}"
    r"(?:选择|决定|生死|命运|未来|一切|局势)[^。！？!?]{0,32})"
    r"[。！？!?]?\s*$",
    flags=re.S,
)
_EXPOSITION_LOOP_MARKERS = (
    "因为", "可是", "什么意思", "怎么办", "回去吧", "等通知", "按规矩", "不能接",
    "不行", "没办法", "证据确凿", "你知道", "我不知道",
)
_DRAMATIC_MOTIFS: dict[str, tuple[str, ...]] = {
    "求见受阻": ("求见", "通报", "递状", "等通知", "按规矩", "不能接", "进不了", "回去吧"),
    "账证核验": ("账册", "核验", "复核", "登记", "凭据", "文书", "副本", "签字"),
    "利益谈判": ("谈判", "条件", "筹码", "交换", "承诺", "保证书", "答应", "反悔"),
    "追逐抓捕": ("追上", "追来", "抓住", "抓走", "绑住", "堵住", "逃走", "黑衣人"),
    "潜入转移": ("混进", "潜入", "藏在", "侧门", "小巷", "出城", "进城", "转移"),
    "公开对峙": ("当众", "围观", "公堂", "对质", "质问", "众人", "围住", "喝道"),
    "关系决裂": ("背叛", "决裂", "失信", "不再相信", "断绝", "出卖", "反目", "翻脸"),
    "资源危机": ("断粮", "被毁", "烧毁", "抢粮", "扣粮", "绝收", "银子用尽", "只剩"),
}
_ABSTRACT_CONTRACT_MARKERS = (
    "下一章", "下章", "具体决定", "必须回应", "留下后果", "推进收束", "完成阶段",
    "局势变化", "制造悬念", "埋下伏笔", "引出冲突",
)
_CONCRETE_HOOK_EVENT = re.compile(
    r"(?:已经|正在|刚(?:刚)?|忽然|猛地|突然|此刻|门外|身后|楼下|远处|夜色里)"
    r"[^。！？!?]{0,32}"
    r"(?:落锁|锁死|封死|砸碎|碎裂|倒下|塌落|断裂|割断|点燃|点着|熄灭|响起|传来|"
    r"逼近|追来|失踪|夺走|撕开|掐住|拽住|拦下|烧着|坠落|翻倒|冲出|闯入|截住)"
    r"[^。！？!?]{0,48}[。！？!?]?$"
)
_CHAPTER_REFERENCE = r"(?:第[零一二三四五六七八九十百千万\d]{1,8}章|前一章|上一章|上章|前章|本章)"
_NARRATIVE_META = re.compile(
    rf"(?:想起|回想起|记得|回忆起|承接|延续)(?:了|在)?{_CHAPTER_REFERENCE}(?:里|中|的|时|发生|提到)"
    rf"|{_CHAPTER_REFERENCE}(?:里|中)(?:曾经|已经|发生过|提到过)"
    r"|(?:以下|下面)是(?:本章|小说)?正文"
    r"|作为(?:一个|一名)?(?:AI|人工智能|语言模型)"
)


def _summary(checks: list[dict[str, Any]], *, stage: str) -> dict[str, int | str]:
    attention = sum(check["status"] in {"attention", "author_review"} for check in checks)
    confirmed = sum(check["status"] in {"included", "evidence_found"} for check in checks)
    if stage == "prompt":
        message = f"生成依据已核对：{confirmed} 项已进入提示词，{attention} 项需要留意。"
    else:
        message = f"候选覆盖已核对：{confirmed} 项找到字面证据，{attention} 项需要作者确认。"
    return {"total": len(checks), "confirmed": confirmed, "attention": attention, "message": message}


def build_prompt_coverage(
    guidance: dict[str, Any],
    *,
    included_content: str,
    task: str,
    outline_nodes: list[str] | None = None,
    outline_source_id: str | None = None,
) -> dict[str, Any]:
    """Report which planning requirements reached the exact prompt package."""
    checks = [dict(check) for check in guidance.get("inputChecks", [])]
    outline_requirements = _outline_dramatic_requirements(outline_nodes or [], outline_source_id)
    all_requirements = [*guidance.get("requirements", []), *outline_requirements]
    applicability = "chapter" if task == "chapter" else "reference"
    for requirement in all_requirements:
        raw_expected = [str(value) for value in requirement.get("expected", []) if str(value).strip()]
        included = bool(raw_expected) and all(value in included_content for value in raw_expected)
        expected = [value if len(value) <= 240 else value[:237] + "..." for value in raw_expected]
        source_type = requirement.get("sourceType", "plan")
        checks.append(
            {
                "id": requirement["id"],
                "checkType": "requirement",
                "sourceType": source_type,
                "sourceId": requirement.get("sourceId"),
                "semanticType": requirement.get("semanticType"),
                "sceneOrder": requirement.get("sceneOrder"),
                "label": requirement["label"],
                "status": "included" if included else "attention",
                "severity": "info" if included or applicability == "reference" else "warning",
                "applicability": applicability,
                "message": (
                    "已进入本次生成提示词。"
                    if included
                    else "内容受上下文预算裁剪影响，未完整进入提示词，请缩短规划后重试。"
                ),
                "expected": expected,
                "expectedTruncated": any(len(value) > 240 for value in raw_expected),
                "evidence": expected if included else [],
            }
        )
    checks.extend(_scene_contract_specificity_checks(checks))
    return {
        "stage": "prompt",
        "task": task,
        "blocking": False,
        "status": "needs_attention"
        if any(check["status"] == "attention" and check["severity"] == "warning" for check in checks)
        else "ready",
        "summary": _summary(checks, stage="prompt"),
        "checks": checks,
    }


def _outline_dramatic_requirements(
    outline_nodes: list[str],
    source_id: str | None,
) -> list[dict[str, Any]]:
    """Turn legacy structural outline lines into auditable drama contracts.

    Imported projects often predate scene cards.  Their outline still carries
    the most important dramatic promises, so keep those promises in the same
    coverage and post-draft checks as scene-card requirements.
    """
    if not source_id:
        return []
    labels: tuple[tuple[str, str, str], ...] = (
        ("开场压力：", "opening_pressure", "开场压力"),
        ("主角策略：", "strategy", "主角策略"),
        ("策略失效：", "turn", "策略失效"),
        ("两难选择：", "choice", "两难选择"),
        ("即时代价：", "cost", "即时代价"),
        ("章末钩子（", "hook", "章末钩子"),
        ("章末钩子：", "hook", "章末钩子"),
        ("章末未决问题：", "unresolved_question", "章末未决问题"),
    )
    requirements: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw_node in outline_nodes:
        node = str(raw_node).strip()
        for prefix, semantic_type, label in labels:
            if not node.startswith(prefix):
                continue
            value = node[len(prefix) :].strip().rstrip("】")
            if not value:
                continue
            key = f"{semantic_type}:{value}"
            if key in seen:
                continue
            seen.add(key)
            requirements.append(
                {
                    "id": f"outline.{source_id}.{semantic_type}",
                    "sourceType": "outline",
                    "sourceId": source_id,
                    "label": label,
                    "expected": [value],
                    "semanticType": semantic_type,
                }
            )
            break
    return requirements


def _salient_terms(values: list[str]) -> list[str]:
    terms: list[str] = []
    for value in values:
        for latin in re.findall(r"[A-Za-z0-9][A-Za-z0-9_-]{2,}", value):
            terms.append(latin.lower())
        for run in re.findall(r"[\u3400-\u9fff]+", value):
            if len(run) <= 4:
                terms.append(run)
            width = 2
            terms.extend(run[index : index + width] for index in range(len(run) - width + 1))
    unique: list[str] = []
    for term in terms:
        if term in _COMMON_BIGRAMS or term in unique:
            continue
        unique.append(term)
        if len(unique) >= 24:
            break
    return unique


def _scene_contract_specificity_checks(
    requirements: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Warn when a scene card describes drama as an abstract writing task."""
    by_scene: dict[str, dict[str, dict[str, Any]]] = {}
    for item in requirements:
        if item.get("checkType") != "requirement" or item.get("semanticType") not in {"turn", "hook"}:
            continue
        source_id = str(item.get("sourceId") or "")
        if source_id:
            by_scene.setdefault(source_id, {})[str(item["semanticType"])] = item

    checks: list[dict[str, Any]] = []
    for source_id, fields in by_scene.items():
        weak_fields: list[str] = []
        evidence: list[str] = []
        for semantic_type, item in fields.items():
            value = " ".join(str(part) for part in item.get("expected", [])).strip()
            abstract = [marker for marker in _ABSTRACT_CONTRACT_MARKERS if marker in value]
            has_action = any(marker in value for marker in _HOOK_ACTION_MARKERS)
            if len(value) < 12 or (abstract and not has_action):
                weak_fields.append("转折" if semantic_type == "turn" else "钩子")
                if abstract:
                    evidence.append(f"{semantic_type}: " + "、".join(abstract[:3]))
                elif value:
                    evidence.append(f"{semantic_type}: 内容过短")
                else:
                    evidence.append(f"{semantic_type}: 未填写")
        if weak_fields:
            order = next((item.get("sceneOrder") for item in fields.values() if item.get("sceneOrder") is not None), None)
            checks.append(
                {
                    "id": f"scene.{source_id}.dramatic_contract",
                    "checkType": "quality",
                    "sourceType": "scene",
                    "sourceId": source_id,
                    "semanticType": "dramatic_contract",
                    "sceneOrder": order,
                    "label": f"场景 {order or '?'} · 戏剧契约具体度",
                    "status": "author_review",
                    "severity": "warning",
                    "applicability": "chapter",
                    "message": (
                        "场景卡的" + "、".join(dict.fromkeys(weak_fields)) +
                        "仍是抽象写作要求；请补成具体人物、动作、阻力和代价，再生成正文。"
                    ),
                    "expected": [],
                    "evidence": evidence,
                }
            )
    return checks


def _narrative_vitality_checks(content: str) -> list[dict[str, Any]]:
    """Surface deterministic symptoms of report-like, low-drama prose.

    This is deliberately a review signal rather than an automatic rejection:
    procedural language can be valid in courtroom or investigation scenes, but
    a dense cluster gives the author a concrete reason to inspect the draft.
    """
    cjk_count = len(re.findall(r"[\u3400-\u9fff]", content or ""))
    if cjk_count < 600:
        return []

    term_counts = {term: content.count(term) for term in _PROCEDURAL_TERMS}
    hits = sum(term_counts.values())
    density = hits * 1000 / max(cjk_count, 1)
    used = [term for term, count in term_counts.items() if count]
    report_like = density >= 18 and len(used) >= 5
    checks: list[dict[str, Any]] = [
        {
            "id": "quality.procedural_density",
            "checkType": "quality",
            "sourceType": "quality",
            "sourceId": None,
            "label": "戏剧张力",
            "status": "author_review" if report_like else "evidence_found",
            "severity": "warning" if report_like else "info",
            "message": (
                "候选中过多篇幅用于登记、核验、责任或费用说明，可能读成办事记录；请确认是否有主动对手、"
                "升级压力、不可逆选择和情绪兑现。"
                if report_like
                else "未发现流程词汇明显挤占故事篇幅。"
            ),
            "expected": [],
            "evidence": [
                f"每千字流程词约 {density:.1f} 次",
                *[f"{term}×{term_counts[term]}" for term in used[:8]],
            ],
        }
    ]

    thesis_count = content.count("不等于")
    ending = content[-1600:]
    checklist_ending = bool(_CHECKLIST_ENDING.search(ending)) and any(
        term in ending for term in _PROCEDURAL_TERMS
    )
    summary_ending = thesis_count >= 3 or checklist_ending
    checks.append(
        {
            "id": "quality.report_ending",
            "checkType": "quality",
            "sourceType": "quality",
            "sourceId": None,
            "label": "章末钩子",
            "status": "author_review" if summary_ending else "evidence_found",
            "severity": "warning" if summary_ending else "info",
            "message": (
                "章末出现规则复述、待办清单或反复使用“不等于”，可能没有落在人物选择或对手行动上。"
                if summary_ending
                else "未发现明显的报告式章末。"
            ),
            "expected": [],
            "evidence": [
                f"全文“不等于”×{thesis_count}",
                f"章末待办清单：{'是' if checklist_ending else '否'}",
            ],
        }
    )
    return checks


def _ending_hook_evidence(text: str) -> dict[str, Any]:
    """Measure whether the final beat is an actionable story debt.

    A final question is not enough: a character can recognize somebody and ask
    "how could they be here?" without creating any pressure for the next
    chapter. Keep this lexical and explainable, but require either an external
    pressure/decision or a concrete contradiction before calling it strong.
    """
    tail = text[-1200:]
    ending = tail[-420:].strip()
    ending_sentences = [item for item in re.findall(r"[^。！？!?]+[。！？!?]?", ending) if item.strip()]
    final_sentence = ending_sentences[-1] if ending_sentences else ending
    final_beat = "".join(ending_sentences[-2:])[-240:] if ending_sentences else ending[-240:]
    unresolved = [marker for marker in _HOOK_MARKERS if marker in tail]
    actions = [marker for marker in _HOOK_ACTION_MARKERS if marker in final_beat]
    pressure = [marker for marker in _HOOK_PRESSURE_MARKERS if marker in final_sentence]
    weak_recognition = bool(_RECOGNITION_ONLY_HOOK.search(ending)) or bool(
        re.search(
            r"(?:认出|认出了|看清|想起)[^！？?]{0,80}(?:是[^。！？!?]{0,24}[。！？!?])?"
            r"(?:他|她|这人|那人)?[^。！？!?]{0,18}(?:怎么会在|为何在|为什么在)[^。！？!?]{0,18}[？?]$",
            ending,
            flags=re.S,
        )
    )
    abstract_ending = bool(_ABSTRACT_ENDING.search(final_beat))
    concrete_contradiction = bool(
        re.search(
            r"(?:已故|死去|十年前|多年以前|陌生(?:私)?印|假印|缺页|空白|血迹|密信|名单|尸体)",
            ending,
        )
    )
    question = bool(re.search(r"[？?]", ending)) or bool(
        re.search(r"(?:谁会|为何|为什么|怎么(?:办|做)|是否|还没|尚未|来不及|必须在|哪里|哪儿|何处|去哪)", ending)
    )
    # Distinguish an action already in motion from a plan.  This is the key
    # failure mode in otherwise polished chapters: "跟上去看看" describes an
    # intention, while "马车已经转向" creates an immediate story debt.
    final_actions = [marker for marker in _HOOK_ACTION_MARKERS if marker in final_sentence]
    intent_in_final = any(marker in final_sentence for marker in _HOOK_INTENT_MARKERS)
    intent_before_action = bool(
        re.search(
            r"(?:准备|打算|想要|将要|计划|想看看|再去)[^。！？!?]{0,24}"
            r"(?:跟上|追踪|转移|运往|追上|截住|盯梢|打开|闯入)",
            final_sentence,
        )
    )
    concrete_event = bool(_CONCRETE_HOOK_EVENT.search(final_sentence))
    started_action = bool(actions) and (
        (
            bool(final_actions)
            and any(marker in final_sentence for marker in ("已经", "正在", "刚", "冲", "跟上", "追", "转移", "运往", "截住"))
        )
        or any(marker in final_sentence for marker in _HOOK_PRESSURE_MARKERS)
        # A preceding sentence may launch the action, but the last sentence
        # must then carry the unresolved pressure and cannot be plan-only.
        or (not intent_in_final and any(marker in final_beat for marker in ("已经", "正在", "刚", "冲", "跟上", "追", "转移", "运往", "截住")))
        or concrete_event
    )
    plan_only = intent_before_action or (
        intent_in_final
        and not final_actions
        and not any(marker in final_sentence for marker in _HOOK_PRESSURE_MARKERS)
    )
    if intent_before_action and not any(marker in final_sentence for marker in _HOOK_PRESSURE_MARKERS):
        started_action = False
    strong = (
        started_action
        and (bool(pressure) or concrete_contradiction or question)
        and not plan_only
        and not weak_recognition
        and not abstract_ending
    )
    return {
        "unresolved": unresolved,
        "actions": actions,
        "pressure": pressure,
        "question": question,
        "weakRecognition": weak_recognition,
        "abstractEnding": abstract_ending,
        "concreteContradiction": concrete_contradiction,
        "startedAction": started_action,
        "concreteEvent": concrete_event,
        "planOnly": plan_only,
        "strong": strong,
    }


def extract_dramatic_fingerprint(text: str) -> dict[str, Any]:
    """Extract bounded structure signals from accepted prose.

    Imported and older chapters often have no scene-card contract. Looking at
    their prose prevents a rotating catalog label from hiding that several
    chapters replay the same access, verification, or capture scene.
    """
    visible = re.sub(r"\s+", "", text or "")
    scored: list[tuple[str, int, list[str]]] = []
    for name, markers in _DRAMATIC_MOTIFS.items():
        hits = [marker for marker in markers if marker in visible]
        score = sum(min(3, visible.count(marker)) for marker in hits)
        if score >= 2:
            scored.append((name, score, hits[:6]))
    scored.sort(key=lambda item: (-item[1], item[0]))
    hook = _ending_hook_evidence(visible)
    if hook["abstractEnding"]:
        hook_type = "抽象总结"
    elif hook["weakRecognition"]:
        hook_type = "识人问句"
    elif any(
        marker in visible[-240:]
        for marker in ("追骑", "追兵", "截住", "交出保村", "保护公函")
    ):
        hook_type = "关系威胁"
    elif any(marker in visible[-420:] for marker in ("倒计时", "期限", "一刻钟", "香灭", "之前", "之内")):
        hook_type = "倒计时"
    elif hook["concreteContradiction"]:
        hook_type = "证据或身份矛盾"
    elif hook["strong"]:
        hook_type = "已启动威胁"
    elif hook["question"]:
        hook_type = "单独问句"
    else:
        hook_type = "无有效钩子"
    return {
        "dominantMotif": scored[0][0] if scored else "",
        "motifs": [name for name, _, _ in scored[:3]],
        "motifEvidence": [
            {"motif": name, "score": score, "markers": hits}
            for name, score, hits in scored[:3]
        ],
        "hookType": hook_type,
    }


def _recent_chapter_similarity_checks(
    text: str,
    prompt_coverage: dict[str, Any],
) -> list[dict[str, Any]]:
    recent = prompt_coverage.get("recentDramaticPatterns")
    if not isinstance(recent, list) or not recent:
        return []
    current = extract_dramatic_fingerprint(text)
    comparable = [
        item
        for item in recent
        if isinstance(item, dict) and isinstance(item.get("bodyFingerprint"), dict)
    ]
    if not comparable:
        return []
    checks: list[dict[str, Any]] = []
    dominant = str(current.get("dominantMotif") or "")
    current_motifs = set(current.get("motifs") or [])
    repeated = [
        item
        for item in comparable
        if item["bodyFingerprint"].get("dominantMotif") == dominant
    ]
    previous = comparable[-1]
    previous_motifs = set(previous["bodyFingerprint"].get("motifs") or [])
    adjacent_overlap = len(current_motifs & previous_motifs)
    same_adjacent_engine = bool(dominant) and previous["bodyFingerprint"].get("dominantMotif") == dominant
    if dominant and (len(repeated) >= 2 or (same_adjacent_engine and adjacent_overlap >= 2)):
        chapter_labels = [
            f"第{item.get('chapterIndex')}章《{item.get('chapterTitle', '')}》"
            for item in repeated[-3:]
        ]
        checks.append(
            {
                "id": "quality.recent_chapter_repetition",
                "checkType": "quality",
                "sourceType": "quality",
                "sourceId": None,
                "label": "近期章节结构重复",
                "status": "author_review",
                "severity": "warning",
                "message": "候选稿与近期章节复用了同一主要戏剧机制；请更换冲突载体、破局方式或人物代价后再采纳。",
                "expected": [],
                "evidence": [
                    f"本章主要机制：{dominant}",
                    "共同机制：" + "、".join(sorted(current_motifs & previous_motifs)),
                    "近期同类：" + "、".join(chapter_labels),
                ],
            }
        )

    # A rotating outline label can hide that the prose repeatedly lands on the
    # same kind of story debt. Use the accepted body fingerprint as the source
    # of truth and make adjacent reuse reviewable even when the surrounding
    # scene motif changed.
    weak_hook_types = {"", "无有效钩子", "单独问句", "识人问句", "抽象总结"}
    current_hook = str(current.get("hookType") or "")
    if current_hook not in weak_hook_types:
        same_hook = [
            item
            for item in comparable
            if str(item["bodyFingerprint"].get("hookType") or "") == current_hook
        ]
        previous_hook = str(previous["bodyFingerprint"].get("hookType") or "")
        if previous_hook == current_hook or len(same_hook) >= 2:
            hook_labels = [
                f"第{item.get('chapterIndex')}章《{item.get('chapterTitle', '')}》"
                for item in same_hook[-3:]
            ]
            checks.append(
                {
                    "id": "quality.recent_hook_repetition",
                    "checkType": "quality",
                    "sourceType": "quality",
                    "sourceId": None,
                    "label": "近期章尾钩子重复",
                    "status": "author_review",
                    "severity": "warning",
                    "message": "候选稿与近期正文形成了同一种章尾追读债；请改换由不同人物选择、对手行动或损失触发的钩子。",
                    "expected": [],
                    "evidence": [
                        f"本章实际钩子：{current_hook}",
                        "近期同类：" + "、".join(hook_labels),
                    ],
                }
            )
    return checks


def _structural_quality_checks(text: str, *, is_chapter: bool) -> list[dict[str, Any]]:
    """Check the minimum dramatic beats that lexical coverage cannot prove."""
    if not is_chapter or len(text) < 300:
        return []
    visible = re.sub(r"\s+", "", text)
    opening = visible[:300]
    opening_pressure = any(marker in opening for marker in (*_HOOK_PRESSURE_MARKERS, *_TURN_MARKERS))
    midpoint = visible[len(visible) // 2 :]
    sentences = [item for item in re.split(r"[。！？!?；]", midpoint) if item.strip()]
    decision_sentences = [
        sentence
        for sentence in sentences
        if any(marker in sentence for marker in _DECISION_MARKERS)
        or ("选择" in sentence and any(marker in sentence for marker in ("要么", "还是", "或", "换")))
    ]
    decision = bool(decision_sentences)
    cost = any(any(marker in sentence for marker in _COST_MARKERS) for sentence in decision_sentences)
    decision_evidence = [
        marker
        for marker in _DECISION_MARKERS
        if any(marker in sentence for sentence in decision_sentences)
    ]
    cost_evidence = [
        marker
        for marker in _COST_MARKERS
        if any(marker in sentence for sentence in decision_sentences)
    ]
    loop_hits = [marker for marker in _EXPOSITION_LOOP_MARKERS if visible.count(marker) >= 2]
    checks = [
        {
            "id": "quality.opening_pressure",
            "checkType": "quality",
            "sourceType": "quality",
            "sourceId": None,
            "label": "开场压力",
            "status": "evidence_found" if opening_pressure else "author_review",
            "severity": "info" if opening_pressure else "warning",
            "message": (
                "前300字出现了行动或压力信号。"
                if opening_pressure
                else "前300字缺少可见压力或行动，开场可能在复述背景。"
            ),
            "expected": [],
            "evidence": ["开场压力：" + ("是" if opening_pressure else "否")],
        },
        {
            "id": "quality.irreversible_choice",
            "checkType": "quality",
            "sourceType": "quality",
            "sourceId": None,
            "label": "不可逆选择",
            "status": "evidence_found" if decision and cost else "author_review",
            "severity": "info" if decision and cost else "warning",
            "message": (
                "后半段同时出现了行动选择和可见代价。"
                if decision and cost
                else "后半段没有同时找到具体选择与代价；章节可能只有信息推进，没有真正改变局势。"
            ),
            "expected": [],
            "evidence": [
                "选择信号：" + ("、".join(decision_evidence) if decision_evidence else "未找到"),
                "代价信号：" + ("、".join(cost_evidence) if cost_evidence else "未找到"),
            ],
        },
    ]
    if len(loop_hits) >= 3:
        checks.append(
            {
                "id": "quality.exposition_loop",
                "checkType": "quality",
                "sourceType": "quality",
                "sourceId": None,
                "label": "解释循环",
                "status": "author_review",
                "severity": "warning",
                "message": "多组拒绝、解释和追问反复出现，可能把一次冲突拆成了几轮同质化说明；请确认每轮是否改变了条件。",
                "expected": [],
                "evidence": [f"{marker}×{visible.count(marker)}" for marker in loop_hits],
            }
        )
    return checks


def _dramatic_contract_checks(content: str, prompt_coverage: dict[str, Any]) -> list[dict[str, Any]]:
    """Surface weak turn/hook evidence without pretending to judge semantics.

    A model can repeat a scene-card sentence verbatim while keeping the story's
    state unchanged. These checks therefore inspect *where* evidence appears:
    a turn should have a late transition plus an action/choice, and a hook should
    leave a concrete unresolved pressure in the final part of the draft. They
    remain author-review warnings, never automatic acceptance decisions.
    """
    text = content or ""
    if len(text) < 300:
        return []
    checks: list[dict[str, Any]] = []
    requirements = [
        item for item in prompt_coverage.get("checks", [])
        if isinstance(item, dict) and item.get("checkType") == "requirement"
    ]
    turn_requirements = [item for item in requirements if item.get("semanticType") == "turn"]
    hook_requirements = [item for item in requirements if item.get("semanticType") == "hook"]

    if turn_requirements:
        midpoint = max(1, len(text) // 2)
        late = text[midpoint:]
        transitions = [marker for marker in _TURN_MARKERS if marker in late]
        actions = [marker for marker in _HOOK_ACTION_MARKERS if marker in late]
        checks.append(
            {
                "id": "quality.turning_point",
                "checkType": "quality",
                "sourceType": "scene",
                "sourceId": turn_requirements[0].get("sourceId"),
                "label": "中段转折落地",
                "status": "evidence_found" if transitions and actions else "author_review",
                "severity": "info" if transitions and actions else "warning",
                "message": (
                    "后半段同时出现了状态转向和行动证据；仍需确认原策略是否真的失效。"
                    if transitions and actions
                    else "后半段缺少成对的状态转向与行动证据；转折可能只是新增信息或旁白宣告。"
                ),
                "expected": [],
                "evidence": [
                    "转向词：" + "、".join(transitions[:6]) if transitions else "未找到明显转向词",
                    "行动词：" + "、".join(actions[:6]) if actions else "未找到明显选择/后果行动",
                ],
            }
        )

    if hook_requirements:
        evidence = _ending_hook_evidence(text)
        unresolved = evidence["unresolved"]
        actions = evidence["actions"]
        strong = evidence["strong"]
        checks.append(
            {
                "id": "quality.chapter_hook",
                "checkType": "quality",
                "sourceType": "scene",
                "sourceId": hook_requirements[-1].get("sourceId"),
                "label": "章尾具体追读问题",
                "status": "evidence_found" if strong else "author_review",
                "severity": "info" if strong else "warning",
                "message": (
                    "章尾附近同时出现了未决压力和具体行动；请确认下一章问题尚未被提前解决。"
                    if strong
                    else "章尾未形成可执行的追读债；仅有熟人现身或问句不算有效钩子。"
                ),
                "expected": [],
                "evidence": [
                    "未决信号：" + "、".join(unresolved[:8]) if unresolved else "未找到未决信号",
                    "动作信号：" + "、".join(actions[:8]) if actions else "未找到章尾动作信号",
                    "外部压力：" + "、".join(evidence["pressure"][:8]) if evidence["pressure"] else "未找到",
                    "识人问句：" + ("是" if evidence["weakRecognition"] else "否"),
                    "总结式收尾：" + ("是" if evidence["abstractEnding"] else "否"),
                    "具体矛盾证据：" + ("是" if evidence["concreteContradiction"] else "否"),
                    "动作已启动：" + ("是" if evidence["startedAction"] else "否"),
                    "仅计划表达：" + ("是" if evidence["planOnly"] else "否"),
                ],
            }
        )
    elif prompt_coverage.get("task") == "chapter" or (
        "task" not in prompt_coverage
        and any(
            item.get("checkType") == "requirement"
            and item.get("applicability") in {None, "chapter"}
            for item in prompt_coverage.get("checks", [])
            if isinstance(item, dict)
        )
    ):
        # Legacy chapters frequently have no scene-card hook at all.  They
        # still need a visible ending contract; otherwise the model tends to
        # close with a summary or another round of routine exposition.
        evidence = _ending_hook_evidence(text)
        question = evidence["question"]
        actions = evidence["actions"]
        strong = evidence["strong"]
        checks.append(
            {
                "id": "quality.chapter_hook_presence",
                "checkType": "quality",
                "sourceType": "quality",
                "sourceId": None,
                "label": "章尾钩子存在性",
                "status": "evidence_found" if strong else "author_review",
                "severity": "info" if strong else "warning",
                "message": (
                    "章尾有具体动作和未决问题；请确认问题尚未被正文提前回答。"
                    if strong
                    else "本章没有有效的可执行钩子；章尾需要具体动作+未决问题，熟人现身、离场或单独问句不足以推动下一章。"
                ),
                "expected": [],
                "evidence": [
                    "未决问题：" + ("是" if question else "否"),
                    "动作信号：" + "、".join(actions[:8]) if actions else "未找到章尾动作信号",
                    "外部压力：" + "、".join(evidence["pressure"][:8]) if evidence["pressure"] else "未找到",
                    "识人问句：" + ("是" if evidence["weakRecognition"] else "否"),
                    "总结式收尾：" + ("是" if evidence["abstractEnding"] else "否"),
                    "具体矛盾证据：" + ("是" if evidence["concreteContradiction"] else "否"),
                    "动作已启动：" + ("是" if evidence["startedAction"] else "否"),
                    "仅计划表达：" + ("是" if evidence["planOnly"] else "否"),
                ],
            }
        )
    checks.extend(
        _structural_quality_checks(
            text,
            is_chapter=prompt_coverage.get("task") == "chapter",
        )
    )
    return checks


def assess_draft_coverage(prompt_coverage: dict[str, Any] | None, content: str) -> dict[str, Any] | None:
    """Turn a stored prompt report into a conservative draft-review report."""
    if not prompt_coverage:
        return None
    normalized_content = (content or "").lower()
    checks: list[dict[str, Any]] = []
    for original in prompt_coverage.get("checks", []):
        if original.get("checkType") != "requirement":
            checks.append(dict(original))
            continue

        check = dict(original)
        expected = [str(value) for value in check.get("expected", []) if str(value).strip()]
        terms = _salient_terms(expected)
        matches = [term for term in terms if term.lower() in normalized_content]
        is_reference = check.get("applicability") == "reference"
        # Two separate terms reduce false positives from common two-character words.
        evidence_found = len(matches) >= 2 or (len(matches) == 1 and len(matches[0]) >= 4)
        if evidence_found:
            check.update(
                status="evidence_found",
                severity="info",
                message="候选中找到相关字面证据；仍建议结合上下文确认语义是否真正兑现。",
                evidence=matches[:8],
            )
        else:
            check.update(
                status="author_review",
                severity="info" if check.get("sourceType") == "positioning" or is_reference else "warning",
                message=(
                    "行内任务不要求覆盖整章规划，此项仅作为一致性参考。"
                    if is_reference
                    else "未找到足够字面证据；可能使用了同义改写，请作者确认后再采纳。"
                ),
                evidence=[],
            )
        checks.append(check)

    meta_matches = list(_NARRATIVE_META.finditer(content or ""))
    if meta_matches:
        checks.append({
            "id": "quality.narrative_meta",
            "checkType": "quality",
            "sourceType": "quality",
            "sourceId": None,
            "label": "叙述穿帮与生成说明",
            "status": "author_review",
            "severity": "warning",
            "message": "疑似把章节编号或生成说明写进了故事。请改为故事内的事件锚点；若是人物讨论书籍或有意打破第四面墙，请结合语境确认。",
            "expected": [],
            "evidence": [content[max(0, match.start() - 16):match.end() + 40] for match in meta_matches[:3]],
        })
    checks.extend(_narrative_vitality_checks(content))
    checks.extend(_dramatic_contract_checks(content, prompt_coverage))
    checks.extend(_recent_chapter_similarity_checks(content, prompt_coverage))
    return {
        "stage": "draft",
        "blocking": False,
        "status": "needs_attention"
        if any(check["status"] in {"attention", "author_review"} and check["severity"] == "warning" for check in checks)
        else "ready",
        "summary": _summary(checks, stage="draft"),
        "checks": checks,
        "method": "lexical_evidence_v2_dramatic_contract",
        "disclaimer": "字面证据只能辅助复核，不能替代作者对情节兑现和语义一致性的判断。",
    }
