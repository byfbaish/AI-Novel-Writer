from services.generation_coverage import (
    assess_draft_coverage,
    build_prompt_coverage,
    extract_dramatic_fingerprint,
)


def _report(text: str) -> dict:
    result = assess_draft_coverage(
        {"checks": []},
        text,
    )
    assert result is not None
    return result


def test_draft_flags_chapter_numbers_leaking_into_character_memory():
    text = "她看着信号，想起第四章里伪装救援艇的姿态喷口。"
    report = _report(text)
    check = next(item for item in report["checks"] if item["id"] == "quality.narrative_meta")
    assert check["status"] == "author_review"
    assert text in check["evidence"][0]
    assert report["status"] == "needs_attention"


def test_draft_flags_generated_prefaces_and_previous_chapter_references():
    for text in ("以下是本章正文。", "她记得上一章中留下的伤口。", "作为一个语言模型，我会继续故事。"):
        assert any(item["id"] == "quality.narrative_meta" for item in _report(text)["checks"])


def test_draft_preserves_in_world_recollections_and_document_chapters():
    text = "她想起撤离时那艘假救援艇。维修手册第四章里记着电路图，她翻开第四章逐行查找。"
    assert not any(item["id"] == "quality.narrative_meta" for item in _report(text)["checks"])


def _dramatic_report(text: str) -> dict:
    result = assess_draft_coverage(
        {
            "checks": [
                {
                    "id": "scene.1.turn",
                    "checkType": "requirement",
                    "sourceType": "scene",
                    "sourceId": "scene-1",
                    "semanticType": "turn",
                    "expected": ["原计划失效"],
                },
                {
                    "id": "scene.1.hook",
                    "checkType": "requirement",
                    "sourceType": "scene",
                    "sourceId": "scene-1",
                    "semanticType": "hook",
                    "expected": ["明日必须回应谁会来】"],
                },
            ]
        },
        text,
    )
    assert result is not None
    return result


def test_draft_coverage_warns_when_procedure_replaces_drama():
    paragraph = (
        "沈砚秋登记袋号，核验时辰，再把复称结果、保管费用、交接责任和县衙文书逐项写入凭据。"
        "她说明送达不等于执行，复称不等于开袋，保管不等于货权。"
    )
    report = _report(paragraph * 40 + "\n一，明日继续核验费用；二，重新登记袋号。")

    by_id = {item["id"]: item for item in report["checks"]}
    assert by_id["quality.procedural_density"]["status"] == "author_review"
    assert by_id["quality.report_ending"]["status"] == "author_review"
    assert report["status"] == "needs_attention"


def test_draft_coverage_counts_document_workflow_terms():
    paragraph = (
        "沈砚秋继续阅卷，把副本编号写入条款，再请两名见证人复核。"
        "众人随后翻到下一份副本，重新核对编号与见证。"
    )
    report = _report(paragraph * 35)

    check = next(item for item in report["checks"] if item["id"] == "quality.procedural_density")
    assert check["status"] == "author_review"
    assert any(item.startswith("阅卷×") for item in check["evidence"])


def test_draft_coverage_does_not_warn_on_action_and_relationship_scene():
    paragraph = (
        "山火越过田埂时，沈禾把最后一桶水推给嫂子，自己转身去解牛绳。"
        "周万成挡在门口，要她拿祖宅换粮。她当众撕掉契纸，却把唯一的退路也烧了。"
        "嫂子没有道谢，只抓住她被烫伤的手，说今晚一起守田。"
    )
    report = _report(paragraph * 18)

    by_id = {item["id"]: item for item in report["checks"]}
    assert by_id["quality.procedural_density"]["status"] == "evidence_found"
    assert by_id["quality.report_ending"]["status"] == "evidence_found"
    assert report["status"] == "ready"


def test_draft_coverage_surfaces_weak_turn_and_hook_structure():
    report = _dramatic_report("她把账册收好，说明明日继续核验。" * 80)

    by_id = {item["id"]: item for item in report["checks"]}
    assert by_id["quality.turning_point"]["status"] == "author_review"
    assert by_id["quality.chapter_hook"]["status"] == "author_review"
    assert report["method"] == "lexical_evidence_v2_dramatic_contract"


def test_draft_coverage_recognizes_action_backed_turn_and_opening_hook():
    text = (
        "她原本要把契纸送进县衙，却在门口发现印记是假的。"
        "沈禾转身撕掉旧路线，改从河埠头闯出去，身后的差役已经扣住了粮车。"
        "她按住门闩，门外脚步越来越近，明日谁会先拿出第二份契纸？"
    ) * 20
    report = _dramatic_report(text)

    by_id = {item["id"]: item for item in report["checks"]}
    assert by_id["quality.turning_point"]["status"] == "evidence_found"
    assert by_id["quality.chapter_hook"]["status"] == "evidence_found"


def test_prompt_coverage_warns_on_abstract_scene_contract():
    report = build_prompt_coverage(
        {
            "inputChecks": [],
            "requirements": [
                {
                    "id": "scene-1-turn",
                    "checkType": "requirement",
                    "sourceType": "scene",
                    "sourceId": "scene-1",
                    "semanticType": "turn",
                    "sceneOrder": 1,
                    "label": "场景 1 · 转折",
                    "expected": ["本章推进收束，留下下一章必须回应的具体决定"],
                },
                {
                    "id": "scene-1-hook",
                    "checkType": "requirement",
                    "sourceType": "scene",
                    "sourceId": "scene-1",
                    "semanticType": "hook",
                    "sceneOrder": 1,
                    "label": "场景 1 · 钩子",
                    "expected": ["章末留下后果"],
                },
            ],
        },
        included_content="本章推进收束，留下下一章必须回应的具体决定章末留下后果",
        task="chapter",
    )

    contract = next(item for item in report["checks"] if item["id"] == "scene.scene-1.dramatic_contract")
    assert contract["status"] == "author_review"
    assert contract["severity"] == "warning"


def test_prompt_coverage_accepts_concrete_scene_contract():
    report = build_prompt_coverage(
        {
            "inputChecks": [],
            "requirements": [
                {
                    "id": "scene-1-turn",
                    "checkType": "requirement",
                    "sourceType": "scene",
                    "sourceId": "scene-1",
                    "semanticType": "turn",
                    "sceneOrder": 1,
                    "label": "场景 1 · 转折",
                    "expected": ["巡核使扣下田契，沈砚秋撕掉旧账并当众改押自己的名字"],
                },
                {
                    "id": "scene-1-hook",
                    "checkType": "requirement",
                    "sourceType": "scene",
                    "sourceId": "scene-1",
                    "semanticType": "hook",
                    "sceneOrder": 1,
                    "label": "场景 1 · 钩子",
                    "expected": ["巡核使点燃香：香灭前要账还是要人"],
                },
            ],
        },
        included_content="巡核使扣下田契，沈砚秋撕掉旧账并当众改押自己的名字巡核使点燃香：香灭前要账还是要人",
        task="chapter",
    )

    assert not any(item["id"] == "scene.scene-1.dramatic_contract" for item in report["checks"])


def test_prompt_coverage_audits_legacy_outline_drama_nodes():
    outline = [
        "开场压力：粮车在村口被扣",
        "主角策略：让见证人公开复述扣车经过",
        "策略失效：差役拿出伪造的县印，见证人当场改口",
        "两难选择：交出田契换粮车，或保住田契让全村断粮",
        "即时代价：沈禾撕掉唯一的通行凭据",
        "章末钩子（倒计时）：香灭前必须决定是否打开粮仓",
        "章末未决问题：粮仓里是谁提前藏进了官印",
    ]
    included = "\n".join(outline)
    report = build_prompt_coverage(
        {"inputChecks": [], "requirements": []},
        included_content=included,
        task="chapter",
        outline_nodes=outline,
        outline_source_id="chapter-legacy",
    )

    requirements = {
        check["id"]: check
        for check in report["checks"]
        if check["checkType"] == "requirement"
    }
    assert requirements["outline.chapter-legacy.turn"]["status"] == "included"
    assert requirements["outline.chapter-legacy.hook"]["status"] == "included"
    assert requirements["outline.chapter-legacy.unresolved_question"]["status"] == "included"


def test_legacy_outline_weak_hook_is_reviewed_in_draft():
    outline = ["策略失效：局势变化", "章末钩子：制造悬念"]
    report = build_prompt_coverage(
        {"inputChecks": [], "requirements": []},
        included_content="\n".join(outline),
        task="chapter",
        outline_nodes=outline,
        outline_source_id="chapter-weak",
    )
    draft = assess_draft_coverage(report, "她收好账册，明日继续核验。" * 100)

    assert draft is not None
    by_id = {check["id"]: check for check in draft["checks"]}
    assert by_id["quality.turning_point"]["status"] == "author_review"
    assert by_id["quality.chapter_hook"]["status"] == "author_review"


def test_legacy_outline_without_drama_nodes_remains_compatible():
    report = build_prompt_coverage(
        {"inputChecks": [], "requirements": []},
        included_content="沈禾去粮铺谈青谷收购价",
        task="chapter",
        outline_nodes=["沈禾去粮铺谈青谷收购价"],
        outline_source_id="chapter-plain",
    )

    assert not any(
        check["id"].startswith("outline.chapter-plain.") for check in report["checks"]
    )


def test_legacy_chapter_without_hook_contract_is_flagged_at_ending():
    report = assess_draft_coverage(
        {
            "checks": [
                {
                    "id": "positioning.selling_point",
                    "checkType": "requirement",
                    "applicability": "chapter",
                    "expected": ["靠种田救村"],
                }
            ]
        },
        "她把账册收好，明日继续核验。" * 100,
    )

    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "author_review"
    assert report["status"] == "needs_attention"


def test_chapter_without_any_planning_requirements_still_gets_hook_check():
    report = assess_draft_coverage(
        {"task": "chapter", "checks": []},
        "她把账册收好，明日继续核验。" * 100,
    )

    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "author_review"
    assert "具体动作" in check["message"]


def test_hook_action_must_land_in_final_part_of_draft():
    report = assess_draft_coverage(
        {"task": "chapter", "checks": []},
        ("她突然推开门，门外有人吗？" + "她继续解释账册。" * 60),
    )

    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "author_review"


def test_recognition_question_is_not_counted_as_a_real_chapter_hook():
    text = (
        "沈禾在府城门外等了一上午，递状子后只得到等通知的答复。"
        "她回头离开，街上有人撞了她一下。她仔细看了看，忽然认出了那张脸。\n"
        "是林谨言。\n"
        "他怎么会在府城？"
    )
    report = assess_draft_coverage({"task": "chapter", "checks": []}, text * 8)
    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "author_review"
    assert "识人问句：是" in check["evidence"]


def test_chapter_without_choice_and_cost_is_flagged_even_when_it_has_questions():
    text = (
        "她赶到府城，守卫不让她进去。她解释账册，守卫让她按规矩等通知。"
        "她又去找另一位大人，得到同样的答复。她站在街上想自己该怎么办？"
    ) * 12
    report = assess_draft_coverage({"task": "chapter", "checks": []}, text)
    checks = {item["id"]: item for item in report["checks"]}
    assert checks["quality.irreversible_choice"]["status"] == "author_review"
    assert checks["quality.exposition_loop"]["status"] == "author_review"


def test_started_threat_is_a_hook_without_forcing_a_question_mark():
    text = "沈禾撕掉通行证，跟着林谨言走出茶馆。" * 50
    text += "两名衙役已经围住门口，其中一人拔刀扣住车轴：张侍郎只给他们一刻钟。"
    report = assess_draft_coverage({"task": "chapter", "checks": []}, text)
    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "evidence_found"
    assert "未决问题：否" in check["evidence"]


def test_action_before_an_abstract_final_summary_is_not_a_hook():
    text = "沈禾被官差追进巷子，林谨言拔刀拦住来人。" * 50
    text += "林谨言盯着沈禾，眼神里的挣扎越来越明显。沈禾知道，接下来他的选择将决定她的生死。"
    report = assess_draft_coverage({"task": "chapter", "checks": []}, text)
    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "author_review"
    assert "总结式收尾：是" in check["evidence"]


def test_concrete_countdown_after_a_character_realization_remains_a_hook():
    text = "沈禾沿着粮车留下的辙印追到仓门。" * 50
    text += "门外的差役已经点燃一炷香。她知道仓门会在香灭时被撞开，只剩一刻钟。"
    report = assess_draft_coverage({"task": "chapter", "checks": []}, text)
    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "evidence_found"
    assert "总结式收尾：否" in check["evidence"]


def test_a_stare_without_consequence_is_not_a_hook():
    text = "沈禾撕掉旧契，放弃退路，代价是祖宅被扣。" * 50
    text += "林谨言站在门边，盯着她。"

    report = assess_draft_coverage({"task": "chapter", "checks": []}, text)

    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "author_review"


def test_old_threat_before_a_neutral_ending_does_not_count_as_hook():
    text = "差役拔刀围住院门，要她一刻钟内交出账册。" * 45
    text += "沈禾回到房里，把白日听见的每句话重新想了一遍。她吹灭灯，躺下睡了。"

    report = assess_draft_coverage({"task": "chapter", "checks": []}, text)

    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "author_review"


def test_started_route_action_with_unresolved_destination_counts_as_hook():
    text = (
        "沈禾盯着北仓后墙，发现护院已经把赈粮装上马车。"
        "刘崇正压低声音：不能在庄门动手。差役翻身上马，四个人跟上运粮车，"
        "马车拐进夜色，看不出要把粮食运到哪里。"
    )
    report = assess_draft_coverage({"task": "chapter", "checks": []}, text * 8)
    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "evidence_found"
    assert "动作已启动：是" in check["evidence"]


def test_plan_only_route_does_not_count_as_hook():
    text = (
        "沈禾收好证据，准备跟上运粮车，想看看他们会把粮食运到哪里。"
        "她打算明日再查清楚。"
    )
    report = assess_draft_coverage({"task": "chapter", "checks": []}, text * 8)
    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "author_review"
    assert "仅计划表达：是" in check["evidence"]


def test_intent_before_action_does_not_count_as_started_hook():
    text = "她准备跟上运粮车，想看看他们会把粮食运到哪里。" * 16
    report = assess_draft_coverage({"task": "chapter", "checks": []}, text)
    check = next(item for item in report["checks"] if item["id"] == "quality.chapter_hook_presence")
    assert check["status"] == "author_review"


def test_dramatic_fingerprint_reads_actual_access_denial_from_body():
    text = (
        "沈禾到衙门求见刘大人，守卫拒绝通报。她改去递状，"
        "小吏仍让她按规矩回去等通知。"
    ) * 8

    fingerprint = extract_dramatic_fingerprint(text)

    assert fingerprint["dominantMotif"] == "求见受阻"
    assert "账证核验" not in fingerprint["motifs"]


def test_draft_warns_when_actual_recent_chapters_repeat_same_engine():
    recent_fingerprint = {
        "dominantMotif": "求见受阻",
        "motifs": ["求见受阻", "账证核验"],
        "hookType": "单独问句",
    }
    prompt = {
        "task": "chapter",
        "checks": [],
        "recentDramaticPatterns": [
            {"chapterIndex": 14, "chapterTitle": "县衙碰壁", "bodyFingerprint": recent_fingerprint},
            {"chapterIndex": 15, "chapterTitle": "府城递状", "bodyFingerprint": recent_fingerprint},
        ],
    }
    text = (
        "沈禾抱着账册到衙门求见主官，门房不肯通报。她转去递状，"
        "小吏翻了翻文书，让她按规矩回去等通知。"
    ) * 10

    report = assess_draft_coverage(prompt, text)

    assert report is not None
    check = next(item for item in report["checks"] if item["id"] == "quality.recent_chapter_repetition")
    assert check["status"] == "author_review"
    assert "求见受阻" in check["evidence"][0]


def test_draft_does_not_warn_when_new_chapter_changes_dramatic_engine():
    prompt = {
        "task": "chapter",
        "checks": [],
        "recentDramaticPatterns": [
            {
                "chapterIndex": 15,
                "chapterTitle": "府城递状",
                "bodyFingerprint": {
                    "dominantMotif": "求见受阻",
                    "motifs": ["求见受阻", "账证核验"],
                    "hookType": "单独问句",
                },
            }
        ],
    }
    text = (
        "仓门外的人点火烧毁最后一袋麦种，沈禾冲过去抢粮。"
        "她放弃田契换下半车种子，代价是全家再无祖宅可回。"
    ) * 12

    report = assess_draft_coverage(prompt, text)

    assert report is not None
    assert not any(item["id"] == "quality.recent_chapter_repetition" for item in report["checks"])


def test_draft_warns_when_actual_hook_repeats_despite_different_scene_engine():
    prompt = {
        "task": "chapter",
        "checks": [],
        "recentDramaticPatterns": [
            {
                "chapterIndex": 15,
                "chapterTitle": "断粮",
                "bodyFingerprint": {
                    "dominantMotif": "资源危机",
                    "motifs": ["资源危机"],
                    "hookType": "倒计时",
                },
            }
        ],
    }
    text = (
        "沈禾在公堂上逼粮商交出私契，围观村民齐声作证。" * 40
        + "差役已经点燃一炷香，香灭前她必须交出田契，只剩一刻钟。"
    )

    report = assess_draft_coverage(prompt, text)

    assert report is not None
    check = next(item for item in report["checks"] if item["id"] == "quality.recent_hook_repetition")
    assert check["status"] == "author_review"
    assert "倒计时" in check["evidence"][0]


def test_hook_fingerprint_prefers_relationship_threat_over_incidental_countdown():
    text = (
        "张府追骑已经冲进巷口，为首之人拔刀截住唯一出口，"
        "只给他一刻钟交出保村公函。"
    ) * 8

    fingerprint = extract_dramatic_fingerprint(text)

    assert fingerprint["hookType"] == "关系威胁"
