"""Authenticated chapter and inline novel generation endpoints."""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import uuid
from datetime import UTC, datetime
from typing import AsyncIterator, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.auth import (
    ProjectPermission,
    get_current_user,
    verify_chapter_assignment,
    verify_project_permission,
)
from celery_app import celery_app
from config import settings
from db.models_core import Chapter, ChapterBody, Project, User
from db.models_long_generation import GenerationSegment
from db.models_usage import GenerationDraft, GenerationRun
from db.session import AsyncSessionLocal, get_db
from memory.assembler import ContextBudgetPolicy
from memory.tokenizer import tokenizer
from services.chunking import html_to_paragraphs
from services.generation import (
    GenerationGateway,
    GenerationProviderError,
    GenerationRoute,
    GenerationService,
    PromptPackage,
    count_generated_words,
    retryable_stream,
)
from services.generation_coverage import assess_draft_coverage
from services.long_generation import (
    DEFAULT_SEGMENT_WORDS,
    MAX_LONG_WORDS,
    MAX_SEGMENT_WORDS,
    MIN_SEGMENT_WORDS,
    build_context_manifest,
    make_segment_plan,
)
from services.long_generation_executor import (
    SegmentBusyError,
    SegmentCheckpointConflictError,
    SegmentExecutionError,
    SegmentLeaseLostError,
    SegmentMergeBlockedError,
    accept_ready_segment,
    checkpoint_hash,
    checkpoint_segment,
    claim_segment,
    fail_segment,
    heartbeat_segment,
    merge_new_segment_outputs,
    validate_claimed_segment,
)
from services.long_generation_runner import LONG_SEGMENT_LEASE_SECONDS
from services.model_catalog import CODING_PLAN_MODELS
from services.model_configs import active_user_generation_route
from services.provenance import PROVENANCE_ALGORITHM, generated_paragraph_hashes
from services.usage import (
    InsufficientCreditsError,
    UsageReservation,
    record_user_key_generation,
    release_reservation,
    reserve_generation,
    settle_generation,
)
from services.writing_skills import select_writing_skills

router = APIRouter()


class ChapterGenerationRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    chapter_id: str = Field(alias="chapterId", min_length=1, max_length=32)
    target_words: int = Field(alias="targetWords", ge=200, le=20000)
    model: Literal["basic", "advanced"] = "basic"
    provider_model: str | None = Field(None, alias="modelId", min_length=1, max_length=200)
    use_style_profile: bool = Field(True, alias="useStyleProfile")
    dialogue_density: Literal["low", "mid", "high"] = Field("mid", alias="dialogueDensity")
    context_mode: Literal["smart", "fast", "standard", "deep"] = Field(
        "smart", alias="contextMode"
    )
    instruction: str = Field("", max_length=2000)


class InlineGenerationRequest(ChapterGenerationRequest):
    action: Literal["续写", "扩写", "润色", "改写语气", "按我的风格"]
    selected_text: str = Field("", alias="selectedText", max_length=20000)
    nearby_text: str = Field("", alias="nearbyText", max_length=30000)


class GenerationPreviewRequest(BaseModel):
    """Inputs accepted by the no-charge prompt preview endpoint."""

    model_config = ConfigDict(populate_by_name=True)

    chapter_id: str = Field(alias="chapterId", min_length=1, max_length=32)
    target_words: int = Field(alias="targetWords", ge=200, le=20000)
    model: Literal["basic", "advanced"] = "basic"
    provider_model: str | None = Field(None, alias="modelId", min_length=1, max_length=200)
    use_style_profile: bool = Field(True, alias="useStyleProfile")
    dialogue_density: Literal["low", "mid", "high"] = Field("mid", alias="dialogueDensity")
    context_mode: Literal["smart", "fast", "standard", "deep"] = Field(
        "smart", alias="contextMode"
    )
    instruction: str = Field("", max_length=2000)
    action: Literal["续写", "扩写", "润色", "改写语气", "按我的风格"] | None = None
    selected_text: str = Field("", alias="selectedText", max_length=20000)
    nearby_text: str = Field("", alias="nearbyText", max_length=30000)


class DraftReviewUpdateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    segment_ids: list[str] = Field(alias="segmentIds", min_length=1, max_length=500)
    decision: Literal["pending", "accepted", "rejected"]
    base_version: int = Field(alias="baseVersion", ge=0)


class DraftContinueRequest(BaseModel):
    """Options for continuing a failed candidate from its last checkpoint."""

    model_config = ConfigDict(populate_by_name=True)

    target_words: int = Field(alias="targetWords", ge=200, le=20000)
    model: Literal["basic", "advanced"] = "basic"
    provider_model: str | None = Field(None, alias="modelId", min_length=1, max_length=200)
    use_style_profile: bool = Field(True, alias="useStyleProfile")
    dialogue_density: Literal["low", "mid", "high"] = Field("mid", alias="dialogueDensity")
    context_mode: Literal["smart", "fast", "standard", "deep"] = Field(
        "smart", alias="contextMode"
    )
    instruction: str = Field("", max_length=2000)


class LongChapterPlanRequest(BaseModel):
    """Create or inspect the durable segment plan for a long chapter."""

    model_config = ConfigDict(populate_by_name=True)

    chapter_id: str = Field(alias="chapterId", min_length=1, max_length=32)
    target_words: int = Field(alias="targetWords", ge=MIN_SEGMENT_WORDS, le=MAX_LONG_WORDS)
    segment_words: int = Field(DEFAULT_SEGMENT_WORDS, alias="segmentWords", ge=MIN_SEGMENT_WORDS, le=MAX_SEGMENT_WORDS)
    scene_purposes: list[str] = Field(default_factory=list, alias="scenePurposes", max_length=500)
    required_beats: list[str] = Field(default_factory=list, alias="requiredBeats", max_length=500)


class LongSegmentClaimRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    lease_seconds: int = Field(300, alias="leaseSeconds", ge=1, le=3600)
    lease_owner: str | None = Field(None, alias="leaseOwner", min_length=1, max_length=100)


class LongSegmentCheckpointRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    lease_revision: int = Field(alias="leaseRevision", ge=1)
    expected_checkpoint_hash: str = Field(alias="expectedCheckpointHash", min_length=64, max_length=64)
    content_text: str = Field(alias="contentText", max_length=500_000)
    lease_owner: str | None = Field(None, alias="leaseOwner", min_length=1, max_length=100)
    lease_seconds: int = Field(300, alias="leaseSeconds", ge=1, le=3600)


class LongSegmentFailRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    lease_revision: int = Field(alias="leaseRevision", ge=1)
    error_code: str = Field("segment_failed", alias="errorCode", min_length=1, max_length=100)
    lease_owner: str | None = Field(None, alias="leaseOwner", min_length=1, max_length=100)


class LongSegmentValidateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    lease_revision: int = Field(alias="leaseRevision", ge=1)
    required_terms: list[str] = Field(default_factory=list, alias="requiredTerms", max_length=500)
    min_ratio: float = Field(0.55, alias="minRatio", gt=0, le=1)
    max_ratio: float = Field(1.35, alias="maxRatio", ge=1, le=3)
    lease_owner: str | None = Field(None, alias="leaseOwner", min_length=1, max_length=100)


class LongSegmentHeartbeatRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    lease_revision: int = Field(alias="leaseRevision", ge=1)
    lease_owner: str | None = Field(None, alias="leaseOwner", min_length=1, max_length=100)
    lease_seconds: int = Field(300, alias="leaseSeconds", ge=1, le=3600)


class LongSegmentGenerateRequest(BaseModel):
    """Worker options persisted with a claimed segment."""

    model_config = ConfigDict(populate_by_name=True)

    model: Literal["basic", "advanced"] = "basic"
    provider_model: str | None = Field(None, alias="modelId", min_length=1, max_length=200)
    use_style_profile: bool = Field(True, alias="useStyleProfile")
    dialogue_density: Literal["low", "mid", "high"] = Field("mid", alias="dialogueDensity")
    context_mode: Literal["smart", "fast", "standard", "deep"] = Field(
        "smart", alias="contextMode"
    )
    instruction: str = Field("", max_length=2000)


def _normalized_story_text(value: str) -> str:
    """Compare persisted prose without treating HTML whitespace as a fact change."""

    return re.sub(r"\s+", "", value or "")


def _accepted_ledger_mismatch(body: ChapterBody | None, rows: list[GenerationSegment]) -> list[int]:
    """Return accepted segment indexes that are absent from the current body.

    Segment acceptance is an execution-ledger fact, while the chapter body is
    the author-visible source of truth.  A restored/manual body can therefore
    legitimately move backwards while the old ledger remains marked accepted.
    Continuing from that ledger would feed stale events back to the model and
    is worse than stopping with an actionable conflict.
    """

    accepted = [row for row in rows if row.status == "accepted" and (row.content_text or "").strip()]
    if not accepted:
        return []
    body_text = _normalized_story_text(
        "\n".join(html_to_paragraphs(body.content_html)) if body is not None else ""
    )
    if not body_text:
        return [row.segment_index for row in accepted]
    return [
        row.segment_index
        for row in accepted
        if _normalized_story_text(row.content_text) not in body_text
    ]


def _raise_ledger_body_mismatch(mismatched_indexes: list[int]) -> None:
    if not mismatched_indexes:
        return
    indexes = ", ".join(str(index + 1) for index in mismatched_indexes[:8])
    raise HTTPException(
        status_code=409,
        detail={
            "code": "LONG_LEDGER_BODY_MISMATCH",
            "message": f"正文与已采纳分段不一致（第 {indexes} 段），请先恢复对应正文版本或重新规划后再生成。",
            "segmentIndexes": mismatched_indexes,
        },
    )


def get_generation_gateway() -> GenerationGateway:
    return GenerationGateway()


def _sse(payload: object) -> str:
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


def _safe_generation_error(package: PromptPackage, error: Exception) -> str:
    message = str(error)
    if package.route.api_key:
        message = message.replace(package.route.api_key, "[redacted]")
    return message[:800]


async def _load_scope(
    chapter_id: str,
    user: User,
    db: AsyncSession,
    permission: ProjectPermission = ProjectPermission.VIEW,
) -> tuple[Chapter, Project]:
    result = await db.execute(
        select(Chapter, Project)
        .join(Project, Project.id == Chapter.project_id)
        .where(Chapter.id == chapter_id, Chapter.deleted_at.is_(None))
    )
    row = result.one_or_none()
    if row is None:
        raise HTTPException(status_code=404, detail="Chapter not found")
    chapter, project = row
    await verify_project_permission(project.id, permission, user, db)
    if permission in {ProjectPermission.GENERATE, ProjectPermission.EDIT_BODY}:
        await verify_chapter_assignment(chapter, user, db)
    return chapter, project


async def _prepare(
    request: ChapterGenerationRequest,
    user: User,
    db: AsyncSession,
) -> PromptPackage:
    chapter, project = await _load_scope(request.chapter_id, user, db, ProjectPermission.GENERATE)
    service = GenerationService(db)
    user_route = await active_user_generation_route(db, user_id=user.id)
    kwargs = request.model_dump(by_alias=False)
    kwargs.pop("chapter_id")
    provider_model = kwargs.pop("provider_model", None)
    if isinstance(request, InlineGenerationRequest):
        kwargs.update(
            action=request.action,
            selected_text=request.selected_text,
            nearby_text=request.nearby_text,
        )
    route = None
    if user_route is not None:
        if provider_model:
            raise HTTPException(
                status_code=422,
                detail={
                    "code": "CUSTOM_MODEL_ROUTE_LOCKED",
                    "message": "已启用自定义模型，请在模型配置中修改模型名称。",
                },
            )
        route = GenerationRoute(
            source="user",
            endpoint=user_route.endpoint,
            api_key=user_route.api_key,
            model_id=user_route.model,
            model_tier="custom",
            config_id=user_route.config_id,
            context_window_tokens=user_route.context_window_tokens,
            max_output_tokens=user_route.max_output_tokens,
            context_safety_margin_tokens=user_route.context_safety_margin_tokens,
        )
    if provider_model and provider_model not in {str(model["id"]) for model in CODING_PLAN_MODELS}:
        raise HTTPException(status_code=422, detail={"code": "MODEL_NOT_ALLOWED", "message": "模型不在已验证的模型目录中。"})
    return await service.prepare(chapter=chapter, project=project, route=route, provider_model=provider_model, **kwargs)


async def _prepare_preview(
    request: GenerationPreviewRequest,
    user: User,
    db: AsyncSession,
) -> PromptPackage:
    """Build the exact generation package without reserving credits or calling a model."""
    common = request.model_dump(by_alias=False, exclude_none=True)
    if request.action is not None:
        preview_request = InlineGenerationRequest(**common)
    else:
        common.pop("selected_text", None)
        common.pop("nearby_text", None)
        preview_request = ChapterGenerationRequest(**common)
    return await _prepare(preview_request, user, db)


def _enforce_generation_preflight(package: PromptPackage) -> None:
    """Reject requests that cannot fit the hard context budget."""
    preflight = package.preflight if isinstance(package.preflight, dict) else {}
    if preflight.get("blocking"):
        raise HTTPException(
            status_code=422,
            detail={
                "code": "GENERATION_PREFLIGHT_BLOCKED",
                "message": "当前上下文超过生成预算，请先压缩设定或更新索引。",
                "preflight": preflight,
            },
        )


def _preview_payload(package: PromptPackage) -> dict:
    layers = [
        package.context.layer1_resident,
        package.context.layer2_retrieved,
        package.context.layer3_summary,
        package.context.layer4_adjacent,
    ]
    return {
        "chapterId": package.chapter.id,
        "projectId": package.project.id,
        "chapterTitle": package.chapter.title,
        "task": package.task,
        "targetWords": package.target_words,
        "model": {"id": package.model_id, "tier": package.model_tier},
        "provider": {"source": package.route.source, "configId": package.route.config_id},
        "tokenBudget": {
            "total": package.context.target_tokens,
            "prompt": package.prompt_tokens,
            "context": package.context.total_tokens,
            "trimmedLayers": package.context.trimmed_layers,
            "mode": package.context.policy.mode,
            "modelWindow": package.context.policy.model_window_tokens,
            "reservedOutput": package.context.policy.reserved_output_tokens,
            "safetyMargin": package.context.policy.safety_margin_tokens,
            "usableContext": package.preflight.get("budget"),
        },
        "contextStats": {
            "mode": package.context.policy.mode,
            "budgetTokens": package.context.target_tokens,
            "usedTokens": package.context.total_tokens,
            "modelWindowTokens": package.context.policy.model_window_tokens,
            "reservedOutputTokens": package.context.policy.reserved_output_tokens,
            "safetyMarginTokens": package.context.policy.safety_margin_tokens,
        },
        "skills": [
            {
                "id": skill.id,
                "version": skill.version,
                "category": skill.category,
                "priority": skill.priority,
            }
            for skill in package.skills.skills
        ],
        "scene": package.skills.scene,
        "coverage": package.coverage,
        "preflight": package.preflight,
        "layers": [
            {
                "key": layer.key,
                "tokens": layer.tokens,
                "items": layer.items,
                "content": layer.content,
                "availableTokens": layer.available_tokens,
                "budgetTokens": layer.budget_tokens,
                "trimReason": layer.trim_reason,
            }
            for layer in layers
        ],
        "messages": package.messages,
    }


def _generation_response(
    package: PromptPackage,
    user: User,
    db: AsyncSession,
    gateway: GenerationGateway,
    reservation: UsageReservation | None,
    request_summary: dict,
    *,
    initial_content: str = "",
) -> StreamingResponse:
    draft_id = uuid.uuid4().hex

    async def event_stream() -> AsyncIterator[str]:
        usage: dict = {}
        chunks: list[str] = []
        finalized = False
        generated_length = 0
        checkpoint_length = 0
        source_body = await db.scalar(select(ChapterBody).where(ChapterBody.chapter_id == package.chapter.id))
        draft_summary = dict(request_summary)
        # ``0`` is the immutable empty-body revision. It lets continuation
        # detect a body created after the candidate started.
        draft_summary.setdefault("sourceBodyRev", source_body.rev if source_body is not None else 0)
        draft = GenerationDraft(
            id=draft_id,
            user_id=user.id,
            project_id=package.project.id,
            chapter_id=package.chapter.id,
            kind="chapter" if package.task == "chapter" else "inline",
            status="streaming",
            content_text=initial_content,
            generated_words=count_generated_words(initial_content),
            request_summary=draft_summary,
        )
        db.add(draft)
        try:
            await db.commit()
        except Exception:
            await db.rollback()
            if reservation is not None:
                await release_reservation(db, reservation, reason="draft_persistence_error")
            await db.commit()
            finalized = True
            yield _sse(
                {
                    "type": "error",
                    "code": "draft_persistence_error",
                    "message": "候选草稿无法保存，本次生成没有开始。请稍后重试。",
                }
            )
            return

        async def persist_failed_draft(session: AsyncSession, error_code: str) -> None:
            """Persist a recoverable draft using the supplied session.

            The request session is fine while the client is connected. A
            cancelled ASGI stream can invalidate that connection, though, so
            disconnect cleanup passes a fresh session here.
            """
            await session.rollback()
            failed_draft = await session.get(GenerationDraft, draft_id)
            if failed_draft is None:
                return
            generated_prose = "".join(chunks)
            prose = _merge_continuation_content(initial_content, generated_prose)
            if generated_prose and failed_draft.run_id is None:
                cached = usage.get("prompt_tokens_details") or {}
                run = GenerationRun(
                    id=uuid.uuid4().hex,
                    user_id=user.id,
                    project_id=package.project.id,
                    chapter_id=package.chapter.id,
                    task_type="chapter" if package.task == "chapter" else "inline",
                    model_tier=package.model_tier,
                    prompt_tokens=int(usage.get("prompt_tokens") or package.prompt_tokens),
                    cached_tokens=int(cached.get("cached_tokens") or 0),
                    completion_tokens=int(usage.get("completion_tokens") or tokenizer.count(generated_prose)),
                    generated_words=count_generated_words(generated_prose),
                    accepted_words=0,
                    layer_report={
                        **package.layer_report,
                        "provenance": {
                            "algorithm": PROVENANCE_ALGORITHM,
                            "paragraph_hashes": generated_paragraph_hashes(prose),
                        },
                        "incomplete": True,
                    },
                )
                session.add(run)
                await session.flush()
                failed_draft.run_id = run.id
            failed_draft.status = "failed"
            failed_draft.content_text = prose
            failed_draft.generated_words = count_generated_words(prose)
            failed_draft.error_code = error_code
        yield _sse(
            {
                "type": "meta",
                "draftId": draft_id,
                "skills": package.skills.ids,
                "scene": package.skills.scene,
                "layers": package.layer_report,
                "promptTokens": package.prompt_tokens,
                "model": package.model_id,
                "provider": package.route.source,
                "coverage": package.coverage,
                "preflight": package.preflight,
                "contextStats": package.layer_report.get("context", {}),
            }
        )
        try:
            async for event in retryable_stream(gateway, package):
                if event.type == "chunk":
                    chunks.append(event.text)
                    generated_length += len(event.text)
                    yield _sse({"type": "chunk", "text": event.text})
                    if generated_length - checkpoint_length >= 1000:
                        prose = _merge_continuation_content(initial_content, "".join(chunks))
                        draft.content_text = prose
                        draft.generated_words = count_generated_words(prose)
                        await db.commit()
                        checkpoint_length = generated_length
                elif event.usage:
                    usage = event.usage

            generated_prose = "".join(chunks)
            prose = _merge_continuation_content(initial_content, generated_prose)
            draft_quality = assess_draft_coverage(package.coverage, prose)
            completion_tokens = int(usage.get("completion_tokens") or tokenizer.count(generated_prose))
            prompt_tokens = int(usage.get("prompt_tokens") or package.prompt_tokens)
            cached = usage.get("prompt_tokens_details") or {}
            run = GenerationRun(
                id=uuid.uuid4().hex,
                user_id=user.id,
                project_id=package.project.id,
                chapter_id=package.chapter.id,
                task_type="chapter" if package.task == "chapter" else "inline",
                model_tier=package.model_tier,
                prompt_tokens=prompt_tokens,
                cached_tokens=int(cached.get("cached_tokens") or 0),
                completion_tokens=completion_tokens,
                generated_words=count_generated_words(generated_prose),
                accepted_words=0,
                layer_report={
                    **package.layer_report,
                    "draftQuality": draft_quality,
                    "provenance": {
                        "algorithm": PROVENANCE_ALGORITHM,
                        "paragraph_hashes": generated_paragraph_hashes(prose),
                    },
                },
            )
            db.add(run)
            await db.flush()
            draft.run_id = run.id
            draft.status = "ready"
            draft.content_text = prose
            draft.generated_words = count_generated_words(prose)
            if reservation is not None:
                charged = await settle_generation(
                    db,
                    reservation,
                    run_id=run.id,
                    prompt_tokens=prompt_tokens,
                    cached_tokens=run.cached_tokens,
                    completion_tokens=completion_tokens,
                )
            else:
                await record_user_key_generation(
                    db,
                    user_id=user.id,
                    project_id=package.project.id,
                    feature="generate_chapter" if package.task == "chapter" else "generate_inline",
                    model=package.model_id,
                    run_id=run.id,
                    config_id=package.route.config_id or "unknown",
                    prompt_tokens=prompt_tokens,
                    cached_tokens=run.cached_tokens,
                    completion_tokens=completion_tokens,
                )
                charged = 0
            await db.commit()
            finalized = True
            yield _sse(
                {
                    "type": "done",
                    "runId": run.id,
                    "draftId": draft.id,
                    "generatedWords": run.generated_words,
                    "usage": {
                        "promptTokens": prompt_tokens,
                        "completionTokens": completion_tokens,
                        "cachedTokens": run.cached_tokens,
                        "credits": charged,
                    },
                    "quality": {
                        "status": draft_quality.get("status") if draft_quality else "unknown",
                        "attention": draft_quality.get("summary", {}).get("attention", 0)
                        if draft_quality
                        else 0,
                    },
                }
            )
            yield "data: [DONE]\n\n"
        except GenerationProviderError as exc:
            error_code = "stream_interrupted" if exc.code == "STREAM_INTERRUPTED" else "generation_provider_error"
            await persist_failed_draft(db, error_code)
            if reservation is not None:
                await release_reservation(
                    db,
                    reservation,
                    reason="stream_interrupted" if exc.code == "STREAM_INTERRUPTED" else "provider_error",
                )
            await db.commit()
            finalized = True
            yield _sse(
                {
                    "type": "error",
                    "code": "STREAM_INTERRUPTED" if exc.code == "STREAM_INTERRUPTED" else "generation_provider_error",
                    "message": _safe_generation_error(package, exc),
                }
            )
        except Exception:
            await persist_failed_draft(db, "generation_internal_error")
            if reservation is not None:
                await release_reservation(db, reservation, reason="internal_error")
            await db.commit()
            finalized = True
            yield _sse(
                {
                    "type": "error",
                    "code": "generation_internal_error",
                    "message": "生成服务内部错误，请稍后重试。",
                }
            )
        finally:
            if not finalized:
                async def persist_cancelled_generation() -> None:
                    """Finish cancellation cleanup outside the request session."""
                    async with AsyncSessionLocal() as cleanup_db:
                        try:
                            await persist_failed_draft(cleanup_db, "stream_interrupted")
                            if reservation is not None:
                                await release_reservation(
                                    cleanup_db, reservation, reason="stream_interrupted"
                                )
                            await cleanup_db.commit()
                        except BaseException:
                            await cleanup_db.rollback()
                            raise

                cleanup_task = asyncio.create_task(persist_cancelled_generation())
                try:
                    await asyncio.shield(cleanup_task)
                except asyncio.CancelledError:
                    # The first cancellation interrupts the response task;
                    # shield the already-running DB task and wait once more so
                    # the candidate and reservation cannot be left half-open.
                    try:
                        await asyncio.shield(cleanup_task)
                    except asyncio.CancelledError:
                        cleanup_task.cancel()
                        await asyncio.gather(cleanup_task, return_exceptions=True)
                        raise

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/models")
async def list_generation_models(user: User = Depends(get_current_user)):
    """Return the curated Volcengine Coding Plan model matrix for model pickers."""
    return {"baseUrl": "https://ark.cn-beijing.volces.com/api/coding/v3", "models": list(CODING_PLAN_MODELS)}


@router.post("/long-plan")
async def create_long_chapter_plan(
    request: LongChapterPlanRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a resumable segment ledger for up to one million Chinese words.

    Planning is idempotent for a chapter. Existing accepted segments are kept;
    changing the target only rebalances pending rows and marks surplus rows as
    skipped, so an author can safely revise a long outline midway through a
    book.
    """
    chapter, project = await _load_scope(
        request.chapter_id, user, db, ProjectPermission.GENERATE
    )
    await db.execute(select(Chapter.id).where(Chapter.id == chapter.id).with_for_update())
    plans = make_segment_plan(
        request.target_words,
        scene_purposes=request.scene_purposes or chapter.outline or [],
        required_beats=request.required_beats,
        segment_words=request.segment_words,
    )
    result = await db.execute(
        select(GenerationSegment)
        .where(GenerationSegment.chapter_id == chapter.id)
        .order_by(GenerationSegment.segment_index)
    )
    existing = list(result.scalars().all())
    body = await db.scalar(select(ChapterBody).where(ChapterBody.chapter_id == chapter.id))
    _raise_ledger_body_mismatch(_accepted_ledger_mismatch(body, existing))
    editable_result = await db.execute(
        select(GenerationSegment)
        .where(
            GenerationSegment.chapter_id == chapter.id,
            GenerationSegment.status.notin_(("accepted", "running")),
        )
        .with_for_update(skip_locked=True)
        .execution_options(populate_existing=True)
    )
    editable_by_index = {row.segment_index: row for row in editable_result.scalars().all()}
    source_revisions = {"chapterBodyRev": body.rev if body else 0, "chapterUpdatedAt": chapter.updated_at.isoformat() if chapter.updated_at else None}
    by_index = {row.segment_index: row for row in existing}
    for plan in plans:
        row = by_index.get(plan.index)
        manifest = build_context_manifest(
            chapter_id=chapter.id,
            segment=plan,
            source_revisions=source_revisions,
            context_layers={},
        )
        if row is None:
            row = GenerationSegment(
                id=uuid.uuid4().hex,
                project_id=project.id,
                chapter_id=chapter.id,
                segment_index=plan.index,
                target_words=plan.target_words,
                context_manifest=manifest,
                status="pending",
            )
            db.add(row)
        elif row.segment_index in editable_by_index:
            row = editable_by_index[row.segment_index]
            plan_changed = row.target_words != plan.target_words or row.context_manifest != manifest
            if plan_changed:
                row.target_words = plan.target_words
                row.context_manifest = manifest
                row.content_text = ""
                row.generated_words = 0
                row.prompt_hash = None
                row.revision += 1
                row.completed_at = None
                row.lease_owner = None
                row.lease_expires_at = None
                row.heartbeat_at = None
                row.status = "pending"
                row.error_code = None
            elif row.status == "skipped":
                row.status = "pending"
                row.error_code = None
    planned_indexes = {plan.index for plan in plans}
    for row in editable_by_index.values():
        if row.segment_index not in planned_indexes:
            row.status = "skipped"
    await db.commit()
    rows = await db.execute(
        select(GenerationSegment).where(GenerationSegment.chapter_id == chapter.id).order_by(GenerationSegment.segment_index)
    )
    segments = list(rows.scalars().all())
    return {
        "chapterId": chapter.id,
        "projectId": project.id,
        "targetWords": request.target_words,
        "segmentWords": request.segment_words,
        "totalSegments": len(plans),
        "nextSegment": next((row.segment_index for row in segments if row.status == "pending"), None),
        "segments": [
            {
                "id": row.id,
                "index": row.segment_index,
                "targetWords": row.target_words,
                "status": row.status,
                "generatedWords": row.generated_words,
                "revision": row.revision,
                "leaseOwner": row.lease_owner,
                "leaseExpiresAt": row.lease_expires_at.isoformat() if row.lease_expires_at else None,
                "heartbeatAt": row.heartbeat_at.isoformat() if row.heartbeat_at else None,
                "manifest": row.context_manifest,
            }
            for row in segments
        ],
    }


@router.get("/long-plan/{chapter_id}")
async def get_long_chapter_plan(
    chapter_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    chapter, project = await _load_scope(chapter_id, user, db)
    result = await db.execute(
        select(GenerationSegment).where(GenerationSegment.chapter_id == chapter.id).order_by(GenerationSegment.segment_index)
    )
    segments = list(result.scalars().all())
    accepted = sum(row.status == "accepted" for row in segments)
    target_words = sum(row.target_words for row in segments if row.status != "skipped")
    # The final segment may be shorter to hit the exact total.  The first
    # segment is the author's configured size and is the useful value for the
    # editable plan controls.
    segment_words = segments[0].target_words if segments else None
    return {
        "chapterId": chapter.id,
        "projectId": project.id,
        "targetWords": target_words,
        "segmentWords": segment_words,
        "totalSegments": len(segments),
        "acceptedSegments": accepted,
        "nextSegment": next((row.segment_index for row in segments if row.status == "pending"), None),
        "segments": [
            {
                "id": row.id,
                "index": row.segment_index,
                "targetWords": row.target_words,
                "status": row.status,
                "revision": row.revision,
                "generatedWords": row.generated_words,
                "leaseOwner": row.lease_owner,
                "leaseExpiresAt": row.lease_expires_at.isoformat() if row.lease_expires_at else None,
                "heartbeatAt": row.heartbeat_at.isoformat() if row.heartbeat_at else None,
                "errorCode": row.error_code,
            }
            for row in segments
        ],
    }


@router.post("/long-segments/{segment_id}/generate")
async def queue_long_generation_segment(
    segment_id: str,
    request: LongSegmentGenerateRequest | None = None,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Claim and queue one long-form segment for the existing Celery worker."""
    segment = await _load_segment_scope(segment_id, user, db, ProjectPermission.GENERATE)
    if segment.segment_index > 0:
        earlier_result = await db.execute(
            select(GenerationSegment)
            .where(
                GenerationSegment.chapter_id == segment.chapter_id,
                GenerationSegment.segment_index < segment.segment_index,
            )
            .order_by(GenerationSegment.segment_index)
        )
        earlier_rows = list(earlier_result.scalars().all())
        body = await db.scalar(select(ChapterBody).where(ChapterBody.chapter_id == segment.chapter_id))
        _raise_ledger_body_mismatch(_accepted_ledger_mismatch(body, earlier_rows))
    if segment.status in {"ready", "accepted"}:
        return _segment_payload(segment)
    if segment.status not in {"pending", "failed", "running"}:
        raise HTTPException(
            status_code=409,
            detail={"code": "SEGMENT_STATE_INVALID", "message": f"该段当前状态为 {segment.status}"},
        )
    payload = request or LongSegmentGenerateRequest()
    if payload.provider_model and payload.provider_model not in {str(item["id"]) for item in CODING_PLAN_MODELS}:
        raise HTTPException(status_code=422, detail={"code": "MODEL_NOT_ALLOWED", "message": "模型不在已验证的模型目录中。"})
    owner = f"long:{user.id}:{uuid.uuid4().hex[:16]}"
    try:
        claim = await claim_segment(
            db,
            segment_id,
            lease_seconds=LONG_SEGMENT_LEASE_SECONDS,
            lease_owner=owner,
        )
        manifest = dict(segment.context_manifest or {})
        manifest["generationRequest"] = {
            "model": payload.model,
            "providerModel": payload.provider_model,
            "useStyleProfile": payload.use_style_profile,
            "dialogueDensity": payload.dialogue_density,
            "contextMode": payload.context_mode,
            "instruction": payload.instruction,
        }
        segment.context_manifest = manifest
        await db.commit()
    except Exception as exc:
        await db.rollback()
        raise _segment_error(exc) from exc

    try:
        task = await asyncio.to_thread(
            celery_app.send_task,
            "generation.generate_long_segment",
            args=[segment_id, user.id, claim.lease_revision, owner],
            retry=False,
        )
    except Exception as exc:
        try:
            await fail_segment(
                db,
                segment_id,
                lease_revision=claim.lease_revision,
                lease_owner=owner,
                error_code="worker_dispatch_failed",
            )
            await db.commit()
        except Exception:
            await db.rollback()
        raise HTTPException(status_code=503, detail={"code": "WORKER_UNAVAILABLE", "message": "长篇生成任务暂时无法排队"}) from exc

    row = await db.get(GenerationSegment, segment_id)
    payload_out = _segment_payload(row or segment)
    payload_out["taskId"] = task.id
    return payload_out


async def _load_segment_scope(
    segment_id: str,
    user: User,
    db: AsyncSession,
    permission: ProjectPermission = ProjectPermission.GENERATE,
) -> GenerationSegment:
    """Load a segment and authorize through its owning project."""
    segment = await db.get(GenerationSegment, segment_id)
    if segment is None:
        raise HTTPException(status_code=404, detail="Generation segment not found")
    chapter = await db.get(Chapter, segment.chapter_id)
    if chapter is None or chapter.deleted_at is not None or chapter.project_id != segment.project_id:
        raise HTTPException(status_code=404, detail="Generation segment chapter not found")
    await verify_project_permission(segment.project_id, permission, user, db)
    if permission in {ProjectPermission.GENERATE, ProjectPermission.EDIT_BODY}:
        await verify_chapter_assignment(chapter, user, db)
    return segment


def _segment_error(exc: Exception) -> HTTPException:
    if isinstance(exc, HTTPException):
        return exc
    if isinstance(exc, SegmentBusyError):
        return HTTPException(status_code=409, detail={"code": "SEGMENT_BUSY", "message": str(exc)})
    if isinstance(exc, SegmentLeaseLostError):
        return HTTPException(status_code=409, detail={"code": "SEGMENT_LEASE_LOST", "message": str(exc)})
    if isinstance(exc, SegmentCheckpointConflictError):
        return HTTPException(status_code=409, detail={"code": "SEGMENT_CHECKPOINT_CONFLICT", "message": str(exc)})
    if isinstance(exc, SegmentMergeBlockedError):
        return HTTPException(status_code=409, detail={"code": "SEGMENT_MERGE_BLOCKED", "message": str(exc)})
    if isinstance(exc, SegmentExecutionError):
        return HTTPException(status_code=409, detail={"code": "SEGMENT_STATE_INVALID", "message": str(exc)})
    if isinstance(exc, ValueError):
        return HTTPException(status_code=422, detail={"code": "SEGMENT_INPUT_INVALID", "message": str(exc)})
    return HTTPException(status_code=500, detail={"code": "SEGMENT_OPERATION_FAILED"})


def _contiguous_mergeable_prefix(rows: list[GenerationSegment]) -> list[GenerationSegment]:
    """Return the completed prefix that can be safely materialized now.

    Plans contain all segments from the outset. A pending, running, or failed
    segment after a ready prefix must not prevent the author from reviewing
    that prefix, while a gap or an invalid first segment remains rejected by
    ``merge_segment_outputs``.
    """
    mergeable = {"ready", "accepted", "skipped"}
    prefix: list[GenerationSegment] = []
    expected_index = 0
    for row in rows:
        if row.segment_index != expected_index or row.status not in mergeable:
            break
        prefix.append(row)
        expected_index += 1
    return prefix


def _segment_payload(row: GenerationSegment, *, include_content: bool = False) -> dict:
    payload = {
        "id": row.id,
        "projectId": row.project_id,
        "chapterId": row.chapter_id,
        "index": row.segment_index,
        "targetWords": row.target_words,
        "status": row.status,
        "revision": row.revision,
        "leaseOwner": row.lease_owner,
        "leaseExpiresAt": row.lease_expires_at.isoformat() if row.lease_expires_at else None,
        "heartbeatAt": row.heartbeat_at.isoformat() if row.heartbeat_at else None,
        "generatedWords": row.generated_words,
        "contentHash": checkpoint_hash(row.content_text),
        "errorCode": row.error_code,
        "completedAt": row.completed_at.isoformat() if row.completed_at else None,
        "manifest": row.context_manifest or {},
    }
    if include_content:
        payload["contentText"] = row.content_text or ""
    return payload


@router.post("/long-segments/{segment_id}/claim")
async def claim_long_generation_segment(
    segment_id: str,
    request: LongSegmentClaimRequest | None = None,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Claim one segment; the returned revision fences every later mutation."""
    await _load_segment_scope(segment_id, user, db)
    try:
        claim = await claim_segment(
            db,
            segment_id,
            lease_seconds=request.lease_seconds if request else 300,
            lease_owner=request.lease_owner if request else None,
        )
        await db.commit()
    except Exception as exc:
        await db.rollback()
        raise _segment_error(exc) from exc
    return {
        "segmentId": claim.segment_id,
        "chapterId": claim.chapter_id,
        "index": claim.segment_index,
        "leaseRevision": claim.lease_revision,
        "checkpointHash": claim.checkpoint_hash,
        "contentText": claim.content_text,
        "targetWords": claim.target_words,
        "manifest": claim.context_manifest,
        "resumed": claim.resumed,
        "leaseOwner": claim.lease_owner,
        "leaseExpiresAt": claim.lease_expires_at.isoformat(),
        "heartbeatAt": claim.heartbeat_at.isoformat(),
    }


@router.post("/long-segments/{segment_id}/checkpoint")
async def checkpoint_long_generation_segment(
    segment_id: str,
    request: LongSegmentCheckpointRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _load_segment_scope(segment_id, user, db)
    try:
        result = await checkpoint_segment(
            db,
            segment_id,
            lease_revision=request.lease_revision,
            expected_checkpoint_hash=request.expected_checkpoint_hash,
            content_text=request.content_text,
            lease_owner=request.lease_owner,
            lease_seconds=request.lease_seconds,
        )
        await db.commit()
    except Exception as exc:
        await db.rollback()
        raise _segment_error(exc) from exc
    return {
        "segmentId": result.segment_id,
        "leaseRevision": result.lease_revision,
        "checkpointHash": result.checkpoint_hash,
        "generatedWords": result.generated_words,
    }


@router.post("/long-segments/{segment_id}/fail")
async def fail_long_generation_segment(
    segment_id: str,
    request: LongSegmentFailRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _load_segment_scope(segment_id, user, db)
    try:
        await fail_segment(
            db,
            segment_id,
            lease_revision=request.lease_revision,
            error_code=request.error_code,
            lease_owner=request.lease_owner,
        )
        await db.commit()
    except Exception as exc:
        await db.rollback()
        raise _segment_error(exc) from exc
    row = await db.get(GenerationSegment, segment_id)
    return _segment_payload(row) if row else {"segmentId": segment_id, "status": "failed"}


@router.post("/long-segments/{segment_id}/validate")
async def validate_long_generation_segment(
    segment_id: str,
    request: LongSegmentValidateRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _load_segment_scope(segment_id, user, db)
    if request.max_ratio < request.min_ratio:
        raise HTTPException(status_code=422, detail={"code": "SEGMENT_RATIO_INVALID"})
    try:
        check = await validate_claimed_segment(
            db,
            segment_id,
            lease_revision=request.lease_revision,
            required_terms=request.required_terms,
            min_ratio=request.min_ratio,
            max_ratio=request.max_ratio,
            lease_owner=request.lease_owner,
        )
        await db.commit()
    except Exception as exc:
        await db.rollback()
        raise _segment_error(exc) from exc
    row = await db.get(GenerationSegment, segment_id)
    return {
        "segment": _segment_payload(row) if row else {"id": segment_id},
        "status": check.status,
        "blocking": check.blocking,
        "checks": [dict(item) for item in check.checks],
    }


@router.post("/long-segments/{segment_id}/heartbeat")
async def heartbeat_long_generation_segment(
    segment_id: str,
    request: LongSegmentHeartbeatRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _load_segment_scope(segment_id, user, db)
    try:
        heartbeat = await heartbeat_segment(
            db,
            segment_id,
            lease_revision=request.lease_revision,
            lease_owner=request.lease_owner,
            lease_seconds=request.lease_seconds,
        )
        await db.commit()
    except Exception as exc:
        await db.rollback()
        raise _segment_error(exc) from exc
    return {
        "segmentId": heartbeat.segment_id,
        "leaseRevision": heartbeat.lease_revision,
        "leaseOwner": heartbeat.lease_owner,
        "leaseExpiresAt": heartbeat.lease_expires_at.isoformat(),
        "heartbeatAt": heartbeat.heartbeat_at.isoformat(),
    }


@router.post("/long-plan/{chapter_id}/merge")
async def merge_long_generation_segments(
    chapter_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Build or reuse an author-facing candidate draft from completed segments."""
    chapter, project = await _load_scope(chapter_id, user, db, ProjectPermission.GENERATE)
    try:
        await db.execute(select(Chapter.id).where(Chapter.id == chapter.id).with_for_update())
        drafts = (
            await db.execute(
                select(GenerationDraft)
                .where(
                    GenerationDraft.chapter_id == chapter.id,
                    GenerationDraft.kind == "chapter",
                )
                .order_by(GenerationDraft.created_at.desc())
                .with_for_update()
            )
        ).scalars().all()
        result = await db.execute(
            select(GenerationSegment)
            .where(GenerationSegment.chapter_id == chapter.id)
            .order_by(GenerationSegment.segment_index)
            .with_for_update()
        )
        rows = list(result.scalars().all())
        # A long-generation plan is created up front, so later segments are
        # commonly still pending while an earlier prefix is ready. Merge only
        # the contiguous completed prefix so it can be reviewed immediately.
        merge_rows = _contiguous_mergeable_prefix(rows)
        merged = merge_new_segment_outputs(merge_rows)
        segment_meta = [
            {
                "id": row.id,
                "index": row.segment_index,
                "revision": row.revision,
                "contentHash": checkpoint_hash(row.content_text),
            }
            for row in rows
            if row.id in merged.segment_ids
        ]
        merge_key = hashlib.sha256(
            json.dumps(
                {"chapterId": chapter.id, "segments": segment_meta, "contentHash": merged.content_hash},
                ensure_ascii=False,
                sort_keys=True,
            ).encode("utf-8")
        ).hexdigest()
        existing_draft = None
        for candidate in drafts:
            summary = candidate.request_summary if isinstance(candidate.request_summary, dict) else {}
            metadata = summary.get("longGenerationMerge")
            if isinstance(metadata, dict) and metadata.get("mergeKey") == merge_key:
                if candidate.status == "rejected":
                    raise HTTPException(
                        status_code=409,
                        detail={
                            "code": "LONG_MERGE_REJECTED",
                            "message": "相同内容已被拒绝，请先修改或重新生成分段。",
                        },
                    )
                if candidate.status not in {"ready", "accepted"}:
                    raise HTTPException(
                        status_code=409,
                        detail={"code": "LONG_MERGE_NOT_REUSABLE"},
                    )
                existing_draft = candidate
                break
        if existing_draft is None:
            summary = {
                "source": "long_generation_segments",
                "longGenerationMerge": {
                    "version": 1,
                    "mergeKey": merge_key,
                    "segmentIds": list(merged.segment_ids),
                    "segments": segment_meta,
                    "contentHash": merged.content_hash,
                },
            }
            # The deterministic id closes the concurrent-merge race even
            # though the legacy draft table has no dedicated merge-key column.
            draft_id = f"lg_{merge_key[:29]}"
            existing_draft = GenerationDraft(
                id=draft_id,
                run_id=None,
                user_id=user.id,
                project_id=project.id,
                chapter_id=chapter.id,
                kind="chapter",
                status="ready",
                content_text=merged.content_text,
                generated_words=merged.generated_words,
                request_summary=summary,
            )
            db.add(existing_draft)
            await db.flush()
        await db.commit()
        await db.refresh(existing_draft)
    except Exception as exc:
        await db.rollback()
        raise _segment_error(exc) from exc
    return _draft_payload(existing_draft, include_content=True)


@router.get("/context/{chapter_id}")
async def preview_context(
    chapter_id: str,
    context_mode: Literal["smart", "fast", "standard", "deep"] = Query(
        "smart", alias="contextMode"
    ),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    chapter, project = await _load_scope(chapter_id, user, db)
    user_route = await active_user_generation_route(db, user_id=user.id)
    policy = ContextBudgetPolicy.create(
        mode=context_mode,
        model_window_tokens=(
            user_route.context_window_tokens
            if user_route is not None
            else settings.generation_context_window_tokens
        ),
        reserved_output_tokens=(
            user_route.max_output_tokens
            if user_route is not None
            else settings.generation_max_output_tokens
        ),
        safety_margin_tokens=(
            user_route.context_safety_margin_tokens
            if user_route is not None
            else settings.generation_context_safety_margin_tokens
        ),
    )
    context = await GenerationService(db).assembler.build(
        project.id,
        chapter.id,
        chapter.outline or [],
        policy=policy,
    )
    selection = select_writing_skills(genre=project.genre, task="chapter", outline=chapter.outline or [])
    labels = {
        "resident": "设定与本章规划 · 常驻",
        "retrieved": "本章相关设定",
        "summary": "前情摘要",
        "adjacent": "相邻原文",
    }
    layers = [
        context.layer1_resident,
        context.layer2_retrieved,
        context.layer3_summary,
        context.layer4_adjacent,
    ]
    return {
        "layers": [
            {
                "key": layer.key,
                "label": labels[layer.key],
                "detail": f"{len(layer.items)} 项",
                "tokens": layer.tokens,
                "availableTokens": layer.available_tokens,
                "budgetTokens": layer.budget_tokens,
                "trimReason": layer.trim_reason,
                "items": layer.items,
            }
            for layer in layers
        ],
        "totalTokens": context.total_tokens,
        "budgetExceeded": context.budget_exceeded,
        "trimmedLayers": context.trimmed_layers,
        "contextMode": context.policy.mode,
        "contextBudget": context.target_tokens,
        "skills": selection.ids,
        "scene": selection.scene,
    }


@router.post("/preview")
async def preview_generation_prompt(
    request: GenerationPreviewRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Return the exact prompt package without model calls, reservations, or usage writes."""
    package = await _prepare_preview(request, user, db)
    return _preview_payload(package)


@router.post("/chapter")
async def generate_chapter(
    request: ChapterGenerationRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    gateway: GenerationGateway = Depends(get_generation_gateway),
):
    package = await _prepare(request, user, db)
    _enforce_generation_preflight(package)
    reservation = await _reserve(package, request, user, db)
    return _generation_response(package, user, db, gateway, reservation, _request_summary(request))


@router.post("/inline")
async def generate_inline(
    request: InlineGenerationRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    gateway: GenerationGateway = Depends(get_generation_gateway),
):
    package = await _prepare(request, user, db)
    _enforce_generation_preflight(package)
    reservation = await _reserve(package, request, user, db)
    return _generation_response(package, user, db, gateway, reservation, _request_summary(request))


def _request_summary(request: ChapterGenerationRequest) -> dict:
    summary = {
        "model": request.model,
        "modelId": request.provider_model,
        "targetWords": request.target_words,
        "useStyleProfile": request.use_style_profile,
        "dialogueDensity": request.dialogue_density,
        "contextMode": request.context_mode,
    }
    if request.instruction.strip():
        summary["instruction"] = request.instruction.strip()
    if isinstance(request, InlineGenerationRequest):
        summary["action"] = request.action
    return summary


def _draft_segments(draft: GenerationDraft) -> tuple[list[dict], int, bool]:
    paragraphs = [
        paragraph.strip()
        for paragraph in (draft.content_text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")
        if paragraph.strip()
    ]
    summary = draft.request_summary if isinstance(draft.request_summary, dict) else {}
    raw_review = summary.get("review")
    has_review = isinstance(raw_review, dict)
    review = raw_review if has_review else {}
    raw_decisions = review.get("decisions")
    decisions = raw_decisions if isinstance(raw_decisions, dict) else {}
    version = review.get("version", 0)
    if not isinstance(version, int) or version < 0:
        version = 0
    segments = []
    for index, text in enumerate(paragraphs, start=1):
        segment_id = f"p{index}"
        decision = decisions.get(segment_id, "pending")
        if decision not in {"pending", "accepted", "rejected"}:
            decision = "pending"
        segments.append({"id": segment_id, "text": text, "decision": decision})
    return segments, version, has_review


def _review_counts(segments: list[dict]) -> dict:
    return {
        "total": len(segments),
        "pending": sum(segment["decision"] == "pending" for segment in segments),
        "accepted": sum(segment["decision"] == "accepted" for segment in segments),
        "rejected": sum(segment["decision"] == "rejected" for segment in segments),
    }


def _accepted_draft_content(draft: GenerationDraft) -> tuple[str, bool]:
    segments, _, has_review = _draft_segments(draft)
    if not has_review:
        return draft.content_text or "", False
    return "\n".join(segment["text"] for segment in segments if segment["decision"] == "accepted"), True


def _draft_payload(
    draft: GenerationDraft,
    *,
    include_content: bool = False,
    coverage: dict | None = None,
) -> dict:
    content = draft.content_text or ""
    segments, review_version, _ = _draft_segments(draft)
    public_summary = dict(draft.request_summary or {})
    public_summary.pop("review", None)
    payload = {
        "id": draft.id,
        "runId": draft.run_id,
        "projectId": draft.project_id,
        "chapterId": draft.chapter_id,
        "kind": draft.kind,
        "status": draft.status,
        "generatedWords": draft.generated_words,
        "excerpt": content[:160] + ("…" if len(content) > 160 else ""),
        "requestSummary": public_summary,
        "errorCode": draft.error_code,
        "createdAt": draft.created_at.isoformat() if draft.created_at else None,
        "updatedAt": draft.updated_at.isoformat() if draft.updated_at else None,
        "acceptedAt": draft.accepted_at.isoformat() if draft.accepted_at else None,
        "reviewVersion": review_version,
        "review": _review_counts(segments),
    }
    if include_content:
        accepted_content, has_review = _accepted_draft_content(draft)
        payload["content"] = accepted_content if draft.status == "accepted" and has_review else content
        payload["segments"] = segments
        payload["coverage"] = coverage
    return payload


async def _draft_coverage(db: AsyncSession, draft: GenerationDraft) -> dict | None:
    if not draft.run_id:
        return None
    run = await db.get(GenerationRun, draft.run_id)
    if run is None or not isinstance(run.layer_report, dict):
        return None
    raw = run.layer_report.get("coverage")
    segments, _, has_review = _draft_segments(draft)
    review_content = draft.content_text or ""
    if has_review:
        # Rejected paragraphs must no longer count as evidence. Pending text
        # remains in scope until the author decides, and a fully reviewed draft
        # therefore assesses exactly what can be inserted.
        review_content = "\n".join(
            segment["text"] for segment in segments if segment["decision"] != "rejected"
        )
    return assess_draft_coverage(raw if isinstance(raw, dict) else None, review_content)


def _quality_review_checks(coverage: dict | None) -> list[dict]:
    """Return unresolved prose-quality warnings that need an author decision.

    Coverage is intentionally conservative and lexical.  It must not silently
    reject a draft forever, but a chapter with an unresolved dramatic warning
    should not be promoted to canon without an explicit paragraph review.
    """
    if not isinstance(coverage, dict):
        return []
    return [
        check
        for check in coverage.get("checks", [])
        if isinstance(check, dict)
        and check.get("checkType") == "quality"
        and check.get("severity") == "warning"
        and check.get("status") in {"attention", "author_review"}
    ]


async def _load_draft(draft_id: str, user: User, db: AsyncSession, *, lock: bool = False) -> GenerationDraft:
    statement = select(GenerationDraft).where(GenerationDraft.id == draft_id)
    if lock:
        statement = statement.with_for_update()
    draft = (await db.execute(statement)).scalar_one_or_none()
    if draft is None:
        raise HTTPException(status_code=404, detail="Draft not found")
    await verify_project_permission(draft.project_id, ProjectPermission.EDIT_BODY, user, db)
    chapter = await db.get(Chapter, draft.chapter_id)
    if chapter is None or chapter.deleted_at is not None:
        raise HTTPException(status_code=404, detail="Chapter not found")
    await verify_chapter_assignment(chapter, user, db)
    return draft


def _continuation_tail(content: str, *, max_chars: int = 12000) -> str:
    """Keep complete paragraphs only so a resumed request has a stable seam."""
    paragraphs = [
        item.strip()
        for item in content.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        if item.strip()
    ]
    selected: list[str] = []
    size = 0
    for paragraph in reversed(paragraphs):
        if selected and size + len(paragraph) + 1 > max_chars:
            break
        selected.append(paragraph)
        size += len(paragraph) + 1
    return "\n".join(reversed(selected))


def _merge_continuation_content(prefix: str, generated: str) -> str:
    """Join persisted output while removing a replayed continuation seam."""
    if not prefix:
        return generated
    if not generated:
        return prefix
    left = prefix.rstrip()
    right = generated.lstrip()
    upper = min(1000, len(left), len(right))
    overlap = next(
        (size for size in range(upper, 1, -1) if left.endswith(right[:size])),
        0,
    )
    if overlap:
        return left + right[overlap:]
    return f"{left}\n{right}"


@router.post("/drafts/{draft_id}/continue")
async def continue_draft(
    draft_id: str,
    request: DraftContinueRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    gateway: GenerationGateway = Depends(get_generation_gateway),
):
    """Resume a failed draft without replacing the canonical chapter body."""
    draft = await _load_draft(draft_id, user, db)
    if draft.status != "failed" or not (draft.content_text or "").strip():
        raise HTTPException(
            status_code=409,
            detail={"code": "DRAFT_NOT_CONTINUABLE", "message": "只有包含已保存内容的中断候选可以继续生成。"},
        )
    body = await db.scalar(select(ChapterBody).where(ChapterBody.chapter_id == draft.chapter_id))
    metadata = draft.request_summary if isinstance(draft.request_summary, dict) else {}
    source_body_rev = metadata.get("sourceBodyRev")
    source_changed = (
        isinstance(source_body_rev, int)
        and (
            (source_body_rev == 0 and body is not None)
            or (source_body_rev > 0 and (body is None or body.rev != source_body_rev))
        )
    )
    if source_changed:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "DRAFT_SOURCE_STALE",
                "message": "正文在候选中断后已经发生变化，请重新生成或先处理当前正文版本。",
                "sourceBodyRev": source_body_rev,
                "currentBodyRev": body.rev if body is not None else 0,
            },
        )
    tail = _continuation_tail(draft.content_text)
    if not tail:
        raise HTTPException(status_code=409, detail={"code": "DRAFT_NOT_CONTINUABLE"})
    source_hash = hashlib.sha256(draft.content_text.encode("utf-8")).hexdigest()
    continuation_instruction = (
        "这是一次从中断候选继续的请求。以下内容是候选末尾已经生成的完整段落。"
        "只从最后一句之后继续，绝不要复述、改写或重新输出这些段落；保持人物、时间、事实和语气连续。"
    )
    if request.instruction.strip():
        continuation_instruction += f"\n作者补充要求：{request.instruction.strip()}"
    inline = InlineGenerationRequest(
        chapterId=draft.chapter_id,
        targetWords=request.target_words,
        model=request.model,
        useStyleProfile=request.use_style_profile,
        dialogueDensity=request.dialogue_density,
        contextMode=request.context_mode,
        action="续写",
        selectedText="",
        nearbyText=tail,
        instruction=continuation_instruction,
    )
    package = await _prepare(inline, user, db)
    _enforce_generation_preflight(package)
    reservation = await _reserve(package, inline, user, db)
    summary = _request_summary(inline)
    summary.update(
        {
            "continuationOfDraftId": draft.id,
            "continuationSourceHash": source_hash,
            "continuationTailChars": len(tail),
            "sourceBodyRev": body.rev if body is not None else 0,
        }
    )
    return _generation_response(
        package,
        user,
        db,
        gateway,
        reservation,
        summary,
        initial_content=draft.content_text,
    )


@router.get("/drafts")
async def list_drafts(
    chapter_id: str = Query(alias="chapterId", min_length=1, max_length=32),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    chapter, _ = await _load_scope(chapter_id, user, db, ProjectPermission.EDIT_BODY)
    drafts = (
        await db.execute(
            select(GenerationDraft)
            .where(
                GenerationDraft.chapter_id == chapter.id,
                GenerationDraft.status.in_(["streaming", "ready", "failed"]),
            )
            .order_by(GenerationDraft.created_at.desc())
            .limit(50)
        )
    ).scalars().all()
    return {"items": [_draft_payload(draft) for draft in drafts]}


@router.get("/drafts/{draft_id}")
async def get_draft(
    draft_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    draft = await _load_draft(draft_id, user, db)
    return _draft_payload(
        draft,
        include_content=True,
        coverage=await _draft_coverage(db, draft),
    )


@router.patch("/drafts/{draft_id}/review")
async def update_draft_review(
    draft_id: str,
    request: DraftReviewUpdateRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    draft = await _load_draft(draft_id, user, db, lock=True)
    if draft.status not in {"ready", "failed"} or not draft.content_text:
        raise HTTPException(
            status_code=409,
            detail={"code": "DRAFT_NOT_REVIEWABLE", "message": "候选仍在生成或已经处理，无法继续审阅。"},
        )
    segments, version, _ = _draft_segments(draft)
    if request.base_version != version:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "DRAFT_REVIEW_CONFLICT",
                "message": "候选已在另一窗口更新，已重新加载最新决定。",
                "currentVersion": version,
            },
        )
    valid_ids = {segment["id"] for segment in segments}
    requested_ids = set(request.segment_ids)
    if len(requested_ids) != len(request.segment_ids) or not requested_ids.issubset(valid_ids):
        raise HTTPException(
            status_code=422,
            detail={"code": "INVALID_DRAFT_SEGMENTS", "message": "候选段落已经变化，请刷新后重试。"},
        )

    summary = dict(draft.request_summary or {})
    raw_review = summary.get("review")
    review = dict(raw_review) if isinstance(raw_review, dict) else {}
    raw_decisions = review.get("decisions")
    decisions = dict(raw_decisions) if isinstance(raw_decisions, dict) else {}
    for segment_id in requested_ids:
        if request.decision == "pending":
            decisions.pop(segment_id, None)
        else:
            decisions[segment_id] = request.decision
    summary["review"] = {"version": version + 1, "decisions": decisions}
    draft.request_summary = summary
    await db.commit()
    await db.refresh(draft)
    return _draft_payload(
        draft,
        include_content=True,
        coverage=await _draft_coverage(db, draft),
    )


@router.post("/drafts/{draft_id}/accept")
async def accept_draft(
    draft_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    draft = await _load_draft(draft_id, user, db, lock=True)
    if draft.status == "accepted":
        return _draft_payload(
            draft,
            include_content=True,
            coverage=await _draft_coverage(db, draft),
        )
    if draft.status not in {"ready", "failed"} or not draft.content_text:
        raise HTTPException(status_code=409, detail={"code": "DRAFT_NOT_ACCEPTABLE"})
    segments, _, has_review = _draft_segments(draft)
    quality_coverage = await _draft_coverage(db, draft)
    quality_checks = _quality_review_checks(quality_coverage)
    if draft.kind == "chapter" and quality_checks and not has_review:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "DRAFT_QUALITY_REVIEW_REQUIRED",
                "message": "候选存在转折、钩子或叙事张力风险，请先逐段审阅后再放入正文。",
                "checks": [
                    {
                        "id": check.get("id"),
                        "label": check.get("label"),
                        "message": check.get("message"),
                        "evidence": check.get("evidence", []),
                    }
                    for check in quality_checks
                ],
            },
        )
    if has_review and any(segment["decision"] == "pending" for segment in segments):
        raise HTTPException(
            status_code=409,
            detail={"code": "DRAFT_REVIEW_INCOMPLETE", "message": "还有段落未决定，完成审阅后再放入正文。"},
        )
    if has_review and not any(segment["decision"] == "accepted" for segment in segments):
        raise HTTPException(
            status_code=409,
            detail={"code": "DRAFT_REVIEW_EMPTY", "message": "没有接受的段落，请舍弃候选或重新选择。"},
        )
    # A long-generation merge is still a candidate until the author accepts it.
    # Fence every source segment at the revision captured during merge, then
    # promote it to accepted in the same transaction as the draft decision.
    merge_meta = (draft.request_summary or {}).get("longGenerationMerge") if isinstance(draft.request_summary, dict) else None
    if isinstance(merge_meta, dict):
        raw_segments = merge_meta.get("segments")
        if not isinstance(raw_segments, list) or not raw_segments:
            raise HTTPException(status_code=409, detail={"code": "DRAFT_SEGMENT_METADATA_MISSING"})
        for item in raw_segments:
            if not isinstance(item, dict) or not isinstance(item.get("id"), str) or not isinstance(item.get("revision"), int):
                raise HTTPException(status_code=409, detail={"code": "DRAFT_SEGMENT_METADATA_INVALID"})
            try:
                # Check acceptance after acquiring the row lock. Different
                # drafts can overlap even though each draft itself is locked.
                source_segment = await db.scalar(
                    select(GenerationSegment)
                    .where(GenerationSegment.id == item["id"])
                    .with_for_update()
                    .execution_options(populate_existing=True)
                )
                if source_segment is None or source_segment.chapter_id != draft.chapter_id or source_segment.project_id != draft.project_id:
                    raise HTTPException(status_code=409, detail={"code": "DRAFT_SEGMENT_SCOPE_MISMATCH"})
                if source_segment.status == "accepted":
                    raise HTTPException(
                        status_code=409,
                        detail={
                            "code": "DRAFT_SEGMENT_ALREADY_ACCEPTED",
                            "message": "候选包含已经采纳的分段，请刷新候选后再试。",
                        },
                    )
                await accept_ready_segment(
                    db,
                    item["id"],
                    lease_revision=item["revision"],
                )
            except Exception as exc:
                await db.rollback()
                raise _segment_error(exc) from exc
    draft.status = "accepted"
    draft.accepted_at = datetime.now(UTC)
    await db.commit()
    await db.refresh(draft)
    return _draft_payload(
        draft,
        include_content=True,
        coverage=await _draft_coverage(db, draft),
    )


@router.delete("/drafts/{draft_id}", status_code=204)
async def reject_draft(
    draft_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    draft = await _load_draft(draft_id, user, db, lock=True)
    if draft.status == "rejected":
        return Response(status_code=204)
    if draft.status == "accepted":
        raise HTTPException(status_code=409, detail={"code": "DRAFT_ALREADY_ACCEPTED"})
    if draft.status == "streaming":
        raise HTTPException(status_code=409, detail={"code": "DRAFT_STILL_STREAMING"})
    draft.status = "rejected"
    draft.rejected_at = datetime.now(UTC)
    await db.commit()
    return Response(status_code=204)


async def _reserve(
    package: PromptPackage,
    request: ChapterGenerationRequest,
    user: User,
    db: AsyncSession,
) -> UsageReservation | None:
    if package.billing_mode == "user_key":
        return None
    try:
        return await reserve_generation(
            db,
            user_id=user.id,
            project_id=package.project.id,
            feature="generate_chapter" if package.task == "chapter" else "generate_inline",
            model=package.model_id,
            model_tier=package.model_tier,
            prompt_tokens=package.prompt_tokens,
            target_words=request.target_words,
        )
    except InsufficientCreditsError as exc:
        raise HTTPException(
            status_code=402,
            detail={
                "code": "INSUFFICIENT_CREDITS",
                "required": exc.required,
                "remaining": exc.remaining,
            },
        ) from exc
