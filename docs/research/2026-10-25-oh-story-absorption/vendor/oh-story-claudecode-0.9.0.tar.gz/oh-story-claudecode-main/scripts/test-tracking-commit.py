#!/usr/bin/env python3
"""Behavioral regression tests for the single-authority tracking state tool."""

from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "skills/story-long-write/scripts/tracking_commit.py"
STORYCTL = ROOT / "skills/story-long-write/scripts/storyctl.py"
STORYCTL_SPEC = importlib.util.spec_from_file_location("storyctl_tracking_tests", STORYCTL)
assert STORYCTL_SPEC and STORYCTL_SPEC.loader
storyctl = importlib.util.module_from_spec(STORYCTL_SPEC)
STORYCTL_SPEC.loader.exec_module(storyctl)


def position(*, volume: str = "第一卷·军宣整顿", start: int = 1) -> dict[str, object]:
    return {
        "volume": volume,
        "volume_start_chapter": start,
        "story_time": "实弹训练两天后",
        "scene": "火箭军文工团高层看片会",
    }


def initial_document(
    *,
    last_chapter: int = 0,
) -> dict[str, object]:
    document: dict[str, object] = {
        "schema_version": 1,
        "book_title": "让你管账号，你高燃混剪炸全网",
        "last_chapter": last_chapter,
        "context": {
            "position": position(),
            "long_term_constraints": ["军方培养江晨的后续安排尚未向读者揭示。"],
            "active_character_names": [],
            "continuity_risks": [],
            "recent_chapters": [
                {"chapter": chapter, "summary": f"第{chapter}章军宣账号继续扩大影响。"}
                for chapter in range(max(1, last_chapter - 2), last_chapter + 1)
            ],
            "next_chapter_commitments": ["推进五天百万粉任务。"] if last_chapter else [],
        },
        "character_snapshots": {},
        "foreshadow": [],
        "timeline_events": [],
    }
    return document


def snapshot(*, state: str = "军内认可继续抬升", items: int = 1, repeat: int = 1) -> dict[str, object]:
    phrases = {
        "abilities_resources": "老兵采访授权与军宣制作资源仍需继续使用",
        "relationships": "与钟嘉嘉及文工团的协作关系影响下一阶段决策",
        "knowledge": "已经确认军宣流程和作品传播结果",
        "open_threads": "尚未回收的培养安排与作品计划仍需推进",
    }
    return {
        "identity": "火箭军文工团宣传兵",
        "location": "火箭军文工团高层看片会",
        "goal": "完成五天百万粉任务",
        "state": state,
        **{
            field: [f"第{index + 1}项：{phrase * repeat}" for index in range(items)]
            for field, phrase in phrases.items()
        },
    }


def transaction(
    chapter: int,
    *,
    mode: str = "append",
    character: bool = False,
    foreshadow: bool = False,
    timeline: bool = False,
    next_commitment: str = "结算百万粉任务并承接老兵主题。",
) -> dict[str, object]:
    character_changes = [{"name": "江晨", "change": "作品价值获军内高层确认"}] if character else []
    foreshadow_changes = (
        [
            {
                "action": "upsert",
                "id": "F027",
                "summary": "专业团队仍拍不出江晨原版的灵魂。",
                "planted_chapter": chapter,
                "planned_resolution_chapter": chapter + 8,
                "status": "已埋",
                "importance": "高",
            }
        ]
        if foreshadow
        else []
    )
    timeline_events = (
        [
            {
                "action": "upsert",
                "id": "E010",
                "story_time": "实弹训练两天后",
                "objective_fact": "军方培养江晨另有尚未公开的后续安排。",
                "reader_knowledge": "读者只知道专业重拍版被否决，不知道后续培养安排。",
                "reveal_status": "未揭示",
                "reveal_chapter": None,
                "characters": ["江晨", "钟嘉嘉"],
            }
        ]
        if timeline
        else []
    )
    return {
        "schema_version": 1,
        "mode": mode,
        "chapter": chapter,
        "chapter_title": f"军宣爆款·{chapter}",
        "delta": {
            "result": f"江晨在第{chapter}章继续扩大军宣作品影响力。",
            "character_changes": character_changes,
            "foreshadow_changes": foreshadow_changes,
            "timeline_events": timeline_events,
            "constraints": [],
            "next_chapter_commitments": [next_commitment],
        },
        "context": {
            "position": position(),
            "long_term_constraints": ["军方培养江晨的后续安排尚未向读者揭示。"],
            "active_character_names": ["江晨"] if character else [],
            "continuity_risks": [],
        },
        "character_snapshots": {"江晨": snapshot()} if character else {},
    }


def load_tool_module():
    spec = importlib.util.spec_from_file_location("tracking_commit_under_test", TOOL)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TrackingCommitTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.project = Path(self.temporary.name) / "让你管账号，你高燃混剪炸全网"
        self.project.mkdir()

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def run_tool(
        self,
        command: str,
        document: dict[str, object] | None = None,
        *,
        expect: int = 0,
    ) -> subprocess.CompletedProcess[str]:
        args = [sys.executable, str(TOOL), command, "--project", str(self.project)]
        if document is not None:
            document = json.loads(json.dumps(document, ensure_ascii=False))
            if command == "commit" and "expected_state_revision" not in document:
                document["expected_state_revision"] = self.read_state()["state_revision"]
            input_path = Path(self.temporary.name) / f"{command}-{os.urandom(4).hex()}.json"
            input_path.write_text(json.dumps(document, ensure_ascii=False), encoding="utf-8")
            args.extend(["--input", str(input_path)])
        # 工具按 UTF-8 直写字节；text=True 默认按 locale 解码，Windows 的 cp1252
        # 会在读中文提示时 UnicodeDecodeError，必须显式指定 UTF-8。
        completed = subprocess.run(
            args, text=True, capture_output=True, check=False, encoding="utf-8"
        )
        self.assertEqual(
            completed.returncode,
            expect,
            msg=f"stdout:\n{completed.stdout}\nstderr:\n{completed.stderr}",
        )
        return completed

    def init(self, *, last_chapter: int = 0) -> None:
        self.run_tool(
            "init",
            initial_document(last_chapter=last_chapter),
        )

    def write_chapter_contract(self, chapter: int, *, actual: int = 800, target: int = 1000) -> bytes:
        (self.project / "大纲").mkdir(exist_ok=True)
        (self.project / "正文").mkdir(exist_ok=True)
        width = max(3, len(str(chapter)))
        (self.project / "大纲" / f"细纲_第{chapter:0{width}d}章.md").write_text(
            f"- 字数目标：{target} 字\n- 字数口径：visible_chars_v1\n",
            encoding="utf-8",
        )
        body = ("# 标题\n" + "字" * actual + "。\n").encode("utf-8")
        (self.project / "正文" / f"第{chapter:0{width}d}章_测试.md").write_bytes(body)
        return body

    def bind_wordcount(
        self,
        document: dict[str, object],
        *,
        resolution: str = "accepted_current_length",
    ) -> dict[str, object]:
        chapter = int(document["chapter"])
        if "expected_state_revision" not in document:
            document["expected_state_revision"] = self.read_state()["state_revision"]
        document["wordcount"] = storyctl.build_project_wordcount_record(
            self.project,
            chapter,
            resolution=resolution,
        )
        return document

    def read_state(self) -> dict[str, object]:
        return json.loads((self.project / "追踪/_tracking-state.json").read_text(encoding="utf-8"))

    def test_init_creates_one_structured_authority_and_only_derived_views(self) -> None:
        self.init()
        tracking = self.project / "追踪"
        state = self.read_state()

        self.assertEqual(state["schema_version"], 4)
        self.assertEqual(state["state_revision"], 0)
        self.assertEqual(state["characters"], {})
        self.assertEqual(state["foreshadow"], {})
        self.assertEqual(state["timeline"], {})
        self.assertEqual(state["wordcount_records"], {})
        self.assertNotIn("wordcount_policy", state)
        self.assertNotIn("wordcount_events", state)
        self.assertFalse((tracking / "_tracking-meta.json").exists())
        self.assertFalse((tracking / "时间线/事件库.json").exists())
        self.assertIn("状态修订：0", (tracking / "上下文.md").read_text(encoding="utf-8"))
        self.run_tool("check")

    def test_commit_updates_state_and_all_demo_derived_views(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1, character=True, foreshadow=True, timeline=True))
        tracking = self.project / "追踪"
        state = self.read_state()

        self.assertEqual(state["last_committed_chapter"], 1)
        self.assertEqual(state["state_revision"], 1)
        self.assertIn("江晨", state["characters"])
        self.assertIn("F027", state["foreshadow"])
        self.assertIn("E010", state["timeline"])
        self.assertIn("状态修订：1", (tracking / "上下文.md").read_text(encoding="utf-8"))
        self.assertIn("F027｜专业团队仍拍不出江晨原版的灵魂", (tracking / "上下文.md").read_text(encoding="utf-8"))
        self.assertIn("军方培养江晨另有尚未公开的后续安排", (tracking / "时间线/作者真相.md").read_text(encoding="utf-8"))
        self.assertNotIn("军方培养江晨另有尚未公开的后续安排", (tracking / "时间线/读者已知.md").read_text(encoding="utf-8"))
        self.assertTrue((tracking / "逐章记录/第001章.md").exists())
        self.run_tool("check")

    def test_simple_wordcount_record_commits_the_exact_current_body(self) -> None:
        self.init()
        original = self.write_chapter_contract(1, actual=800, target=1000)
        document = self.bind_wordcount(transaction(1))

        self.run_tool("commit", document)

        state = self.read_state()
        self.assertEqual(state["last_committed_chapter"], 1)
        self.assertEqual(state["state_revision"], 1)
        record = state["wordcount_records"]["1"]
        self.assertEqual(
            set(record),
            {"metric", "target", "actual", "status", "resolution", "body_sha256"},
        )
        self.assertEqual(record["status"], "under")
        self.assertEqual(record["resolution"], "accepted_current_length")
        self.assertEqual((self.project / "正文/第001章_测试.md").read_bytes(), original)
        self.run_tool("check")

    def test_body_or_target_change_rejects_a_prepared_record_without_writes(self) -> None:
        self.init()
        original_body = self.write_chapter_contract(1, actual=800, target=1000)
        document = self.bind_wordcount(transaction(1))
        before = self.read_state()

        body_path = self.project / "正文/第001章_测试.md"
        body_path.write_bytes(original_body + "变".encode("utf-8"))
        changed_body = self.run_tool("commit", document, expect=2)
        self.assertIn("wordcount record is stale", changed_body.stderr)
        self.assertEqual(self.read_state(), before)

        body_path.write_bytes(original_body)
        (self.project / "大纲/细纲_第001章.md").write_text(
            "- 字数目标：1100 字\n- 字数口径：visible_chars_v1\n", encoding="utf-8"
        )
        changed_target = self.run_tool("commit", document, expect=2)
        self.assertIn("wordcount record is stale", changed_target.stderr)
        self.assertEqual(self.read_state(), before)

    def test_two_concurrent_different_commits_advance_only_one_revision(self) -> None:
        self.init()
        self.write_chapter_contract(1, actual=800, target=1000)
        first = self.bind_wordcount(transaction(1, next_commitment="A"))
        second = self.bind_wordcount(transaction(1, next_commitment="B"))

        paths = []
        for index, document in enumerate((first, second), start=1):
            path = Path(self.temporary.name) / f"concurrent-{index}.json"
            path.write_text(json.dumps(document, ensure_ascii=False), encoding="utf-8")
            paths.append(path)
        processes = [
            subprocess.Popen(
                [sys.executable, str(TOOL), "commit", "--project", str(self.project), "--input", str(path)],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                encoding="utf-8",
            )
            for path in paths
        ]
        results = [process.communicate(timeout=20) + (process.returncode,) for process in processes]

        self.assertEqual(sorted(result[2] for result in results), [0, 2], results)
        state = self.read_state()
        self.assertEqual(state["state_revision"], 1)
        self.assertEqual(set(state["wordcount_records"]), {"1"})
        self.assertEqual(len(list((self.project / "追踪/逐章记录").glob("第001章.md"))), 1)

    def test_character_snapshot_lists_are_not_limited_to_eight_items(self) -> None:
        self.init()
        document = transaction(1, character=True)
        document["character_snapshots"]["江晨"] = snapshot(items=12)

        completed = self.run_tool("commit", document)

        self.assertNotIn("at most 8 items", completed.stderr)
        self.assertEqual(len(self.read_state()["characters"]["江晨"]["relationships"]), 12)
        self.run_tool("check")

    def test_snapshot_target_warns_and_hard_cap_rejects_before_any_write(self) -> None:
        self.init()
        warning = transaction(1, character=True)
        warning["character_snapshots"]["江晨"] = snapshot(items=12, repeat=2)
        completed = self.run_tool("commit", warning)
        self.assertIn("WARNING: character snapshot 江晨", completed.stderr)
        self.assertEqual(self.read_state()["state_revision"], 1)

        rejected = transaction(2, character=True)
        rejected["character_snapshots"]["江晨"] = snapshot(items=24, repeat=4)
        before = json.loads(json.dumps(self.read_state(), ensure_ascii=False))
        completed = self.run_tool("commit", rejected, expect=2)
        self.assertIn("hard cap of 8192 bytes", completed.stderr)
        self.assertEqual(self.read_state(), before)
        self.assertFalse((self.project / "追踪/逐章记录/第002章.md").exists())

    def test_missing_active_snapshot_is_rejected_before_any_write(self) -> None:
        self.init()
        document = transaction(1)
        document["context"]["active_character_names"] = ["不存在的核心角色"]
        before = self.read_state()

        result = self.run_tool("commit", document, expect=2)

        self.assertIn("has no current snapshot", result.stderr)
        self.assertEqual(self.read_state(), before)
        self.assertFalse((self.project / "追踪/逐章记录/第001章.md").exists())

    def test_partial_view_write_keeps_old_authority_and_same_transaction_can_retry(self) -> None:
        self.init()
        module = load_tool_module()
        document = transaction(1, character=True, foreshadow=True, timeline=True)
        document["expected_state_revision"] = 0
        original = module.atomic_write_text

        def fail_on_foreshadow(path: Path, payload: str) -> None:
            if path.name == "伏笔.md":
                raise OSError("injected derived-view failure")
            original(path, payload)

        module.atomic_write_text = fail_on_foreshadow
        with self.assertRaises(OSError):
            module.apply_transaction(self.project, document)

        self.assertEqual(self.read_state()["state_revision"], 0)
        self.assertIn("状态修订：1", (self.project / "追踪/上下文.md").read_text(encoding="utf-8"))
        self.run_tool("check", expect=2)

        module.atomic_write_text = original
        module.apply_transaction(self.project, document)
        self.assertEqual(self.read_state()["state_revision"], 1)
        self.run_tool("check")

    def test_stale_revision_cannot_overwrite_newer_state(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1, foreshadow=True, timeline=True))
        stale = transaction(1, mode="revision", foreshadow=True, timeline=True)
        stale["expected_state_revision"] = 1
        self.run_tool("commit", transaction(2))

        result = self.run_tool("commit", stale, expect=2)

        self.assertIn("tracking state changed", result.stderr)
        self.assertEqual(self.read_state()["last_committed_chapter"], 2)
        self.assertEqual(self.read_state()["state_revision"], 2)

    def test_old_revision_preserves_current_next_chapter_commitment(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1, next_commitment="让专业团队进场重拍。"))
        self.run_tool("commit", transaction(2, next_commitment="等待高层看片结论。"))
        self.run_tool("commit", transaction(3, next_commitment="结算五天百万粉任务。"))
        self.run_tool("commit", transaction(1, mode="revision", next_commitment="修订章当时的旧承诺。"))

        context = (self.project / "追踪/上下文.md").read_text(encoding="utf-8")
        self.assertIn("结算五天百万粉任务", context)
        self.assertNotIn("修订章当时的旧承诺", context)

    def test_old_revision_applies_current_rows_without_moving_update_chapter_back(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1, foreshadow=True, timeline=True))
        chapter_two = transaction(2, foreshadow=True, timeline=True)
        chapter_two["delta"]["foreshadow_changes"][0].update(
            planted_chapter=1,
            planned_resolution_chapter=2,
            status="已回收",
            summary="专业版缺少灵魂的判断已经由高层拍板兑现。",
        )
        chapter_two["delta"]["timeline_events"][0]["reader_knowledge"] = "读者已经看到张耀祖采用江晨原版。"
        self.run_tool("commit", chapter_two)

        revision = transaction(1, mode="revision", foreshadow=True, timeline=True)
        revision["delta"]["foreshadow_changes"][0].update(
            planted_chapter=1,
            planned_resolution_chapter=2,
            status="已回收",
            summary="专业版缺少灵魂的判断已经由高层拍板兑现。",
        )
        revision["delta"]["timeline_events"][0]["reader_knowledge"] = "读者已经看到张耀祖采用江晨原版。"
        self.run_tool("commit", revision)

        state = self.read_state()
        self.assertEqual(state["foreshadow"]["F027"]["updated_chapter"], 2)
        self.assertEqual(state["timeline"]["E010"]["updated_chapter"], 2)
        self.run_tool("check")

    def test_imported_cutoff_requires_only_new_daily_records(self) -> None:
        self.init(last_chapter=27)
        self.run_tool("commit", transaction(28, character=True))
        tracking = self.project / "追踪"

        self.assertFalse((tracking / "逐章记录/第027章.md").exists())
        self.assertTrue((tracking / "逐章记录/第028章.md").exists())
        self.assertEqual(self.read_state()["imported_through_chapter"], 27)
        self.run_tool("check")

    def test_imported_chapter_revision_creates_an_overlay_record(self) -> None:
        self.init(last_chapter=20)
        self.run_tool("commit", transaction(10, mode="revision"))
        self.assertTrue((self.project / "追踪/逐章记录/第010章.md").exists())
        self.assertEqual(self.read_state()["imported_through_chapter"], 20)
        self.run_tool("check")

    def test_check_compares_derived_views_to_state_without_parsing_markdown(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1, character=True, foreshadow=True, timeline=True))
        tracking = self.project / "追踪"

        path = tracking / "角色状态/江晨.md"
        path.write_text("# 任意手改格式\n", encoding="utf-8")
        result = self.run_tool("check", expect=2)
        self.assertIn("derived view differs from _tracking-state.json", result.stderr)

        self.run_tool("commit", transaction(2))
        self.run_tool("check")

    def test_check_rejects_orphan_character_file(self) -> None:
        self.init()
        orphan = self.project / "追踪/角色状态/CONFLICT.md"
        orphan.write_text("# orphan\n", encoding="utf-8")
        result = self.run_tool("check", expect=2)
        self.assertIn("character snapshot files differ", result.stderr)

    def test_draft_prefills_current_context_so_only_the_delta_is_written(self) -> None:
        self.init()
        (self.project / "大纲").mkdir(exist_ok=True)
        (self.project / "大纲" / "细纲_第001章.md").write_text("### 第 1 章：看片会\n", encoding="utf-8")
        completed = subprocess.run(
            [sys.executable, str(TOOL), "draft", "--project", str(self.project), "--chapter", "1"],
            text=True, capture_output=True, check=False, encoding="utf-8")
        self.assertEqual(completed.returncode, 0, completed.stderr)
        guide = json.loads(completed.stdout)
        draft_path = Path(guide["draft"])
        self.assertEqual(draft_path, self.project / ".story/work/第001章/tracking.json")
        self.assertEqual(guide["mode"], "append")
        self.assertEqual(guide["limits_chars"]["delta.result"], 160)
        draft = json.loads(draft_path.read_text(encoding="utf-8"))
        self.assertEqual(draft["chapter_title"], "看片会")
        self.assertEqual(draft["expected_state_revision"], self.read_state()["state_revision"])
        self.assertEqual(draft["context"]["long_term_constraints"],
                         self.read_state()["context"]["long_term_constraints"])
        # 新章的故事时间与场景不沿用上一章：留空，逼着按本章结尾填；上一章的值另给参考。
        previous = self.read_state()["context"]["position"]
        self.assertEqual((draft["context"]["position"]["story_time"], draft["context"]["position"]["scene"]), ("", ""))
        self.assertEqual(guide["previous_position"], {"story_time": previous["story_time"], "scene": previous["scene"]})
        self.assertEqual(draft["context"]["position"]["volume"], previous["volume"])
        draft["delta"]["result"] = "江晨在看片会上保住了原版。"
        self.run_tool("commit", draft, expect=2)
        self.assertEqual(self.read_state()["last_committed_chapter"], 0)
        draft["context"]["position"].update({"story_time": "看片会当晚", "scene": "剪辑室"})
        draft_path.write_text(json.dumps(draft, ensure_ascii=False), encoding="utf-8")
        # 重跑 draft 只刷新修订号，不冲掉已填内容。
        again = subprocess.run(
            [sys.executable, str(TOOL), "draft", "--project", str(self.project), "--chapter", "1"],
            text=True, capture_output=True, check=False, encoding="utf-8")
        self.assertEqual(again.returncode, 0, again.stderr)
        self.assertIn("原样保留", json.loads(again.stdout)["fill"])
        draft = json.loads(draft_path.read_text(encoding="utf-8"))
        self.assertEqual(draft["delta"]["result"], "江晨在看片会上保住了原版。")
        self.run_tool("commit", draft)
        self.assertEqual(self.read_state()["last_committed_chapter"], 1)
        self.assertEqual(self.read_state()["context"]["position"]["scene"], "剪辑室")

    def test_common_model_spellings_commit_on_first_try(self) -> None:
        # 实测（v0.8.1 solo A/B，10 章）首次提交全被退回：章号写成字符串、自造 planned_chapter、
        # action 写 add、新书快照的 identity 写成列表。这些写法含义明确，照收并规范成正式形状。
        self.init()
        document = transaction(1, character=True, foreshadow=True, timeline=True)
        row = document["delta"]["foreshadow_changes"][0]
        row["action"] = "add"
        row["planted_chapter"] = "1"
        row["planned_chapter"] = row.pop("planned_resolution_chapter")
        event = document["delta"]["timeline_events"][0]
        event["action"] = "新增"
        document["character_snapshots"]["江晨"]["identity"] = ["火箭军文工团宣传兵", "军宣爆款创作者"]
        document["character_snapshots"]["江晨"]["relationships"] = "与钟嘉嘉协作"
        self.run_tool("commit", document)
        state = self.read_state()
        self.assertEqual(state["foreshadow"]["F027"]["planted_chapter"], 1)
        self.assertEqual(state["foreshadow"]["F027"]["planned_resolution_chapter"], 9)
        self.assertEqual(state["characters"]["江晨"]["identity"], "火箭军文工团宣传兵；军宣爆款创作者")
        self.assertEqual(state["characters"]["江晨"]["relationships"], ["与钟嘉嘉协作"])

    def test_status_verbs_fill_a_missing_status_and_reject_a_contradicting_one(self) -> None:
        # resolve/回收 映射成 upsert 时，动作词本身就是「已回收」的意图：缺 status 按它补，矛盾就退回并说清怎么写。
        self.init()
        document = transaction(1, foreshadow=True)
        row = document["delta"]["foreshadow_changes"][0]
        row["action"] = "回收"
        row.pop("status")
        self.run_tool("commit", document)
        self.assertEqual(self.read_state()["foreshadow"]["F027"]["status"], "已回收")

        for verb, status, hint in (("resolve", "已埋", "status=已回收"), ("回收", "已埋", "status=已回收"),
                                   ("advance", "已回收", "status=已埋"), ("推进", "放弃", "status=已埋")):
            document = transaction(2, foreshadow=True)
            document["delta"]["foreshadow_changes"][0].update({"action": verb, "status": status})
            stderr = self.run_tool("commit", document, expect=2).stderr
            self.assertIn(f"action={verb} 与 status={status} 矛盾", stderr)
            self.assertIn(hint, stderr)
        self.assertEqual(self.read_state()["last_committed_chapter"], 1)

        document = transaction(2, foreshadow=True)
        document["delta"]["foreshadow_changes"][0].update({"action": "推进", "status": "已埋",
                                                           "planted_chapter": "１"})
        self.run_tool("commit", document)
        self.assertEqual(self.read_state()["foreshadow"]["F027"]["status"], "已埋")

    def test_superscript_chapter_is_a_clean_rejection_not_a_traceback(self) -> None:
        self.init()
        document = transaction(1, foreshadow=True)
        document["delta"]["foreshadow_changes"][0]["planted_chapter"] = "²"
        completed = self.run_tool("commit", document, expect=2)
        self.assertIn("planted_chapter must be an integer", completed.stderr)
        self.assertNotIn("Traceback", completed.stderr)

    def test_rejections_name_the_fix(self) -> None:
        self.init()
        document = transaction(1, foreshadow=True)
        document["delta"]["foreshadow_changes"][0]["payoff_note"] = "看片会后"
        completed = self.run_tool("commit", document, expect=2)
        self.assertIn("contains unsupported fields: payoff_note", completed.stderr)
        self.assertIn("只收 action, id, importance, planned_resolution_chapter, planted_chapter, status, summary",
                      completed.stderr)
        document = transaction(1, foreshadow=True)
        document["delta"]["foreshadow_changes"][0]["action"] = "merge"
        self.assertIn("action is invalid: use upsert or delete", self.run_tool("commit", document, expect=2).stderr)
        self.run_tool("commit", transaction(1, character=True))
        document = transaction(2, character=True)
        document["character_snapshots"] = {}
        self.assertIn("current_snapshots", self.run_tool("commit", document, expect=2).stderr)

    def test_draft_shows_entry_shapes_from_the_validator_constants(self) -> None:
        self.init()
        completed = subprocess.run(
            [sys.executable, str(TOOL), "draft", "--project", str(self.project), "--chapter", "1"],
            text=True, capture_output=True, check=False, encoding="utf-8")
        self.assertEqual(completed.returncode, 0, completed.stderr)
        shapes = json.loads(completed.stdout)["shapes"]
        foreshadow = shapes["delta.foreshadow_changes[]"]
        self.assertEqual(foreshadow["planted_chapter"], 1)
        self.assertEqual(foreshadow["status"], "已埋|已回收|已过期|放弃")
        self.assertEqual(set(foreshadow), {"action", "id", "summary", "planted_chapter",
                                           "planned_resolution_chapter", "status", "importance"})
        self.assertEqual(shapes["delta.timeline_events[]"]["reveal_status"], "未揭示|部分揭示|已揭示")
        snapshot_shape = shapes["character_snapshots.{角色名}"]
        self.assertEqual(snapshot_shape["identity"], "一句话")
        self.assertEqual(snapshot_shape["open_threads"], ["一条一句"])

    def test_redraft_with_stale_revision_rebuilds_context_and_keeps_filled_parts(self) -> None:
        self.init()
        (self.project / "大纲").mkdir(exist_ok=True)
        (self.project / "大纲" / "细纲_第001章.md").write_text("### 第 1 章：看片会\n", encoding="utf-8")
        draft_cmd = [sys.executable, str(TOOL), "draft", "--project", str(self.project), "--chapter", "1"]
        first = subprocess.run(draft_cmd, text=True, capture_output=True, check=False, encoding="utf-8")
        draft_path = Path(json.loads(first.stdout)["draft"])
        state = self.read_state()
        # 过期草稿：中间别的事务改过 state 后，旧草稿的修订号与 context 都是旧的。
        stale = json.loads(draft_path.read_text(encoding="utf-8"))
        stale["expected_state_revision"] = state["state_revision"] + 7
        stale["context"]["position"]["volume"] = "旧卷名"
        stale["delta"]["result"] = "江晨保住了原版。"
        stale["context"]["position"].update({"story_time": "当晚", "scene": "剪辑室"})
        draft_path.write_text(json.dumps(stale, ensure_ascii=False), encoding="utf-8")
        again = subprocess.run(draft_cmd, text=True, capture_output=True, check=False, encoding="utf-8")
        self.assertEqual(again.returncode, 0, again.stderr)
        self.assertIn("context 按当前状态重建", json.loads(again.stdout)["fill"])
        rebuilt = json.loads(draft_path.read_text(encoding="utf-8"))
        self.assertEqual(rebuilt["expected_state_revision"], state["state_revision"])
        self.assertEqual(rebuilt["context"]["position"]["volume"], state["context"]["position"]["volume"])
        self.assertEqual(rebuilt["delta"]["result"], "江晨保住了原版。")
        self.assertEqual((rebuilt["context"]["position"]["story_time"], rebuilt["context"]["position"]["scene"]),
                         ("当晚", "剪辑室"))
        self.run_tool("commit", rebuilt)
        self.assertEqual(self.read_state()["last_committed_chapter"], 1)

    def test_redraft_merge_keeps_the_drafts_own_additions_and_retirements(self) -> None:
        self.init()
        (self.project / "大纲").mkdir(exist_ok=True)
        (self.project / "大纲" / "细纲_第001章.md").write_text("### 第 1 章：看片会\n", encoding="utf-8")
        draft_cmd = [sys.executable, str(TOOL), "draft", "--project", str(self.project), "--chapter", "1"]
        first = subprocess.run(draft_cmd, text=True, capture_output=True, check=False, encoding="utf-8")
        draft_path = Path(json.loads(first.stdout)["draft"])
        state = self.read_state()
        old = state["context"]["long_term_constraints"][0]
        stale = json.loads(draft_path.read_text(encoding="utf-8"))
        stale["expected_state_revision"] = state["state_revision"] + 7
        stale["context"]["long_term_constraints"] = ["本章新立的约束。"]  # 删旧条目、加新条目
        stale["delta"]["retired_context_items"] = [old]
        stale["delta"]["result"] = "江晨保住了原版。"
        stale["context"]["position"].update({"story_time": "当晚", "scene": "剪辑室", "volume": "旧卷名"})
        draft_path.write_text(json.dumps(stale, ensure_ascii=False), encoding="utf-8")
        again = subprocess.run(draft_cmd, text=True, capture_output=True, check=False, encoding="utf-8")
        guide = json.loads(again.stdout)
        self.assertIn("卷信息与当前状态不同", guide["fill"])
        rebuilt = json.loads(draft_path.read_text(encoding="utf-8"))
        # 本章的新增留下、退役的不回来。
        self.assertEqual(rebuilt["context"]["long_term_constraints"], ["本章新立的约束。"])
        self.run_tool("commit", rebuilt)
        self.assertEqual(self.read_state()["context"]["long_term_constraints"], ["本章新立的约束。"])

    def test_redraft_revision_and_names_are_not_merged_back_silently(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1))
        # 修订草稿：中间可能插进新章并退役条目，旧草稿多出的条目不能自动带回。
        draft_cmd = [sys.executable, str(TOOL), "draft", "--project", str(self.project), "--chapter", "1"]
        first = subprocess.run(draft_cmd, text=True, capture_output=True, check=False, encoding="utf-8")
        self.assertEqual(json.loads(first.stdout)["mode"], "revision")
        draft_path = Path(json.loads(first.stdout)["draft"])
        state = self.read_state()
        stale = json.loads(draft_path.read_text(encoding="utf-8"))
        stale["expected_state_revision"] = state["state_revision"] + 7
        stale["context"]["long_term_constraints"].append("已被后续章节退役的条目。")
        stale["context"]["active_character_names"].append("路人乙")
        stale["character_snapshots"] = {"路人乙": {"name": "路人乙"}}  # 后续章节已退役的角色的旧快照
        draft_path.write_text(json.dumps(stale, ensure_ascii=False), encoding="utf-8")
        again = subprocess.run(draft_cmd, text=True, capture_output=True, check=False, encoding="utf-8")
        fill = json.loads(again.stdout)["fill"]
        rebuilt = json.loads(draft_path.read_text(encoding="utf-8"))
        self.assertEqual(rebuilt["context"]["long_term_constraints"], state["context"]["long_term_constraints"])
        self.assertNotIn("路人乙", rebuilt["context"]["active_character_names"])
        self.assertIn("没有自动带回", fill)
        self.assertIn("已被后续章节退役的条目。", fill)
        self.assertIn("在场角色 路人乙", fill)
        self.assertIn("角色快照 路人乙", fill)
        self.assertEqual(rebuilt["character_snapshots"], {})

    def draft(self, chapter: int) -> tuple[dict[str, object], Path]:
        completed = subprocess.run(
            [sys.executable, str(TOOL), "draft", "--project", str(self.project), "--chapter", str(chapter)],
            text=True, capture_output=True, check=False, encoding="utf-8")
        self.assertEqual(completed.returncode, 0, completed.stderr)
        guide = json.loads(completed.stdout)
        return guide, Path(guide["draft"])

    def test_revision_draft_keeps_commitments_that_contain_the_separator(self) -> None:
        # 承诺原文带「；」：非最新章的修订草稿从逐章记录读回承诺，不能把一条拆成两条。
        self.init()
        commitment = "江晨答应交片；但只交原版，不交删改版。"
        self.run_tool("commit", transaction(1, next_commitment=commitment))
        self.run_tool("commit", transaction(2))
        _, draft_path = self.draft(1)
        draft = json.loads(draft_path.read_text(encoding="utf-8"))
        self.assertEqual(draft["delta"]["next_chapter_commitments"], [commitment])
        # 照预填提交后再读回，仍是同一条（渲染与读回互逆）。
        self.run_tool("commit", draft)
        (self.project / ".story/work/第001章/tracking.json").unlink()
        _, draft_path = self.draft(1)
        again = json.loads(draft_path.read_text(encoding="utf-8"))
        self.assertEqual(again["delta"]["next_chapter_commitments"], [commitment])

    def test_revision_draft_without_a_record_does_not_claim_it_prefilled(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1))
        self.run_tool("commit", transaction(2))
        (self.project / "追踪/逐章记录/第001章.md").unlink()
        guide, _ = self.draft(1)
        self.assertEqual(guide["mode"], "revision")
        self.assertNotIn("已按本章现有逐章记录预填", guide["fill"])
        self.assertIn("逐章记录缺失", guide["fill"])

    def test_revision_draft_prefills_the_committed_record_so_nothing_is_wiped(self) -> None:
        self.init()
        first = transaction(1, character=True, foreshadow=True, timeline=True)
        first["delta"]["constraints"] = ["原版视频不能再被替换。"]
        self.run_tool("commit", first)
        self.run_tool("commit", transaction(2, character=True))
        record_path = self.project / "追踪/逐章记录/第001章.md"
        before = record_path.read_text(encoding="utf-8")

        guide, draft_path = self.draft(1)
        self.assertEqual(guide["mode"], "revision")
        # 修订的 delta 是本章修订后的完整记录，不是「只填变化」。
        self.assertNotIn("只填 delta 里本章的变化", guide["fill"])
        self.assertIn("完整记录", guide["fill"])
        draft = json.loads(draft_path.read_text(encoding="utf-8"))
        delta = draft["delta"]
        self.assertEqual(delta["result"], first["delta"]["result"])
        self.assertEqual(delta["character_changes"], first["delta"]["character_changes"])
        self.assertEqual([item["id"] for item in delta["foreshadow_changes"]], ["F027"])
        self.assertEqual([item["id"] for item in delta["timeline_events"]], ["E010"])
        self.assertEqual(delta["constraints"], ["原版视频不能再被替换。"])
        self.assertEqual(delta["next_chapter_commitments"], first["delta"]["next_chapter_commitments"])
        self.assertIn("江晨", draft["character_snapshots"])

        # 只改修订真正改变的一项，其余照预填提交：逐章记录除结果外逐字不变，check 通过。
        delta["result"] = "江晨在看片会上保住原版，并当场剪出新预告。"
        self.run_tool("commit", draft)
        after = record_path.read_text(encoding="utf-8")
        self.assertEqual(after, before.replace(first["delta"]["result"], delta["result"]))
        self.run_tool("check")

    def test_revision_keeps_the_chapter_retirement_log(self) -> None:
        self.init()
        constraint = "军方培养江晨的后续安排尚未向读者揭示。"
        declared = transaction(1)
        declared["context"]["long_term_constraints"] = []
        declared["delta"]["retired_context_items"] = [constraint]
        self.run_tool("commit", declared)
        _, draft_path = self.draft(1)
        draft = json.loads(draft_path.read_text(encoding="utf-8"))
        self.run_tool("commit", draft)
        record = (self.project / "追踪/逐章记录/第001章.md").read_text(encoding="utf-8")
        self.assertIn("## 本章退役登记", record)
        self.assertIn(constraint, record)
        self.run_tool("check")

    def test_revision_without_remeasuring_a_changed_body_is_rejected(self) -> None:
        self.init()
        body = self.write_chapter_contract(1, actual=1000, target=1000)
        self.run_tool("commit", self.bind_wordcount(transaction(1), resolution="within_user_band"))
        (self.project / "正文/第001章_测试.md").write_bytes(body.replace("字".encode("utf-8"), "改".encode("utf-8"), 50))
        before = self.read_state()
        result = self.run_tool("commit", transaction(1, mode="revision"), expect=2)
        self.assertIn("storyctl.py chapter commit", result.stderr)
        self.assertEqual(self.read_state(), before)
        # 报错说清改的是哪一项，并指向带 storyctl 的写作 skill（story-review / story-import 不带 storyctl）。
        self.assertIn("第1章正文已改", result.stderr)
        self.assertIn("story-long-write 的 storyctl.py chapter commit", result.stderr)
        # 正文没动的纯追踪修订（例如修派生视图）照常可提交。
        (self.project / "正文/第001章_测试.md").write_bytes(body)
        self.run_tool("commit", transaction(1, mode="revision"))
        # 只改字数目标：报「字数目标已改」，不谎报正文已改。
        outline = self.project / "大纲/细纲_第001章.md"
        original_outline = outline.read_text(encoding="utf-8")
        outline.write_text(original_outline.replace("1000 字", "1200 字"), encoding="utf-8")
        result = self.run_tool("commit", transaction(1, mode="revision"), expect=2)
        self.assertIn("第1章字数目标已改", result.stderr)
        self.assertNotIn("正文已改", result.stderr)

    def test_tracking_only_revision_survives_a_later_author_range_line(self) -> None:
        # 提交时细纲没写「字数范围」（记录无 author_range）；作者事后给细纲补一行范围。正文与目标都没动，
        # 纯追踪修订不该被当成「正文或字数目标已改」拒掉。
        self.init()
        self.write_chapter_contract(1, actual=1000, target=1000)
        self.run_tool("commit", self.bind_wordcount(transaction(1), resolution="within_user_band"))
        outline = self.project / "大纲/细纲_第001章.md"
        outline.write_text(outline.read_text(encoding="utf-8") + "- 字数范围：1500-2000 字\n", encoding="utf-8")
        self.run_tool("commit", transaction(1, mode="revision"))
        self.run_tool("check")

    def test_tracking_only_revision_survives_a_non_numeric_target_note(self) -> None:
        # 旧细纲在数字目标旁留了一行「字数目标：按卷规划」式说明：不含数字的行是说明文字，
        # 已提交章的纯追踪修订照常核对并通过；两个数字值冲突仍拒。
        self.init()
        self.write_chapter_contract(1, actual=1000, target=1000)
        self.run_tool("commit", self.bind_wordcount(transaction(1), resolution="within_user_band"))
        outline = self.project / "大纲/细纲_第001章.md"
        original = outline.read_text(encoding="utf-8")
        outline.write_text(original + "- 字数目标：按卷规划\n", encoding="utf-8")
        self.run_tool("commit", transaction(1, mode="revision"))
        outline.write_text(original + "- 字数目标：1200 字\n", encoding="utf-8")
        result = self.run_tool("commit", transaction(1, mode="revision"), expect=2)
        self.assertIn("字数记录无法核对", result.stderr)

    def test_retired_item_still_in_context_is_rejected(self) -> None:
        self.init()
        document = transaction(1)
        document["delta"]["retired_context_items"] = list(document["context"]["long_term_constraints"])
        result = self.run_tool("commit", document, expect=2)
        self.assertIn("lists items that are still in context", result.stderr)

    def test_all_over_length_fields_are_reported_at_once_in_characters(self) -> None:
        self.init()
        document = transaction(1, foreshadow=True)
        document["delta"]["result"] = "江晨" * 100
        document["delta"]["foreshadow_changes"][0]["summary"] = "老兵" * 70
        result = self.run_tool("commit", document, expect=2)
        self.assertIn("2 个字段超长", result.stderr)
        self.assertIn("delta.result exceeds 480 bytes（现 200 字，上限约 160 字，至少删 40 字）", result.stderr)
        self.assertIn("summary exceeds 360 bytes（现 140 字，上限约 120 字，至少删 20 字）", result.stderr)
        self.assertEqual(self.read_state()["last_committed_chapter"], 0)

    def test_unknown_fields_are_rejected(self) -> None:
        invalid_init = initial_document()
        invalid_init["baseline"] = {}
        self.run_tool("init", invalid_init, expect=2)

        self.init()
        state = self.read_state()
        state["status"] = "clean"
        (self.project / "追踪/_tracking-state.json").write_text(
            json.dumps(state, ensure_ascii=False), encoding="utf-8"
        )
        result = self.run_tool("check", expect=2)
        self.assertIn("unsupported fields", result.stderr)

    def test_init_archives_a_pre_transaction_tracking_directory(self) -> None:
        tracking = self.project / "追踪"
        tracking.mkdir()
        (tracking / "角色状态.md").write_text("# 旧角色状态\n", encoding="utf-8")
        (tracking / "时间线.md").write_text("# 旧时间线\n", encoding="utf-8")
        (tracking / "_tracking-meta.json").write_text("{}\n", encoding="utf-8")

        result = self.run_tool("init", initial_document())
        self.assertIn("_旧追踪存档", result.stderr)
        archive = tracking / "_旧追踪存档"
        self.assertEqual((archive / "角色状态.md").read_text(encoding="utf-8"), "# 旧角色状态\n")
        self.assertEqual((archive / "时间线.md").read_text(encoding="utf-8"), "# 旧时间线\n")
        self.assertFalse((tracking / "角色状态.md").exists())
        self.assertTrue((tracking / "角色状态").is_dir())
        self.run_tool("check")

    def test_failed_init_leaves_the_old_tracking_directory_untouched(self) -> None:
        tracking = self.project / "追踪"
        tracking.mkdir()
        (tracking / "角色状态.md").write_text("# 旧角色状态\n", encoding="utf-8")
        invalid = initial_document()
        invalid["baseline"] = {}

        self.run_tool("init", invalid, expect=2)
        self.assertTrue((tracking / "角色状态.md").exists())
        self.assertFalse((tracking / "_旧追踪存档").exists())

    def test_commit_and_check_still_refuse_a_retired_layout(self) -> None:
        self.init()
        (self.project / "追踪/时间线.md").write_text("# 旧时间线\n", encoding="utf-8")
        result = self.run_tool("check", expect=2)
        self.assertIn("retired tracking files", result.stderr)
        result = self.run_tool("commit", transaction(1), expect=2)
        self.assertIn("retired tracking files", result.stderr)

    def test_dropping_a_context_item_without_declaring_it_is_rejected(self) -> None:
        self.init()
        silent = transaction(1)
        silent["context"]["long_term_constraints"] = []
        result = self.run_tool("commit", silent, expect=2)
        self.assertIn("retired_context_items", result.stderr)
        self.assertEqual(self.read_state()["state_revision"], 0)
        self.assertFalse((self.project / "追踪/逐章记录/第001章.md").exists())

    def test_declared_context_retirement_is_recorded_in_the_chapter_delta(self) -> None:
        self.init()
        declared = transaction(1)
        constraint = "军方培养江晨的后续安排尚未向读者揭示。"
        declared["context"]["long_term_constraints"] = []
        declared["delta"]["retired_context_items"] = [constraint]
        self.run_tool("commit", declared)

        self.assertEqual(self.read_state()["context"]["long_term_constraints"], [])
        delta_text = (self.project / "追踪/逐章记录/第001章.md").read_text(encoding="utf-8")
        self.assertIn("## 本章退役登记", delta_text)
        self.assertIn(constraint, delta_text)
        self.run_tool("check")

    def test_retiring_a_core_character_removes_its_derived_view(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1, character=True))
        self.assertTrue((self.project / "追踪/角色状态/江晨.md").exists())

        retire = transaction(2)
        retire["delta"]["retired_characters"] = ["江晨"]
        self.run_tool("commit", retire)

        self.assertNotIn("江晨", self.read_state()["characters"])
        self.assertFalse((self.project / "追踪/角色状态/江晨.md").exists())
        self.assertIn("角色状态：江晨", (self.project / "追踪/逐章记录/第002章.md").read_text(encoding="utf-8"))
        self.run_tool("check")

    def test_an_interrupted_archive_can_be_resumed(self) -> None:
        tracking = self.project / "追踪"
        (tracking / "_旧追踪存档").mkdir(parents=True)
        (tracking / "角色状态.md").write_text("# 未搬完\n", encoding="utf-8")
        (tracking / "_旧追踪存档/时间线.md").write_text("# 上次已搬\n", encoding="utf-8")

        self.run_tool("init", initial_document())
        archive = tracking / "_旧追踪存档"
        self.assertEqual((archive / "角色状态.md").read_text(encoding="utf-8"), "# 未搬完\n")
        self.assertEqual((archive / "时间线.md").read_text(encoding="utf-8"), "# 上次已搬\n")
        self.run_tool("check")

    def test_archive_never_clobbers_an_already_archived_file(self) -> None:
        tracking = self.project / "追踪"
        (tracking / "_旧追踪存档").mkdir(parents=True)
        (tracking / "角色状态.md").write_text("现役\n", encoding="utf-8")
        (tracking / "_旧追踪存档/角色状态.md").write_text("存档\n", encoding="utf-8")

        result = self.run_tool("init", initial_document(), expect=2)
        self.assertIn("already exists", result.stderr)
        self.assertEqual((tracking / "角色状态.md").read_text(encoding="utf-8"), "现役\n")
        self.assertEqual((tracking / "_旧追踪存档/角色状态.md").read_text(encoding="utf-8"), "存档\n")

    def test_a_character_can_die_and_retire_in_one_transaction(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1, character=True))
        farewell = transaction(2)
        farewell["delta"]["character_changes"] = [{"name": "江晨", "change": "在最终一战中阵亡，彻底退场"}]
        farewell["delta"]["retired_characters"] = ["江晨"]
        self.run_tool("commit", farewell)

        record = (self.project / "追踪/逐章记录/第002章.md").read_text(encoding="utf-8")
        self.assertIn("江晨｜核心｜在最终一战中阵亡，彻底退场", record)
        self.assertIn("角色状态：江晨", record)
        self.assertNotIn("江晨", self.read_state()["characters"])
        self.run_tool("check")

    def test_retirement_is_rejected_in_a_revision(self) -> None:
        self.init(last_chapter=20)
        retire = transaction(10, mode="revision")
        retire["delta"]["retired_characters"] = ["江晨"]
        result = self.run_tool("commit", retire, expect=2)
        self.assertIn("append transaction", result.stderr)

        drop = transaction(10, mode="revision")
        drop["context"]["long_term_constraints"] = []
        drop["delta"]["retired_context_items"] = ["军方培养江晨的后续安排尚未向读者揭示。"]
        result = self.run_tool("commit", drop, expect=2)
        self.assertIn("append transaction", result.stderr)
        self.assertEqual(self.read_state()["state_revision"], 0)

    def test_retiring_a_still_active_character_is_rejected(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1, character=True))
        still_listed = transaction(2)
        still_listed["delta"]["retired_characters"] = ["江晨"]
        still_listed["context"]["active_character_names"] = ["江晨"]
        result = self.run_tool("commit", still_listed, expect=2)
        self.assertIn("retired character 江晨 is still listed in context.active_character_names", result.stderr)
        self.assertEqual(self.read_state()["state_revision"], 1)

    def test_retiring_and_updating_a_character_in_one_transaction_is_rejected(self) -> None:
        self.init()
        self.run_tool("commit", transaction(1, character=True))
        updated = transaction(2, character=True)
        updated["delta"]["retired_characters"] = ["江晨"]
        updated["context"]["active_character_names"] = []
        result = self.run_tool("commit", updated, expect=2)
        self.assertIn("character 江晨 cannot be retired and updated in the same transaction", result.stderr)
        self.assertEqual(self.read_state()["state_revision"], 1)

    def test_windows_reserved_character_name_is_rejected(self) -> None:
        self.init()
        invalid = transaction(1, character=True)
        invalid["delta"]["character_changes"][0]["name"] = "CON"
        invalid["context"]["active_character_names"] = ["CON"]
        invalid["character_snapshots"] = {"CON": invalid["character_snapshots"]["江晨"]}
        result = self.run_tool("commit", invalid, expect=2)
        self.assertIn("is reserved on Windows", result.stderr)
        self.assertEqual(self.read_state()["state_revision"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
